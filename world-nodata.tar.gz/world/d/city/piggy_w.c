//Cracked by Roath
inherit __DIR__"piggy_two.c";

void create()
{
    ::create();

    set ("short", "˫�˹�����");
    set("exits", ([
        "east": __DIR__"club3",
    ]) );
}
