//Cracked by Roath
#include <armor.h>

inherit BOOTS;

void create()
{
        set_name("ţƤսѥ", ({ "niupi shoes", "shoes" }) );
        set_weight(1700);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "˫");
            set("value",7000);
                set("material", "cloth");
            set("armor_prop/armor", 10);
                  set("reincarnation/armor", 1);   
        set("armor_prop/dodge", 15);
        }
        setup();
}

