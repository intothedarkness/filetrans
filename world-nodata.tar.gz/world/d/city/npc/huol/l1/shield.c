//Cracked by Roath
#include <armor.h>

inherit SHIELD;

void create()
{
    set_name("��ľ��", ({"xiangmu dun", "dun", "shield"}));
  set_weight(6000);
  if ( clonep() )
     set_default_object(__FILE__);
  else {
   set("unit", "��");
     set("value",8000);
     set("reincarnation/armor", 1);
   set("material", "wood");
     set("armor_prop/armor", 50);
       }
  setup();
}
