//Cracked by Roath
#include <armor.h>

inherit ARMOR;

void create()
{
          set_name("����ս��", ({"tie armor","armor", "jia"}));
        set_weight(30000);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "��");
		set("long", "һ�������ʵص�ս�ס�\n");
                  set("material", "iron");
                  set("value",20000);
                  set("reincarnation/armor", 1); 
                 set("armor_prop/armor", 90);
                  set("armor_prop/dodge", -5);
        }
        setup();
}


