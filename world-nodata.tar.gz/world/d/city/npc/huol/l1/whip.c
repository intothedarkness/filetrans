//Cracked by Roath
#include <weapon.h>

inherit WHIP;

void create()
{
          set_name("���ڱ�", ({"sanjie whip", "whip"}));
        set_weight(8000);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "��");
                set("reincarnation/weapon", 1); 
                set("value",7500);
        }
         init_whip(80);
        setup();
}

