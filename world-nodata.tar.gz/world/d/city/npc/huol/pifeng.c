//Cracked by Roath
#include <armor.h>

inherit SURCOAT;

void create()
{
    set_name("��Ƥ����", ({"shoupi pifeng","pifeng"}));
  set_weight(4500);
  if( clonep() )
    set_default_object(__FILE__);
  else
  {
    set("long", "һ�������硣\n");
    set("material", "leather");
    set("unit", "��");
      set("value",6500);
      set("armor_prop/armor", 50);
  }
  setup();
}


