//Cracked by Roath
#include <weapon.h>

inherit WHIP;

void create()
{
          set_name("����", ({"ruan whip", "whip"}));
        set_weight(8000);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "��");
            set("value",4500);
        }
         init_whip(60);
        setup();
}

