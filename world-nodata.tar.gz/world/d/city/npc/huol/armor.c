//Cracked by Roath
#include <armor.h>

inherit ARMOR;

void create()
{
          set_name("�������Ӽ�", ({"iron armor","armor", "jia"}));
        set_weight(30000);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "��");
		set("long", "һ�������ʵص����ס�\n");
                  set("material", "iron");
                  set("value",10000);
                  set("armor_prop/armor", 75);
                  set("armor_prop/dodge", -7);
        }
        setup();
}


