//Cracked by Roath
#include <weapon.h>

inherit DAGGER;

void create()
{
  set_name("����צ", ({ "iron zhua", "zhua", "dagger" }) );
  set_weight(300);
  set("unit", "��");
  if( clonep() )
     set_default_object(__FILE__);
  else {
    set("value",8000);
    set("material", "iron");
  }
    set("reincarnation/weapon", 3); 
    set("wield_msg","$N����$n�������\n");
    init_dagger(40);
  setup();
}

