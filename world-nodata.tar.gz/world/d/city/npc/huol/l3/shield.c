//Cracked by Roath
#include <armor.h>

inherit SHIELD;

void create()
{
    set_name("�ľ��", ({"nanmu dun", "dun", "shield"}));
  set_weight(6000);
  if ( clonep() )
     set_default_object(__FILE__);
  else {
   set("unit", "��");
     set("value",10000);
     set("reincarnation/armor", 3);
   set("material", "wood");
     set("armor_prop/armor", 55);
       }
  setup();
}
