//Cracked by Roath
#include <weapon.h>

inherit WHIP;

void create()
{
          set_name("��ڱ�", ({"wujie whip", "whip"}));
        set_weight(8000);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "��");
                set("reincarnation/weapon", 3); 
                set("value",10000);
        }
         init_whip(85);
        setup();
}

