//Cracked by Roath
#include <armor.h>

inherit SURCOAT;

void create()
{
    set_name("��Ƥ����", ({"hupi pifeng","pifeng"}));
  set_weight(4500);
  if( clonep() )
    set_default_object(__FILE__);
  else
  {
    set("long", "һ����Ƥ�����硣\n");
    set("material", "leather");
    set("unit", "��");
      set("value",9000);
      set("armor_prop/armor", 60);
                  set("reincarnation/armor", 3);
  }
  setup();
}


