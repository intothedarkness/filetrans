//Cracked by Roath
#include <armor.h>

inherit BOOTS;

void create()
{
        set_name("��ţƤսѥ", ({ "huangniupi shoes", "shoes" }) );
        set_weight(1700);
        if( clonep() )
                set_default_object(__FILE__);
        else {
                set("unit", "˫");
            set("value",10000);
                set("material", "cloth");
            set("armor_prop/armor", 15);
                  set("reincarnation/armor", 3);   
        set("armor_prop/dodge", 20);
        }
        setup();
}

