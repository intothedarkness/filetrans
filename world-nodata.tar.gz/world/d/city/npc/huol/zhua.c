//Cracked by Roath
#include <weapon.h>

inherit DAGGER;

void create()
{
  set_name("����צ", ({ "tie zhua", "zhua", "dagger" }) );
  set_weight(300);
  set("unit", "��");
  if( clonep() )
     set_default_object(__FILE__);
  else {
     set("value",3000);
    set("material", "tron");
  }
  set("wield_msg","$N����$n�������\n");
    init_dagger(30);
  setup();
}

