void init()
{
        add_action("block_cmd", "", 1);
}

int block_cmd(string args)
{
        string verb = query_verb();
object me = this_player();

        if (wizardp(me)) return 0;
        if (!wizardp(me) && (verb == "perform") || (verb == "exert") || (verb == "cast") || (verb == "throw") || (verb == "duandao") || (verb == "fight")) return 1;
        return 0;
}
