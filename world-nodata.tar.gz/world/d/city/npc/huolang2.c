// huolang3.c
// code refined by Rocky

inherit NPC;
inherit F_VENDOR;

void create()
{
    set_name("��С��", ({"li xiaoer", "li","xiaoer"}));
    set("long","��ͨƤ�߱������ӡ�\n");
    set("gender", "����");
    set("title", "�η�����");
    
    set("combat_exp", 10000);
    set("age", 20);
    set("attitude", "friendly");
    set("shen_type", 1);
    
    set_skill("unarmed", 35);
    set_skill("dodge", 30);
    set_skill("parry", 35);
    set("chat_chance", 5);

    // protected NPC.
    set("protected_NPC", 1);

    set("chat_msg", ({
        (: random_move :)
    }) );
        
    set("vendor_goods", ([


        "armor":    "/d/city/npc/huol/armor",
        "axe":      "/d/city/npc/huol/axe",
        "blade":    "/d/city/npc/huol/blade",
        "cloth":    "/d/city/npc/huol/cloth",
        "fork":     "/d/city/npc/huol/fork",
        "hammer":   "/d/city/npc/huol/hammer",
        "kui":      "/d/city/npc/huol/kui",
        "mace":     "/d/city/npc/huol/mace",
        "pifeng":   "/d/city/npc/huol/pifeng",
        "qin":      "/d/city/npc/huol/qin",
        "shield":   "/d/city/npc/huol/shield",
        "shoes":    "/d/city/npc/huol/shoes",
        "spear":    "/d/city/npc/huol/spear",
        "staff":    "/d/city/npc/huol/staff",
        "stick":    "/d/city/npc/huol/stick",
        "whip":     "/d/city/npc/huol/whip",
        "zhua":     "/d/city/npc/huol/zhua",

    ]) );
    setup();
    add_money("silver", 5);
    carry_object("/d/obj/cloth/choupao")->wear();
}

void init()
{
    object ob;

    ::init();
    if( interactive(ob = this_player()) && !is_fighting() ) 
    {
        remove_call_out("greeting");
        call_out("greeting", 1, ob);
    }
    
    add_action("do_vendor_list", "list");
}
