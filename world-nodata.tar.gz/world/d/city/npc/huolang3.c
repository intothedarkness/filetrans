// huolang3.c
// code refined by Rocky

inherit NPC;
inherit F_VENDOR;

void create()
{
    set_name("��С��", ({"wang xiaoer", "wang","xiaoer"}));
    set("long","��ͨƤ�߱������ӡ�\n");
    set("gender", "����");
    set("title", "�η�����");
    
    set("combat_exp", 10000);
    set("age", 20);
    set("attitude", "friendly");
    set("shen_type", 1);
    
    set_skill("unarmed", 35);
    set_skill("dodge", 30);
    set_skill("parry", 35);
    set("chat_chance", 5);

    // protected NPC.
    set("protected_NPC", 1);

    set("chat_msg", ({
        (: random_move :)
    }) );
        
    set("vendor_goods", ([
        "armor":    "/d/city/npc/huol/l1/armor",
        "axe":      "/d/city/npc/huol/l1/axe",
        "blade":    "/d/city/npc/huol/l1/blade",
        "cloth":    "/d/city/npc/huol/l1/cloth",
        "fork":     "/d/city/npc/huol/l1/fork",
        "hammer":   "/d/city/npc/huol/l1/hammer",
        "kui":      "/d/city/npc/huol/l1/kui",
        "mace":     "/d/city/npc/huol/l1/mace",
        "pifeng":   "/d/city/npc/huol/l1/pifeng",
        "qin":      "/d/city/npc/huol/l1/qin",
        "shield":   "/d/city/npc/huol/l1/shield",
        "shoes":    "/d/city/npc/huol/l1/shoes",
        "spear":    "/d/city/npc/huol/l1/spear",
        "staff":    "/d/city/npc/huol/l1/staff",
        "stick":    "/d/city/npc/huol/l1/stick",
        "whip":     "/d/city/npc/huol/l1/whip",
        "zhua":     "/d/city/npc/huol/l1/zhua",
    ]) );
    
    setup();
    add_money("silver", 5);
    carry_object("/d/obj/cloth/choupao")->wear();
}

void init()
{
    object ob;

    ::init();
    if( interactive(ob = this_player()) && !is_fighting() ) 
    {
        remove_call_out("greeting");
        call_out("greeting", 1, ob);
    }
    
    add_action("do_vendor_list", "list");
}