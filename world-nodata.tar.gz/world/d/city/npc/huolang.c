// huolang.c
// code refined by Rocky
// modify by huadao.2020.08.13
inherit NPC;
inherit F_VENDOR;

void create()
{
    set_name("��С��", ({"xu xiaoer", "xu","xiaoer"}));
    set("gender", "����");
    set("title", "�η�����");
    set("long", "��С���߱�������������챦����׬ȡ��ۣ����Լ۸���Ը���ԭ���ء�\n");
    set("eff_kee", 10000);
    set("eff_gin", 10000);
    set("eff_sen", 10000);
    set("kee", 10000);
    set("gin", 10000);
    set("sen", 10000);
    set("age", 20);
    set("attitude", "friendly");
    // protected NPC.
    set("protected_NPC", 1);    
    set("chat_msg", ({
        (: random_move :)
        }) );
        
    set("vendor_goods", ([
        "pillow":   "/d/city/npc/huol/pillow",
        "wan":      "/d/city/npc/huol/wan",
        "dan":      "/d/obj/drug/jiedudan",
        "shanzha":     "/d/obj/drug/shanzhapian",
        "shanyuan":  "/d/obj/misc/shanyuanfu",
// �������		

//        "goldendan":      "/d/obj/gift/2015/goldendan-huadao",
// ���Ӽ���

//        "xiandan":  "/d/obj/gift/2016/xd",

    ]) );
    setup();
    add_money("silver", 5);
    carry_object("/d/obj/cloth/choupao")->wear();
}

void init()
{
    object ob;
    ::init();
    if( interactive(ob = this_player()) && !is_fighting() ) 
    {
        remove_call_out("greeting");
        call_out("greeting", 1, ob);
    }
    add_action("do_vendor_list", "list");
}
