//
// re-write by Rocky to centralize the implemetation of Zhangmen file to
// Zhangmen.h and specialize the characteristics to individual's zhangmen
// file.
//
inherit "/std/zhangmen.c";

// family specialized definitions.
#define MASTER_NPC              "/d/death/npc/dizhang"
#define ZHNANGMEN_LOCALTION     "/d/death/new-walk2"
#define MALE_IDS                ({"gui wang", "guiwang"})
#define FEMALE_IDS              ({"nu zhu", "nuzhu" })
#define MALE_TILE               "��������";
#define FEMAL_TITLE             "�ظ�Ů��"
#define FAMILY_NAME             "���޵ظ�"

mapping extra_inquiries =
([
    "name" : "�ٺ٣��ظ����ű������¡�\n",
    "here" : "ۺ����˾��Ҳ��\n",
 ]);
    
void create()
{   
    default_male_ids += MALE_IDS;
    default_female_ids += FEMALE_IDS;
    default_male_zhangmen_title = MALE_TILE;
    default_female_zhangmen_title = FEMAL_TITLE;
    
    set("current_master_base_name", MASTER_NPC);
    set("current_master", MASTER_NPC->query("id"));
    set("where", ZHNANGMEN_LOCALTION);
    set("family/family_name", FAMILY_NAME);
    set("gender", MASTER_NPC->query("gender"));
    set("extra_inquiries", extra_inquiries);

    _create(); 
    restore();

    setup();
}
