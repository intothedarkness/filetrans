//Cracked by Roath
// Room: /changan/phomes
//cglaem...12/31/96.
//mon. 2/23/97.

#include <ansi.h>

inherit ROOM;
#include "/cmds/std/valid_move.h";

void create ()
{
    set ("short", "סլ��");
  set ("long", @LONG

��ˮ֮����һ��סլ�����غ�������һ����Ư����С������
�������컣���Ϣ���£�����ס�ҵľ������ڡ�����С¥
ǰ��������(paizi)��д��Щ�˼ҵ����֡�

LONG);

  set("exits", ([ /* sizeof() == 2 */
  "west" : __DIR__"office",
  "east" : __DIR__"wside5",
]));
  set("outdoors", 1);

  setup();
}

void init()
{
        add_action("show_name", "look");
	add_action("enter_home","",1);
}

int show_name(string arg)
{     
      mixed *files; 
      string who,result,content,chinese;
      int n,i,j,k;
      string host, host1, host2;
      int len, len1;

      if(!arg||arg!="paizi") return 0;
      files=get_dir("/data/playerhomes/");
      n=sizeof(files);
      j=0;
      for(i=0;i<=n-1;i++) {
	if(sscanf(files[i], "h_%s.o", who)==1) {
	  files[j]=who;
	  ++j;
        }
      }
      result="\n                        ���֮�� \n";
      if (j>0) {
	--j;
	k=0;
	for (i=0;i<=j;i++) {
	  content=read_file("/data/playerhomes/h_"+
	    files[i]+".o");
          if(content){
            if(sscanf(content,"%*s\"name\":\"%s\"",
	      chinese)==2) {
	      if(sscanf(content,
	        "%*s\"home_host\":({\"%s\",\"%s\",})",
		host1,host2)==3) {
                if(host1==files[i]) host=host1+" & "+host2;
		else if(host2==files[i]) host=host2+" & "+host1;
		else host="data error";
              } else host=files[i];

	      len=strlen(chinese);
	      len1=32-strlen(host);
	      if(len1<1) len1=1; // this should not happen.
	      if(len>len1) chinese=chinese[0..(len1-1)];
	      chinese+=" ("+capitalize(host)+")";
	      result+=sprintf("%-35s  ",chinese);
	      if(k==1) result+="\n";
	      k=1-k;
            }
          }
        }
      }
      
      result="\n"+result+"\n\n\n"+
        "ע���������ҵĵ�һ�����������롣\n";
        
      this_player()->start_more(result);
      
      return 1;
}

int enter_home(string arg)
{     
      string name,*files;
      object env,*inv,room,me=this_player();
      string roomid;
      int i;
    string *home_host;

      roomid="h_"+query_verb();
      files=get_dir("/data/playerhomes/");
      if(member_array(roomid+".o",files)==-1) {
        return 0;
      }

      if(!valid_move(me)) return 0; 
      //check if can move. mon 9/25/97

      env=environment(me);
      inv=all_inventory(env);
      if(i=sizeof(inv)) {
        for(i=0; i<sizeof(inv); i++) {
          if (inv[i]->query("id")==roomid) {
            room=inv[i];
            break;
          }
        } 
      }
      if(!room) {
        room=new("/obj/home.c");
        room->set("file_name",roomid);
        room->restore();        
        room->set("no_fight",1);
        room->set("no_magic",1);
        
        // modified by xfile 2004-12-24
        if ( !room->move(env) )
        {
        	// clean up manually, bcz too many rooms here.
        	clean_up();
        	
        	// if still can't move room to this environment, system can't 
        	// deal with it. it seems impossible that more than 20 players 
        	// wanna enter their home at same time. so, this message seldom
        	// be given up.
        	if ( !room->move(env) )
        		return notify_fail("����סլ���Ѿ����ˣ�����������ɣ�\n");
        	
        }
      }
   home_host=room->query("home_host");
  if (member_array(me->query("id"),home_host)==-1) {
// mon
//    if (member_array( (me->parse_command_id_list())[0],home_host)>-1)
//   {  message_vision("������ͷһ����ס$N���·����˷ܵ�˵����"+me->name()+"�����¿ɴ������ˣ������츶Ƿ�µĹ����ѣ���\n",me);me->start_busy(1);return 1;}
    if (!me->query_temp("armor/cloth")) return notify_fail("�¹ڲ�����ˡ���Ӵ���\n");
    if (me->query_temp("weapon")) return notify_fail("�ֳ�����������ȥ���ͻ���ȥ��ٰ���\n");
  }
      message_vision("$N�����һ���ţ����˽�ȥ��\n",me);
      me->move(room);
      return 1;
}

// modified by xfile@bjxyj  2004-12-24
// here has some bugs.
int clean_up()
{      
	// this is special for this room. no clean_up when there are
	// player homes inside.

	object *inv, * inv_of_room;
	int i, j;	
	// clean up flag.
	int need_clean = 1;
	
	inv = all_inventory();
	
	
	// bug code, commented by xfile.
	/* 
	 for(i=sizeof(inv)-1; i>=0; i--)
	 if(inv[i]->is_home() ||
	   userp(inv[i])) return 1;
	*/
	for ( i = 0; i < sizeof( inv ); i ++ )
	{
		if ( inv[i]->is_home() )
		{
			need_clean = 1;
			
			// enumerate all objects which inside the room.
			// and then detect whether it is a player one bye one.
			inv_of_room = all_inventory( inv[i] );
			for ( j = 0; j < sizeof( inv_of_room ); j ++ )
			{
				// means this room contains players.
				if ( userp ( inv_of_room[j] ) )
				{
					need_clean = 0;
					break;					
				}								
			}
			// destruct the room object by need_clean flag.
			if ( need_clean )
				destruct( inv[i] ); 
		}		
	}	
	return ::clean_up();

}
