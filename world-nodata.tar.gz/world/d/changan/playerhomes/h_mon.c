//Cracked by Roath
// home for mon.

//inherit "/d/changan/playerhomes/home.c";
inherit "/obj/home.c";

void create()
{
     ::create();
     restore();
     setup();
}

