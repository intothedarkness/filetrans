
inherit __DIR__"beach";
