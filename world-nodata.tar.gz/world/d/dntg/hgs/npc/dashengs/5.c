//creat by huadao.20100708.
#define ID 5
#include <dasheng.c>
