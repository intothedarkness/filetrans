//creat by huadao.20100708.
#define ID 0
#include <dasheng.c>
