//creat by huadao.20100708.
#define ID 3
#include <dasheng.c>
