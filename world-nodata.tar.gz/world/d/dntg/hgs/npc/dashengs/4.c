//creat by huadao.20100708.
#define ID 4
#include <dasheng.c>
