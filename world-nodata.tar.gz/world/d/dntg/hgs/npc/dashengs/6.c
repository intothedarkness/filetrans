//creat by huadao.20100708.
#define ID 6
#include <dasheng.c>
