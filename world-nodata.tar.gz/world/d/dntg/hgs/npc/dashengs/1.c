//creat by huadao.20100708.
#define ID 1
#include <dasheng.c>
