//2010.06.20 huadao.
#include <room.h>
inherit ROOM;

void create()
{
set("short", "��������");
set("long", @LONG
    
LONG );


set("exits", ([
  "south"   : __DIR__"qianyuangong",
  "north"   : "/d/5hill/lingxiaowai",
]));


set("objects", ([
  __DIR__"npc/yuhuang"   : 1,
  __DIR__"npc/wuquxingjun"   : 1,
]));



setup();
}

int valid_leave(object me, string dir)
{
    if ((me->query("dntg/laojunlu") != "done") && dir == "north" ) {

            return notify_fail("�󵨣���������Ҳ���Ҵ���\n");
    }
    return ::valid_leave(me, dir);
}
