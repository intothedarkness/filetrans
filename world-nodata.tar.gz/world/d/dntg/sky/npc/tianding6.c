//Cracked by Roath
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("����Ȫ",({ "xin jiu quan", "tian ding", "ding","tianding" }) );

}
