//Cracked by Roath
#include <ansi.h>

inherit "/d/dntg/sky/npc/tianding.c";

void create()
{
  ::create();
  set_name("����ͥ",({ "bi yan ting", "tian ding", "ding","tianding" }) );

}
