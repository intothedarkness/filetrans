//Cracked by Roath
//sgzl

inherit NPC;

void create()
{
  set_name("�ʥ���",({"yisheng zhenjun","zhenjun","jun"}));
  set("gender", "����");
  set("age", 45);
  set("long", "    \n��۵���������������������ǰ�����š�\n");

  set("attitude", "heroism");
  set("class", "xian");
  set("combat_exp", 800000);
  set("daoxing", 1000000);
  set("kee", 1500);
  set("max_kee", 1500);
  set("sen", 1700);
  set("max_sen", 1700);
  set("force", 3000);
  set("max_force", 1500);
  set("mana", 3000);
  set("max_mana", 1500);
  set("force_factor", 100);
  set("mana_factor", 100);


  set_skill("dodge", 140);
  set_skill("baguazhen", 140);
  set_skill("force", 140);
  set_skill("zhenyuan-force", 140);
  set_skill("spells", 140);
  set_skill("taiyi", 140);
  set_skill("unarmed", 140);
  set_skill("wuxing-quan", 140);
  set_skill("parry", 140);


map_skill("dodge", "baguazhen");
map_skill("force", "zhenyuan-force");
map_skill("spells", "taiyi");
map_skill("unarmed", "wuxing-quan");
map_skill("parry", "wuxing-quan");

  set("inquiry", ([
]));


setup();

carry_object("/d/obj/cloth/jinpao")->wear();
add_money("silver", 80);

}
