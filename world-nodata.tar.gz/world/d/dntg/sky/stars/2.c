//Cracked by Roath
#define ID 2
#include <star.c>
