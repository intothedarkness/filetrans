//Cracked by Roath
#define ID 6
#include <star.c>
