//Cracked by Roath
#define ID 0
#include <star.c>
