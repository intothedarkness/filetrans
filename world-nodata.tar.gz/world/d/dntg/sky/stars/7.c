//Cracked by Roath
#define ID 7
#include <star.c>
