//Cracked by Roath
#define ID 3
#include <star.c>
