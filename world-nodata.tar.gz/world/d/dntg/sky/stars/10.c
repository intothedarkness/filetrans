//Cracked by Roath
#define ID 10
#include <star.c>
