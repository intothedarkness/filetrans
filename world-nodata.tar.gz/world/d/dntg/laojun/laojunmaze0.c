//Cracked by Roath
#include <maze.h>
