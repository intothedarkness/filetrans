#include <ansi.h>
//creat by huadao for ��Ұ��.2009.12.14
inherit NPC_SAVE;

void create(int sk, int gd)
{
	gd = random(2);
	sk = random(13);

  set ("long", @LONG
һ������ͨͨ�ļҶ�����ò���ã������׺ͣ���ü��Ŀ��
δ�����ڣ�Ц����ӭ����Ӣ��ׯԺ�ĽӴ���ƽ�������
�����õĿ��ˣ����ݰ�����ͨ����·��
LONG); 

	set_name("����", ({"hu wei", "huwei"}));
	set("title", "Ӣ��ׯԺ");
	set("age", 30);
	set("str", 100);
	set("kar", 40);
	set_weight(9999999);
         set("no_check", 1);
	set("class", "xian");
	set("attitude", "heroism");
	set("per", random(10) + 20);
	set("max_kee", 3000);
	set("max_gin", 3000);
	set("max_sen", 3000);
	set("force", 3000*2);
	set("max_force", 3000);
	set("force_factor", 300);
	set("mana", 3000*2);
	set("max_mana", 3000);
	set("mana_factor", 300);
	set("combat_exp", 3000000);
	set("daoxing", 3000000);
	set("env/no_teach", 1);
	set("eff_dx", 1000);
	set("nkgain", 1000);
    set("reincarnation/number", 10);
    set("no_show_zs", 10);

  set_skill("parry", 300);
  set_skill("unarmed", 300);
  set_skill("dodge", 300);
  set_skill("blade", 300);
  set_skill("fork", 300);
  set_skill("hammer", 300);
  set_skill("sword", 300);
  set_skill("stick", 300);
  set_skill("staff", 300);
  set_skill("spear", 300);
  set_skill("rake", 300);
  set_skill("mace", 300);
  set_skill("archery", 300);
  set_skill("whip", 300);
  set_skill("axe", 300);
  set_skill("spells", 300);
  set_skill("force", 300);

  set_skill("dragonfight", 300);
  set_skill("dragonstep", 300);
  set_skill("xuanhu-blade", 300);
  set_skill("yueya-chan", 300);
  set_skill("kaishan-chui", 300);
  set_skill("fonxansword", 300);
  set_skill("dali-bang", 300);
  set_skill("cloudstaff", 300);
  set_skill("huoyun-qiang", 300);
  set_skill("skyriver-rake", 300);
  set_skill("jinglei-mace", 300);
  set_skill("xuanyuan-archery", 300);
  set_skill("hellfire-whip", 300);
  set_skill("sanban-axe", 300);
  set_skill("seashentong", 300);
  set_skill("ningxie-force", 300);

  map_skill("unarmed", "dragonfight");
  map_skill("dodge", "dragonstep");
  map_skill("blade", "xuanhu-blade");
  map_skill("fork", "yueya-chan");
  map_skill("hammer", "kaishan-chui");
  map_skill("sword", "fonxansword");
  map_skill("stick", "dali-bang");
  map_skill("staff", "cloudstaff");
  map_skill("spear", "huoyun-qiang");
  map_skill("rake", "skyriver-rake");
  map_skill("mace", "jinglei-mace");
  map_skill("archery", "xuanyuan-archery");
  map_skill("axe", "sanban-axe");
  map_skill("whip", "hellfire-whip");
  map_skill("spells", "seashentong");
  map_skill("force", "ningxie-force");

  set("inquiry", ([
        "name" : "���ҵ���С����������,Ӣ��ׯԺ������Ҳ��",
        "here" : "������Ǹ�·���ɵ�ׯԺ�����Ÿ��ɶ��С�",
        "rumor" : "��ˡ���²������",
        "װ��" : "����������������¶��",
        "�߹�" : "�ߣ������Ǻεȵؽ磬˭���ڴ���Ұ��",
         ]) );

	setup();

        if (gd==0) {carry_object("/d/obj/cloth/xianyi")->wear();
		    set("gender", "Ů��");
					}
        else {
			carry_object("/d/obj/cloth/xianpao")->wear();
					    set("gender", "����");
				}
       
                carry_object("/d/bangpai/obj/jinjia");
		carry_object("/d/bangpai/obj/jiasha");
		carry_object("/d/qujing/qilin/obj/shield");

        switch(sk)
        {
        case 0:
            carry_object("/d/bangpai/obj/weapon6");
			command("enable parry dali-bang");
            break; 

        case 1:
            carry_object("/d/bangpai/obj/weapon4");
			command("enable parry fonxansword");
            break; 

        case 2:
            carry_object("/d/bangpai/obj/weapon5");
			command("enable parry cloudstaff");
            break; 

        case 3:
            carry_object("/d/bangpai/obj/weapon9");
			command("enable parry hellfire-whip");
            break; 

        case 4:
            carry_object("/d/bangpai/obj/weapon10");
			command("enable parry sanban-axe");
            break; 

        case 5:
            carry_object("/d/bangpai/obj/weapon3");
			command("enable parry kaishan-chui");
            break; 

        case 6:
            carry_object("/d/bangpai/obj/weapon1");
			command("enable parry xuanhu-blade");
            break; 

        case 7:
            carry_object("/d/bangpai/obj/weapon0");
			command("enable parry skyriver-rake");
            break; 

        case 8:
            carry_object("/d/bangpai/obj/weapon2");
			command("enable parry yueya-chan");
            break; 

        case 9:
            carry_object("/d/bangpai/obj/weapon8");
			command("enable parry huoyun-qiang");
            break; 

        case 10:
            carry_object("/d/bangpai/obj/weapon7");
			command("enable parry jinglei-mace");
            break; 

        case 11:
            carry_object("/d/bangpai/obj/weapon11");
            carry_object("/d/bangpai/obj/arrow");
			command("enable parry xuanyuan-archery");
            break; 


        case 12:
            break; 

        }

	reload("huwei"+ID);
}

void init()
{
	object ob;
	ob=this_player();
	::init();
	
	if( wizardp(ob) && !this_object()->query("have_title") ){
		tell_object(ob,CYN"\n�����Զ���˻����İ�����ƣ�����(settitle ���)��\n\n"NOR);
	}
//        if( wizardp(ob) && !this_object()->query("banghui/improve_huwei") ){
        if( (wizardp(ob) && !this_object()->query("banghui/improve_huwei")) || ob->query("bh_rank") == "����" ){
		tell_object(ob,CYN"\nͨ������������ǿ������ʵ��������(improve_huwei)��\n\n"NOR);
	}
	add_action("settitle", "settitle");
	add_action("improve_huwei", "improve_huwei");
	return;
}

int settitle(string arg)
{
	object ob;
	ob=this_player();

	if(!wizardp(ob))
		return notify_fail("ʲô��\n");

	if(!arg)
		return notify_fail(CYN"����(settitle ���)��\n"NOR);

	tell_object(ob, CYN"�����ɹ���\n"NOR);
	this_object()->set("have_title", 1);
	this_object()->set("title", arg);
	this_object()->save();
	return 1;
}
int improve_huwei(int number, int afford)
{
	object ob;
	ob=this_player();
/*
	if(!wizardp(ob))
		return notify_fail("ʲô��\n");
*/
	//����1000��gold��
  if( !(afford=ob->can_afford(10000000)) )  {
     write(CYN"ÿ����һ����Ҫ�ƽ�1000����������Ǯ���񲻹���\n"NOR);
     return 1; 
  } else if( afford == 2 )  {
      write(CYN"�ֽ��ף�������Ʊ���������ֽ���²�����\n"NOR);
      return 1;
  }

	ob->pay_money(10000000);
	ob->save();
	tell_object(ob, CYN"���Ը�����ϡ�\n"NOR);
	if(! number=this_object()->query("banghui/improve_huwei"))	number=0;
	this_object()->add("banghui/improve_huwei", 1);
	number=this_object()->query("banghui/improve_huwei");
	this_object()->set("number", number);
	set("max_kee", 3000+100*number);
	set("max_gin", 3000+100*number);
	set("max_sen", 3000+100*number);
	set("eff_kee", 3000+100*number);
	set("eff_gin", 3000+100*number);
	set("eff_sen", 3000+100*number);
	set("kee", 3000+100*number);
	set("gin", 3000+100*number);
	set("sen", 3000+100*number);
	set("force", (3000+100*number)*2);
	set("max_force", 3000+100*number);
	set("force_factor", 300+10*number);
	set("mana", (3000+100*number)*2);
	set("max_mana", 3000+100*number);
	set("mana_factor", 300+10*number);
	set("combat_exp", 3000000+100000*number);
	set("daoxing", 3000000+100000*number);
	set("eff_dx", 3000000+500000*number);
	set("nkgain", 1000+100*number);

  set_skill("parry", 300+10*number);
  set_skill("unarmed", 300+10*number);
  set_skill("dodge", 300+10*number);
  set_skill("blade", 300+10*number);
  set_skill("fork", 300+10*number);
  set_skill("hammer", 300+10*number);
  set_skill("sword", 300+10*number);
  set_skill("stick", 300+10*number);
  set_skill("staff", 300+10*number);
  set_skill("spear", 300+10*number);
  set_skill("rake", 300+10*number);
  set_skill("mace", 300+10*number);
  set_skill("archery", 300+10*number);
  set_skill("whip", 300+10*number);
  set_skill("axe", 300+10*number);
  set_skill("spells", 300+10*number);
  set_skill("force", 300+10*number);

  set_skill("dragonfight", 300+10*number);
  set_skill("dragonstep", 300+10*number);
  set_skill("xuanhu-blade", 300+10*number);
  set_skill("yueya-chan", 300+10*number);
  set_skill("kaishan-chui", 300+10*number);
  set_skill("fonxansword", 300+10*number);
  set_skill("dali-bang", 300+10*number);
  set_skill("cloudstaff", 300+10*number);
  set_skill("huoyun-qiang", 300+10*number);
  set_skill("skyriver-rake", 300+10*number);
  set_skill("jinglei-mace", 300+10*number);
  set_skill("xuanyuan-archery", 300+10*number);
  set_skill("hellfire-whip", 300+10*number);
  set_skill("sanban-axe", 300+10*number);
  set_skill("seashentong", 300+10*number);
  set_skill("ningxie-force", 300+10*number);

  this_object()->save();
	return 1;
}

void kill_ob (object ob, int number)
{
  object me = this_object();

    message_vision ("$N���ֳ�ȥ���ף�¶��һ���̴�װ�����ȵ����˴�����������Ұ��\n",me);
    command("drop pao");
    command("drop yi");
     command("wield all");


    command("wear all");

	set("eff_kee", 3000+100*number);
	set("eff_gin", 3000+100*number);
	set("eff_sen", 3000+100*number);
	set("kee", 3000+100*number);
	set("gin", 3000+100*number);
	set("sen", 3000+100*number);
	set("force", (3000+100*number)*2);
	set("mana", (3000+100*number)*2);
	
	set("chat_chance_combat", 30+number);
	set("chat_msg_combat", ({
		(: cast_spell, "hufa" :),
	}));

  ::kill_ob(ob);
}

void unconcious()
{
	die();
}

void die()
{

        if( environment() ) {
        message("sound", "\n\n��ʿ����������ִ̨����ˣ������ס������һ��������������ط�������ȥ�ķ�����\n\n", environment());
        command("bye");
        message("sound", "\n��ʿ����һת�������������ˡ�����\n\n", environment());
        }

        destruct(this_object());
}
