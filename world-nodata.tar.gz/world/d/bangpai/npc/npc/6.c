#define ID 006
#include <huwei.c>
