#define ID 002
#include <huwei.c>
