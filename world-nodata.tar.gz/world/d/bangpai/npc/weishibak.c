#include <ansi.h>
//creat by huadao for ��Ұ��.2009.12.14
inherit NPC;
string ask_me(object me);

void create(int sk, int gd)
{
	gd = random(2);
	sk = random(12);

  set_name("��ʿ", ({"wei shi", "weishi", "hero"}));
  set ("long", @LONG
һ����ز�¶�����ָ��֣�װ���������������ݣ�����Ӣ
��ׯԺ�ĳ���������Ӣ��ׯԺ�ĵؽ��ڣ�һ�а�ȫ�����
�����Ǹ���
LONG); 
	set("title", "Ӣ��ׯԺ");
	set("age", 30);
	set("str", 30);
//	set("no_check", 1);	
	set("class", "xian");
	set("attitude", "heroism");
	set("per", random(10) + 20);
	set("max_kee", 3000);
	set("max_gin", 3000);
	set("max_sen", 3000);
	set("force", 3000*2);
	set("max_force", 3000);
	set("force_factor", 300);
	set("mana", 3000*2);
	set("max_mana", 3000);
	set("mana_factor", 300);
	set("combat_exp", 3000000);
	set("daoxing", 3000000);
	set("env/no_teach", 1);
	set("eff_dx", 3000000);
	set("nkgain", 1000);
    set("reincarnation/number", 10);
    set("no_show_zs", 10);

  set_skill("parry", 300);
  set_skill("unarmed", 300);
  set_skill("dodge", 300);
  set_skill("blade", 300);
  set_skill("fork", 300);
  set_skill("hammer", 300);
  set_skill("sword", 300);
  set_skill("stick", 300);
  set_skill("staff", 300);
  set_skill("spear", 300);
  set_skill("rake", 300);
  set_skill("mace", 300);
  set_skill("archery", 300);
  set_skill("whip", 300);
  set_skill("axe", 300);
  set_skill("spells", 300);
  set_skill("force", 300);

  set_skill("dragonfight", 300);
  set_skill("chaos-steps", 300);
  set_skill("xuanhu-blade", 300);
  set_skill("yueya-chan", 300);
  set_skill("kaishan-chui", 300);
  set_skill("fonxansword", 300);
  set_skill("dali-bang", 300);
  set_skill("cloudstaff", 300);
  set_skill("huoyun-qiang", 300);
  set_skill("skyriver-rake", 300);
  set_skill("jinglei-mace", 300);
  set_skill("xuanyuan-archery", 300);
  set_skill("hellfire-whip", 300);
  set_skill("sanban-axe", 300);
  set_skill("pingtian-dafa", 300);
  set_skill("ningxie-force", 300);

  map_skill("unarmed", "dragonfight");
  map_skill("dodge", "chaos-steps");
  map_skill("blade", "xuanhu-blade");
  map_skill("fork", "yueya-chan");
  map_skill("hammer", "kaishan-chui");
  map_skill("sword", "fonxansword");
  map_skill("stick", "dali-bang");
  map_skill("staff", "cloudstaff");
  map_skill("spear", "huoyun-qiang");
  map_skill("rake", "skyriver-rake");
  map_skill("mace", "jinglei-mace");
  map_skill("archery", "xuanyuan-archery");
  map_skill("axe", "sanban-axe");
  map_skill("whip", "hellfire-whip");
  map_skill("spells", "pingtian-dafa");
  map_skill("force", "ningxie-force");

  set("inquiry", ([
        "name" : "���ҵ���С����������,Ӣ��ׯԺ������Ҳ��",
        "here" : "������Ǹ�·���ɵ�ׯԺ�����Ÿ��ɶ��С�",
        "rumor" : "��˵�ص������ܾ��ڰ����������档����",
        "�߹�" : "�ߣ������Ǻεȵؽ磬˭���ڴ���Ұ��",
         ]) );

	setup();

        if (gd==0) {carry_object("/d/obj/cloth/nichang")->wear();
		    set("gender", "Ů��");
					}
        else {
			carry_object("/d/obj/cloth/luopao")->wear();
					    set("gender", "����");
				}
       
  carry_object("/d/obj/armor/jinjia")->wear();
  carry_object("/d/qujing/qilin/obj/shield")->wear();

        switch(sk)
        {

        case 0:
  carry_object("/d/bangpai/obj/weapon6")->wield();
  command("enable parry dali-bang");
            break; 

        case 1:
  carry_object("/d/bangpai/obj/weapon4")->wield();
  command("enable parry fonxansword");
            break; 

        case 2:
  carry_object("/d/bangpai/obj/weapon5")->wield();
  command("enable parry cloudstaff");
            break; 

        case 3:
  carry_object("/d/bangpai/obj/weapon9")->wield();
  command("enable parry hellfire-whip");
            break; 

        case 4:
  carry_object("/d/bangpai/obj/weapon10")->wield();
  command("enable parry sanban-axe");
            break; 

        case 5:
  carry_object("/d/bangpai/obj/weapon3")->wield();
  command("enable parry kaishan-chui");
            break; 

        case 6:
  carry_object("/d/bangpai/obj/weapon1")->wield();
  command("enable parry xuanhu-blade");
            break; 

        case 7:
  carry_object("/d/bangpai/obj/weapon0")->wield();
  command("enable parry skyriver-rake");
            break; 

        case 8:
  carry_object("/d/bangpai/obj/weapon2")->wield();
  command("enable parry yueya-chan");
            break; 

        case 9:
  carry_object("/d/bangpai/obj/weapon8")->wield();
  command("enable parry huoyun-qiang");
            break; 

        case 10:
  carry_object("/d/bangpai/obj/weapon7")->wield();
  command("enable parry jinglei-mace");
            break; 

        case 11:
  command("remove shield");
  command("enable parry xuanyuan-archery");
  carry_object("/d/bangpai/obj/arrow")->wield();;
  carry_object("/d/bangpai/obj/weapon11")->wield();
            break; 

		}

}

void init()
{
  object me;
  
  ::init();
  if( interactive(me = this_player()) &&
	  living(me)
	  && !is_fighting() 
	  && living(this_object())) {
    call_out("greeting", 1, me);
  }
}

void greeting(object me)
{
  string npcrude=RANK_D->query_self_rude(this_object());
  string myrude=RANK_D->query_rude(me);


	if (me->query_temp("bh_weishi_kill") && !wizardp(me))
    {
      command("say "+me->query("name")+"�����"+myrude+"������ɱ��Խ������"+npcrude+"��������");
      command("kill " + me->query("id"));
	  me->set_temp("no_move", 1);
	  call_out("free", random(2), me);
      return;
    }
}

void free(object me)
{
	if (me)
	me->delete_temp("no_move");      
	return;
}

void kill_ob (object ob)
{
  object me = this_object();

    message_vision ("$Nһ����Ц������س��ɣ��������ɻ�ûһ��������������Ұ�ģ�\n",me);
	set("eff_kee", 3000);
	set("eff_gin", 3000);
	set("eff_sen", 3000);
	set("kee", 3000);
	set("gin", 3000);
	set("sen", 3000);
	set("force", (3000)*2);
	set("mana", (3000)*2);
	set("chat_chance_combat", 10);
	set("chat_msg_combat", ({
		(: cast_spell, "zhuang" :),
	}));
  ::kill_ob(ob);
    ob->set_temp("bh_weishi_kill", 1);
}

void unconcious()
{
	die();
}

void die()
{

        if( environment() ) {
        message("sound", "\n\n��ʿ��������Լ����������أ�������������Ӳ����ٺ����ģ�\n\n", environment());
        command("heng");
        message("sound", "\n��ʿ����һת�������������ˡ�����\n\n", environment());
        }

        destruct(this_object());
}