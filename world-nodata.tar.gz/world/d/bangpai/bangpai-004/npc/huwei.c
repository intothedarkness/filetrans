//creat by huadao for ��Ұ��.2009.12.14
inherit NPC;

void create(int gd, int sk)
{
	gd = random(2);
	sk = random(12);

  set_name("����", ({"hu wei", "huwei"}));
  set ("long", @LONG
һ������ͨͨ�ļҶ�����ò���ã������׺ͣ���ü��Ŀ��
δ�����ڣ�Ц����ӭ����Ӣ��ׯԺ�ĽӴ���ƽ�������
�����õĿ��ˣ����ݰ�����ͨ����·��
LONG); 
	set("title", "��������");
	set("age", 30);
	set("str", 50);
	set_weight(9999999);
    set("no_check", 1);
	set("class", "xian");
	set("attitude", "heroism");
	set("per", random(10) + 20);
	set("max_kee", 3000);
	set("max_gin", 3000);
	set("max_sen", 3000);
	set("force", 3000*2);
	set("max_force", 3000);
	set("force_factor", 300);
	set("mana", 3000*2);
	set("max_mana", 3000);
	set("mana_factor", 300);
	set("combat_exp", 3000000);
	set("daoxing", 3000000);
	set("env/no_teach", 1);
	set("eff_dx", 1000);
	set("nkgain", 1000);
    set("reincarnation/number", 10);
    set("no_show_zs", 10);


  set_skill("parry", 300);
  set_skill("unarmed", 300);
  set_skill("dodge", 300);
  set_skill("blade", 300);
  set_skill("fork", 300);
  set_skill("hammer", 300);
  set_skill("sword", 300);
  set_skill("stick", 300);
  set_skill("staff", 300);
  set_skill("spear", 300);
  set_skill("rake", 300);
  set_skill("mace", 300);
  set_skill("archery", 300);
  set_skill("whip", 300);
  set_skill("axe", 300);
  set_skill("spells", 300);
  set_skill("force", 300);

  set_skill("dragonfight", 300);
  set_skill("chaos-steps", 300);
  set_skill("xuanhu-blade", 300);
  set_skill("yueya-chan", 300);
  set_skill("kaishan-chui", 300);
  set_skill("fonxansword", 300);
  set_skill("dali-bang", 300);
  set_skill("cloudstaff", 300);
  set_skill("huoyun-qiang", 300);
  set_skill("skyriver-rake", 300);
  set_skill("jinglei-mace", 300);
  set_skill("xuanyuan-archery", 300);
  set_skill("hellfire-whip", 300);
  set_skill("sanban-axe", 300);
  set_skill("dao", 300);
  set_skill("dragonforce", 300);

  map_skill("unarmed", "dragonfight");
  map_skill("dodge", "chaos-steps");
  map_skill("blade", "xuanhu-blade");
  map_skill("fork", "yueya-chan");
  map_skill("hammer", "kaishan-chui");
  map_skill("sword", "fonxansword");
  map_skill("stick", "dali-bang");
  map_skill("staff", "cloudstaff");
  map_skill("spear", "huoyun-qiang");
  map_skill("rake", "skyriver-rake");
  map_skill("mace", "jinglei-mace");
  map_skill("archery", "xuanyuan-archery");
  map_skill("axe", "sanban-axe");
  map_skill("whip", "hellfire-whip");
  map_skill("spells", "dao");
  map_skill("force", "dragonforce");

  set("inquiry", ([
        "name" : "���ҵ���С����������,Ӣ��ׯԺ������Ҳ��",
        "here" : "������Ǹ�·���ɵ�ׯԺ�����Ÿ��ɶ��С�",
        "rumor" : "��ˡ���²������",
        "װ��" : "����������������¶��",
        "�߹�" : "�ߣ������Ǻεȵؽ磬˭���ڴ���Ұ��",
         ]) );

	setup();

        if (gd==0) {carry_object("/d/obj/cloth/xianyi")->wear();
		    set("gender", "Ů��");
					}
        else {
			carry_object("/d/obj/cloth/xianpao")->wear();
					    set("gender", "����");
				}
       
  carry_object("/d/bangpai/obj/jinjia");
  carry_object("/d/qujing/qilin/obj/shield");
        switch(sk)
        {
        case 0:
            carry_object("/d/bangpai/obj/weapon6");
			command("enable parry dali-bang");
            break; 

        case 1:
            carry_object("/d/bangpai/obj/weapon4");
			command("enable parry fonxansword");
            break; 

        case 2:
            carry_object("/d/bangpai/obj/weapon5");
			command("enable parry cloudstaff");
            break; 

        case 3:
            carry_object("/d/bangpai/obj/weapon9");
			command("enable parry hellfire-whip");
            break; 

        case 4:
            carry_object("/d/bangpai/obj/weapon10");
			command("enable parry sanban-axe");
            break; 

        case 5:
            carry_object("/d/bangpai/obj/weapon3");
			command("enable parry kaishan-chui");
            break; 

        case 6:
            carry_object("/d/bangpai/obj/weapon1");
			command("enable parry xuanhu-blade");
            break; 

        case 7:
            carry_object("/d/bangpai/obj/weapon0");
			command("enable parry skyriver-rake");
            break; 

        case 8:
            carry_object("/d/bangpai/obj/weapon2");
			command("enable parry yueya-chan");
            break; 

        case 9:
            carry_object("/d/bangpai/obj/weapon8");
			command("enable parry huoyun-qiang");
            break; 

        case 10:
            carry_object("/d/bangpai/obj/weapon7");
			command("enable parry jinglei-mace");
            break; 

        case 11:
            carry_object("/d/bangpai/obj/weapon11");
            carry_object("/d/bangpai/obj/arrow");
			command("enable parry xuanyuan-archery");
            break; 


        case 12:
            break; 

        }
}

void kill_ob (object ob)
{
  object me = this_object();

    message_vision ("$N���ֳ�ȥ���ף�¶��һ���̴�װ�����ȵ����˴�����������Ұ��\n",me);

	set("eff_kee", 3000);
	set("eff_gin", 3000);
	set("eff_sen", 3000);
	set("kee", 3000);
	set("gin", 3000);
	set("sen", 3000);
	set("force", (3000)*2);
	set("mana", (3000)*2);
        set("chat_chance_combat", 30);
        set("chat_msg_combat", ({
        (: exert_function, "shield" :),
        }) );
	command("drop pao");
    command("drop yi");
    command("wield all");
    command("wear all");
  ::kill_ob(ob);

}

void unconcious()
{
	die();
}

void die()
{

        if( environment() ) {
        message("sound", "\n\n��ʿ����������ʹ˰��֣����ڴ˶�л�ˣ����գ�������л��\n\n", environment());
        command("bow");
        message("sound", "\n��ʿ����һת������������ˡ�����\n\n", environment());
        }

        destruct(this_object());
}
