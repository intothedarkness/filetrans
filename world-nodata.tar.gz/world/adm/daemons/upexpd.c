// Created by gslxz@2002/11/30

#include <ansi.h>

int *exp=({
	10000,//1
	30000,
	50000,//3
	70000,
	100000,//5
	125000,
	150000,//7
	200000,
	250000,//9
	300000,
	350000,//11
	400000,
	450000,//13
	500000,
	600000,//15
	700000,
	800000,//17
	900000,
	1000000,//19
	1200000,
	1400000,//21
	1600000,
	1800000,//23
	2000000,
	2300000,//25
	2600000,
	3000000,//27
	3400000,
	3800000,//29
	4200000,
	4800000,//31
	5800000,
	6500000,//33
	7500000,
	9000000,//35
	10000000,
	12000000,//37
	14000000,
	16000000,//39
	18000000,//40
	20000000,//41
	25000000,//42
	30000000,//43
	35000000,//44
	40000000,//45
	45000000,//46
	50000000,//47
	55000000,//48
	60000000,//49 
	70000000, //50
	80000000, //51
	90000000, //52
	100000000, //53
	150000000, //54
	200000000, //55 
});
/**************************************************************************************************/

//added by gslxz@2002/11/30
string query_upexp(object ob)
{
	int exp,d,w;
	
//	d = (int)ob->query("daoxing");
//	w = (int)ob->query("combat_exp");

//	exp = d + w;
  	exp = (int)ob->query("combat_exp");
 
            if(exp >=0 && exp < 10000){
                        ob->set("level",0);
		return  " 0" ;	
        }
       else if(exp >=10000 && exp < 30000){
                       ob->set("level",1);
		return  " 1" ;	
        }
	else if(exp >= 30000 && exp < 50000){
                       ob->set("level",2);
		return  " 2" ;	
        }
	else if(exp >= 50000 && exp < 70000){
                        ob->set("level",3);
		return  " 3" ;
        }
	else if(exp >= 70000 && exp < 100000){
                        ob->set("level",4);
		return  " 4" ;	
        }
	else if(exp >= 100000 && exp < 125000){
                        ob->set("level",5);
		return  " 5" ;	
        }
	else if(exp >= 125000 && exp < 150000){ 
                        ob->set("level",6);
		return  " 6" ;	
        }
	else if(exp >= 150000 && exp < 200000){ 
                        ob->set("level",7);
		return  " 7" ;	
        }
	else if(exp >= 200000 && exp < 250000){ 
                        ob->set("level",8);
		return  " 8" ;	
        }
	else if(exp >= 250000 && exp < 300000){ 
                        ob->set("level",9);
		return  " 9" ;	
        }
	else if(exp >= 300000 && exp < 350000){ 
                        ob->set("level",10);
		return  "10" ;	
        }
	else if(exp >= 350000 && exp < 400000){ 
                        ob->set("level",11);
		return  "11" ;	
        }
	else if(exp >= 400000 && exp < 450000){ 
                        ob->set("level",12);
		return  "12" ;	
        }
	else if(exp >= 450000 && exp < 500000){ 
                        ob->set("level",13);
		return  "13" ;	
        }
	else if(exp >= 500000 && exp < 600000){ 
                        ob->set("level",14);
		return  "14" ;	
        }
	else if(exp >= 600000 && exp < 700000){ 
                        ob->set("level",15);
		return  "15" ;	
        }
	else if(exp >= 700000 && exp < 800000){ 
                        ob->set("level",16);
		return  "16" ;	
        }
	else if(exp >= 800000 && exp < 900000){ 
                        ob->set("level",17);
		return  "17" ;	
        }
	else if(exp >= 900000 && exp < 1000000){ 
                        ob->set("level",18);
		return  "18" ;	
        }
	else if(exp >= 1000000 && exp < 1200000){ 
                        ob->set("level",19);
		return  "19" ;	
        }
	else if(exp >= 1200000 && exp < 1400000){ 
                        ob->set("level",20);
		return  "20" ;	
        }
	else if(exp >= 1400000 && exp < 1600000){ 
                        ob->set("level",21);
		return  "21" ;	
        }
	else if(exp >= 1600000 && exp < 1800000){ 
                        ob->set("level",22);
		return  "22" ;	
        }
	else if(exp >= 1800000 && exp < 2000000){ 
                        ob->set("level",23);
		return  "23" ;	
        }
	else if(exp >= 2000000 && exp < 2300000){ 
                        ob->set("level",24);
		return  "24" ;	
        }
	else if(exp >= 2300000 && exp < 2600000){ 
                        ob->set("level",25);
		return  "25" ;	
        }
	else if(exp >= 2600000 && exp < 3000000){ 
                        ob->set("level",26);
		return  "26" ;	
        }
	else if(exp >= 3000000 && exp < 3400000){ 
                        ob->set("level",27);
		return  "27" ;	
        }
	else if(exp >= 3400000 && exp < 3800000){ 
                        ob->set("level",28);
		return  "28" ;	
        }
	else if(exp >= 3800000 && exp < 4200000){ 
                        ob->set("level",29);
		return  "29" ;	
        }
	else if(exp >= 4200000 && exp < 4800000){ 
                        ob->set("level",30);
		return  "30" ;	
        }
	else if(exp >= 4800000 && exp < 5800000){ 
                        ob->set("level",31);
		return  "31" ;	
        }
	else if(exp >= 5800000 && exp < 6500000){ 
                        ob->set("level",32);
		return  "32" ;	
        }
	else if(exp >= 6500000 && exp < 7500000){ 
                        ob->set("level",33);
		return  "33" ;	
        }
	else if(exp >= 7500000 && exp < 9000000){ 
                        ob->set("level",34);
		return  "34" ;	
        }
	else if(exp >= 9000000 && exp < 10000000){ 
                        ob->set("level",35);
		return  "35" ;	
        }
	else if(exp >= 10000000 && exp < 12000000){ 
                        ob->set("level",36);
		return  "36" ;	
        }
	else if(exp >= 12000000 && exp < 14000000){ 
                        ob->set("level",37);
		return  "37" ;	
        }
	else if(exp >= 14000000 && exp < 16000000){ 
                        ob->set("level",38);
		return  "38" ;	
        }
	else if(exp >= 16000000 && exp < 18000000){ 
                        ob->set("level",39);
		return  "39" ;	
        }
	else if(exp >= 18000000 && exp < 20000000){ 
                        ob->set("level",40);
		return  "40" ;	
        }
	else if(exp >= 20000000 && exp < 25000000){ 
                        ob->set("level",41);
		return  "41" ;	
        }
	else if(exp >= 25000000 && exp < 30000000){ 
                        ob->set("level",42);
		return  "42" ;	
        }
	else if(exp >= 30000000 && exp < 35000000){ 
                        ob->set("level",43);
		return  "43" ;	
        }
	else if(exp >= 35000000 && exp < 40000000){ 
                        ob->set("level",44);
		return  "44" ;	
        }
	else if(exp >= 40000000 && exp < 45000000){ 
                        ob->set("level",45);
		return  "45" ;	
        }
	else if(exp >= 45000000 && exp < 50000000){ 
                        ob->set("level",46);
		return  "46" ;	
        }
	else if(exp >= 50000000 && exp < 55000000){ 
                        ob->set("level",47);
		return  "47" ;	
        }
	else if(exp >= 55000000 && exp < 60000000){ 
                        ob->set("level",48);
		return  "48" ;	
        }
	else if(exp >= 60000000 && exp < 70000000){ 
                        ob->set("level",49);
		return  "49" ;	
        }
	else if(exp >= 70000000 && exp < 80000000){ 
                        ob->set("level",50);
		return  "50" ;	
        }
	else if(exp >= 80000000 && exp < 90000000){ 
                        ob->set("level",51);
		return  "51" ;	
        }
	else if(exp >= 90000000 && exp < 100000000){ 
                        ob->set("level",52);
		return  "52" ;	
        }
	else if(exp >= 100000000 && exp < 150000000){ 
                        ob->set("level",53);
		return  "53" ;	
        }
	else if(exp >= 150000000 && exp < 200000000){ 
                        ob->set("level",54);
		return  "54" ;	
        }
	else if(exp >= 200000000 ){ 
                        ob->set("level",55);
		return  "55" ;	
        }

}
/**************************************************************************************************/

string query_timec(int time)
{
        string msg;
        int day, hour, min;
        
        time=time()-time;
        
        msg="";
        day=time/86400;
        hour=time%86400/3600;
        min=time/60%60;
        if(min<1)
                min=1;
        if(day)
                msg+=sprintf("%s��", chinese_number(day));
        if(day<10 && hour)
                msg+=sprintf("%sСʱ", chinese_number(hour));
        if(!day && hour<20 && min)
                msg+=sprintf("%s����", chinese_number(min));
        return msg;
}

string query_time(int time)
{
        string msg;
        int day, hour, min;
        
        time=time()-time;
        
        msg="";
        day=time/86400;
        hour=time%86400/3600;
        min=time/60%60;

        if(min<1)
                min=1;
        if(day)
                msg+=sprintf("%d��", day);
        if(day<10 && hour)
                msg+=sprintf("%dСʱ", hour);
        if(!day && hour<20 && min )
                msg+=sprintf("%d����", min);

        return msg;
}

