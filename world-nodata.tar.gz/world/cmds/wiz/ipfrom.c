//Cracked by Roath
// ------------------------------------------------------------
// ipfrom.c
// Author: 	xfile@bjxyj
// Date :	2004.12.9
// Purpose: 	check the player's IP where comes from.
// ------------------------------------------------------------
#define __DEBUG 0

string ERROR_STRING 	= "ϵͳ����\n";
string UNKNOWN_IP	= "δ֪�ģɣе�ַ��\n";
string index_file_name 	= "/adm/etc/IPDB/ipindex";

string check_ip(string ip);
string get_config_file( string ip );
int compare_ip( string ip1, string ip2 );
int is_valid_ip( string ip );

void create()
{
	seteuid(getuid());
}

int is_valid_ip( string ip )
{
	string * ip_list;
	int ip_seg1, ip_seg2, ip_seg3, ip_seg4;
	int i;
	
	ip_list = explode( ip, "." );
	if ( sizeof( ip_list ) != 4 )
		return 0;
	
	for ( i = 0;i < 4; i ++ )
	{
		if( atoi( ip_list[i] ) < 0 || atoi( ip_list[i]) > 255 )
		{
			return 0;
		}
	}

	return 1;
}
	
int main(object me, string arg)
{	
	string ip_seg1, ip_seg2, ip_seg3, ip_seg4;
	object user, user_login;
	int query_type;

	string online_ip, last_from_ip;	
	string out_message;

	if (!arg)
		return notify_fail("ָ���ʽ: ipfrom ��ңɣ� �� ipfrom �ɣе�ַ��\n");	
	
	if ( strsrch( arg, "." ) != -1 )
	{
	 	if( !is_valid_ip( arg ) )
			return notify_fail("�ɣе�ַ��ʽ����ȷ��\n");
	}

	// query_type 
	// 1 : means query by user ID.
	// 2 : means query by IP address.
	if ( sscanf(arg, "%s.%s.%s.%s", ip_seg1, ip_seg2, ip_seg3, ip_seg4) == 4 )
	{
		query_type = 2;
	}
	else 
		query_type = 1;

	switch( query_type )
	{
	case 1: 	// case 1: by user ID 	
		{
			user_login = new(LOGIN_OB);
			user_login->set( "id", arg );
			if(!user_login->restore()) 
			{
				destruct( user_login );
				return notify_fail("û�������ҡ�\n");
			}			
		
			last_from_ip = user_login->query("last_from");			

			user = find_player( arg );
			if ( !user )
			{
				out_message = sprintf( 
					"%s(%s) ������Ϣ:\n"
					"------------------------------------------\n"
					"��ǰ����״̬: %s\n"
					"�ϴ����ߣɣ�: %s\n"
					"�ϴΣɣ�����: %s\n"
					"------------------------------------------\n",
					user_login->query("name"), arg,
					"����",
					last_from_ip,
					check_ip( last_from_ip ) );
					break;

			}
			else 
			{
				// get user current IP.
				online_ip = query_ip_number( user );
				out_message = sprintf(
					"%s(%s) ������Ϣ:\n"
					"------------------------------------------\n"
					"��ǰ����״̬: %s\n"
					"��ǰ���ߣɣ�: %s\n"
					"��ǰ�ɣ�����: %s\n"
					//
					// xfile@bjxyj 2004-12-12 8:16
					// A error comes from MUDOS -- interpret.c
					// system error message was that: Too long evaluation. Execution aborted.
					// maybe need rebuild the new version MUDOS.
					// I absolutely have no ieda on this situation, just only make such an 
					// ugly protection. :( 
					// 
					"�ϴ����ߣɣ�: %s\n"
					"�ɣе�ַ����: %s\n"
					"------------------------------------------\n",
					user->query("name"), arg,
					"����",
					online_ip,
					check_ip( online_ip ),
					last_from_ip,
					check_ip( last_from_ip ) );
			}
			destruct( user_login );			
		}
		break;

	case 2:		// case 2: by IP address.

		out_message = sprintf(
			"------------------------------------------\n"					
			"IP : %s\n"
			"IP from : %s\n"
			"------------------------------------------\n",
			arg,
			check_ip( arg ) );
		break;
		
	default :
		out_message = ERROR_STRING;
	}
	write( out_message );
	return 1;


}

// get address string.
string check_ip(string ip)
{	
	

    	string * ip_address, * user_ip, * ip_list_start, * ip_list_end;
	string file_buf, address, ip_start, ip_end, ip_config;
	int i;
		
	ip_config = get_config_file( ip );
	if ( !ip_config )
		return ERROR_STRING;
	
#if __DEBUG
	write( ip_config );

	write( "stack: check_ip: " + ip + "\n" );
#endif	
	user_ip = explode(ip, ".");
    	file_buf = read_file(ip_config);
	
    	if ( !file_buf ) 
	{			
		return ERROR_STRING;
	}
	
    	ip_address = explode( file_buf, "\n" );
    	for (i = 0; i < sizeof(ip_address); i++) 
	{
		if ( sscanf( ip_address[i], "(%s,%s)%s", ip_start, ip_end, address ) == 3 )
		{
			if ( compare_ip( ip_start, ip ) <= 0
				&& compare_ip( ip_end, ip ) >= 0 )
			{
				return address;
			}		
		}
		else 
		{
			return UNKNOWN_IP;
		}

	}
    	return UNKNOWN_IP;

}

// get ip config file.
string get_config_file( string ip )
{
	int i;
	string buf, ip_start_string, ip_end_string, ret_val, file_name;
	string * str_array, *ip_list_start, *ip_list_end;
	

	ret_val = "/adm/etc/IPDB/";

	buf = read_file( index_file_name );	

	if ( !buf )
		return ERROR_STRING;
	
	str_array = explode( buf, "\n" );

	for ( i = 0; i < sizeof( str_array );  i ++ )
	{		
		if ( sscanf( str_array[i], "%s:(%s,%s)", file_name, ip_start_string, ip_end_string ) == 3)
		{
			if ( compare_ip( ip_start_string, ip ) <= 0
				&& compare_ip( ip_end_string, ip ) >= 0 )
			{
				return ret_val + file_name;
			}
		}
		else 
		{
			return ERROR_STRING;
		}
	}	
	return ERROR_STRING;
}

// compare ip address
// Notes:
// 	return value: 
//	-1:	ip1 < ip2
//	1:	ip1 > ip2
//	0:	ip1 = ip2	
int compare_ip( string ip1, string ip2 )
{
	// string * ip_list1 = explode( ip1, "." );
	// string * ip_list2 = explode( ip2, "." );

	// int ip1_1 = atoi( ip_list1[0] );
	// int ip1_2 = atoi( ip_list1[1] );
	// int ip1_3 = atoi( ip_list1[2] );
	// int ip1_4 = atoi( ip_list1[3] );
		
	// int ip2_1 = atoi( ip_list2[0] );
	// int ip2_2 = atoi( ip_list2[1] );
	// int ip2_3 = atoi( ip_list2[2] );
	// int ip2_4 = atoi( ip_list2[3] );
	
	int ip1_1,ip1_2,ip1_3,ip1_4;
	int ip2_1,ip2_2,ip2_3,ip2_4;
	
	sscanf( ip1, "%d.%d.%d.%d", ip1_1, ip1_2, ip1_3, ip1_4 );
	sscanf( ip2, "%d.%d.%d.%d", ip2_1, ip2_2, ip2_3, ip2_4 );
	
	
	

	if ( ip1_1 > ip2_1 ) return 1;
	if ( ip1_1 < ip2_1 ) return -1;

	if ( ip1_1 == ip2_1 )
	{
		if ( ip1_2 > ip2_2 ) return 1;
		if ( ip1_2 < ip2_2 ) return -1;

		if ( ip1_2 == ip2_2)
		{
			if ( ip1_3 > ip2_3 ) return 1;
			if ( ip1_3 < ip2_3 ) return -1;
			if ( ip1_3 == ip2_3)
			{
				if ( ip1_4 > ip2_4 ) return 1;
				if ( ip1_4 < ip2_4 ) return -1;
				if ( ip1_4 == ip2_4 ) return 0;
			}
		}
	}
}