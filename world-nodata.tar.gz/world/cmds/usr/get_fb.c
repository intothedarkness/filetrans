// -------------------------------------------------------------------
// Get_fb.c
// the reason of creating this file is I really do not want to
// mess up the existing command ji.c, the special fabao is now
// some kind of property instead of real item.
// 2015 4.8
// -------------------------------------------------------------------

#include <ansi.h>
inherit F_CLEAN_UP;

#define FABAO_SUIPIAN_PROP              "fabao_system/suipian/"
#define FABAO_FABAO_PROP                "fabao_system/fabao/"
#define OBJ_DIR                         "/services/sys/task/mieyao/obj/"
#define MSG_CREATE_FB                   "��ӽ�����ȡ��һ��%s��\n"
#define MSG_CREATE_FB_FAIL              "�������Ѿ��Ų����κζ����ˡ�\n"
#define COMMAND_TITLE                   HIC + "\n����������Ŀǰ�У�\n" + NOR
#define MSG_EMPTY_BAG                   HIC + "���������ǿյġ�\n" + NOR
#define FABAO_LIST_TITLE                HIC + "��������                ��������\n" + NOR
#define FORMAT                          "%-24s%-30d\n"

#define DEBUG 0

mapping fabao_name_map = 
([
    "yinyang jing"      :  "������",
    "feilong zhang"     :  "������",
    "yuru yi"           :  "������",
    "fuyao suo"         :  "������",
    "linglong ta"       :  "������",
    "zhaoyao jing"      :  "������",
    "fantian yin"       :  "����ӡ",
    "guiqi ling"        :  "������",
    "hundun zhong"      :  "������",
]);

mapping fabao_file_map = 
([
    "������" :  "yinyang-jing.c",
    "������" :  "feilong-zhang.c",
    "������" :  "yuru-yi.c",
    "������" :  "fuyao-suo.c",
    "������" :  "linglong-ta.c",
    "������" :  "zhaoyao-jing.c",
    "����ӡ" :  "fantian-yin.c",
    "������" :  "guiqi-ling.c",
    "������" :  "hundun-zhong.c",
]);

void create() { seteuid(getuid()); }

int list_fabao()
{
    mapping fabao_prop = _player->query(FABAO_FABAO_PROP);
    int num_of_map = sizeof(fabao_prop); 
    
    if(num_of_map <= 0)
    {
        printf(MSG_EMPTY_BAG);
        return 1;
    }
    else
    {
        string  *   fabao_strings = keys(fabao_prop);
        int     *   num_of_fabao = values(fabao_prop);
        
        printf(COMMAND_TITLE);
        printf(HIC + LINE1 + NOR);
        printf(FABAO_LIST_TITLE);      
        printf(HIC + LINE2 + NOR);
        
        for (int i = 0; i < num_of_map; i ++)
        {
            printf( HIY  + FORMAT + NOR,
                fabao_strings[i] + "(" +
                (OBJ_DIR + fabao_file_map[fabao_strings[i]])->parse_command_id_list()[0] + ")",
                num_of_fabao[i]);
        }
        
        printf(HIC + LINE1 + NOR);
    }
    return 1;
}

int main(object me, string arg)
{
    mapping fabao_prop = _player->query(FABAO_FABAO_PROP);
    int num_of_map = sizeof(fabao_prop);
    
    if(!arg) 
        return list_fabao();
    
    if(num_of_map <= 0)
    {
        return notify_fail(MSG_EMPTY_BAG);
    }
    else
    {
        string  *   fabao_strings = keys(fabao_prop);
        int     *   num_of_fabao = values(fabao_prop);
        string      fabao_string = fabao_name_map[arg];
        int         index =  member_array(fabao_string, fabao_strings);

#if DEBUG
        printf("fabao_string = %s\n", fabao_string);
        printf("index = %d\n", index);
        
        for (int c = 0; c < sizeof(fabao_strings); c ++)
        {
            printf("fabao_strings[%d] = %s\n", c, fabao_strings[c]);
        }
#endif

        
        if (stringp(fabao_string) 
            && index != -1
            && num_of_fabao[index] > 0)
        {
            object real_fabao = new(OBJ_DIR + fabao_file_map[fabao_string]);
            real_fabao->set("owner_id", _player->query("id"));
            if(real_fabao->move(_player))
            {
                printf(HIY + MSG_CREATE_FB, real_fabao->get_name() + NOR);
                _player->add(FABAO_FABAO_PROP + fabao_string, -1);
                
                if(_player->query(FABAO_FABAO_PROP + fabao_string) <= 0)
                {
                    _player->delete(FABAO_FABAO_PROP+ fabao_string);
                }
                
                list_fabao();
            }
            else
            {
                printf(HIY + MSG_CREATE_FB_FAIL + NOR);
                destruct(real_fabao);                
            }
        }
    }
    return 1;
}

int help(object me)
{
    write(@HELP
ָ���ʽ :  get_fb <����ID>

���ָ���������ӽ�����ȡ��һ�����ⷨ����
    
���ָ�combine_fb, put_fb

HELP);
    return 1;
}

