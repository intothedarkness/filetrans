inherit F_CLEAN_UP;

int main(object me, string arg)
{
	object * obs;
	string result;
	int total=0, count=0;
	
//	obs=users();
	obs = filter_array(children(USER_OB), (: clonep($1) && $1->query("id") && $1->query("name") :)); 
	result=sprintf("%10s%10s%10s%10s%15s%15s%10s\n",
		"����", "����", "���Ứ", "NK", "������ռ�ٷֱ�", "����/����%", "ID");
	obs=filter_array(obs, (: !wizardp($1) :));
	obs=sort_array(obs, "sort_keys", this_object());
	result+="==================================================================================\n";
	foreach(object ob in obs)
	{
		if(!ob->query("daoxing") || !ob->query("quest/puti-flower/daoxing"))
			continue;
		result+=sprintf("%10d%10d%10d%10d%15d%15d%10s\n",
			ob->query("daoxing"),
			ob->query("quest/gain/daoxing"),
			ob->query("quest/puti-flower/daoxing"),
			ob->query("kill/nkgain"),
			ob->query("quest/puti-flower/daoxing")*100/ob->query("daoxing"),
			ob->query("quest/puti-flower/daoxing")*100/ob->query("quest/gain/daoxing"),
			ob->query("id"));
		count++;
		total+=ob->query("quest/puti-flower/daoxing")*100/ob->query("daoxing");
	}
	result+="==================================================================================\n";
	result+="ƽ�����Ứռ�ܵ��аٷֱȣ�"+total/count+"%\n";
	me->start_more(result);
	return 1;
}

static int sort_keys(object one, object two) { 
	return one->query("daoxing")-two->query("daoxing");
}
