#include "/doc/help.h"
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object ob,string arg,object obj)
{
	if (!arg) return notify_fail ("usage:wakeup <id>\n");
	ob = LOGIN_D->find_body(arg);
	if (!ob){ 
	if (!(ob=present (lower_case(arg), environment(this_player()))) )
		return notify_fail ("��Χû��"+arg+"\n");
	}
//	ob->remove_call_out("revive");
//	ob->revive();
	ob->reincarnate();
	write("Ok.\n");
	destruct(obj); 

	return 1;
}

int help()
{
       write( @TEXT

ָ���ʽ��wakeup <sb.>
ʹĳ������

TEXT
       );
       return 1 ;
}
