
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object me, string arg)
{
        int goto_inventory = 0;
        object obj, ridee;
        string msg, ridemsg;

        if( !arg ) return notify_fail("��Ҫȥ���\n");


        obj = find_object(arg);
        
        if(!obj) obj = find_living(arg);
       
        if(!obj) obj = LOGIN_D->find_body(arg);
        
        if (obj)
          obj->move(environment(me));
          

    
    return 1;
}

int help(object me)
{
write(@HELP
ָ���ʽ : odest | <object euid>
    
HELP
    );
    return 1;
}

