#!/bin/sh
tar -czf ../20`date +"%y-%m-%d"`-User-data.tar.gz data backup-mudlib.sh backup-data.sh backup-all.sh
