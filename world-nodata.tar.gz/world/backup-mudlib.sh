#!/bin/sh
tar -czf ../20`date +"%y-%m-%d"`-Mudlib-XYJ-CN.tar.gz adm cmds d daemon doc feature include obj std u log services backup-mudlib.sh backup-data.sh backup-all.sh
