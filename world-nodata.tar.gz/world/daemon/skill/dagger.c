//Cracked by Roath
// sword.c

inherit SKILL;
