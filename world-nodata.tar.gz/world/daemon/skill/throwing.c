//Cracked by Roath
// throwing.c

inherit SKILL;

