//Cracked by Roath
// hammer.c

inherit SKILL;
