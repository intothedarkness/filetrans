//Cracked by Roath
// axe.c

inherit SKILL;
