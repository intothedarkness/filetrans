//Cracked by Roath
// rake.c

inherit SKILL;
