//Cracked by Roath
// unarmed.c

#include <ansi.h>

inherit SKILL;


