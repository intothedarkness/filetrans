// modified by Rocky@XYJ-CN March 2015
// enhance fair amount of benfit for hell player.

#include <ansi.h>

#define DEBUG           0
#define MULTI_FACTROR   2

inherit SSERVER;

int perform(object me, object target)
{
    int is_hell_player = 0;    
	object weapon = me->query_temp("weapon");
	int weapon_damage = me->query_temp("apply/damage") * MULTI_FACTROR;
    
    if (me->query("family/family_name") == "���޵ظ�")
    {
        is_hell_player = 1;
    }

#if DEBUG
    printf("hell player = %s\n", is_hell_player ? "yes" : "no");
#endif

	if(!target) target = offensive_target(me);

	if( !target
		||      !target->is_character()
		||      target->is_corpse()
		||      target==me)
		return notify_fail("��Ҫ��˭ʩչ��һ�С����ˡ�������\n");

	if(!me->is_fighting())
		return notify_fail("�����ˡ�����ֻ����ս����ʹ�ã�\n");

	if(me->query("force") < 1000 )
		return notify_fail("�������������\n");

    // cut down the force cost to half for hell player.
	me->add("force", is_hell_player ? -50 : -100);

	// increase the hit chance by keeping the target busy.
    // and also increase the weapon damange.
    if (is_hell_player)
	{	
        me->add_temp("apply/damage", weapon_damage);
        me->set_temp("three_powerup", 1);    
        
        if (!target->is_busy())
        {
            // 1 second is sufficient, the following 3 hits will be finished in no time.
            target->start_busy(1);
#if DEBUG
            printf("target is busy now.\n");
#endif            
            target->set_temp("three_busy",1);
        }

	}
	
	message_vision(HIR + "\n$N˫�ֻ�һ��Բ����Ȼ������٣������������������������ˡ����ˡ��������С�\n" + NOR, me);

	me->set("HellZhen", 7);
	COMBAT_D->do_attack(me, target, me->query_temp("weapon"));

	me->set("HellZhen", 6);
	COMBAT_D->do_attack(me, target, me->query_temp("weapon")); 

	me->set("HellZhen", 5);
	COMBAT_D->do_attack(me, target, me->query_temp("weapon"));

	me->delete("HellZhen");
	
	if (me->query_temp("three_powerup") && is_hell_player)
	{
      me->add_temp("apply/damage", -weapon_damage);
      me->delete_temp("three_powerup");
      
      if (target->query_temp("three_busy"))
      {
          target->delete_temp("three_busy");
          target->start_busy(0);
#if DEBUG
           printf("target stops busy now.\n");
#endif           
      }
	}
	
	if( !target->is_fighting(me) ) {
		if( living(target) ) {
			if( userp(target) ) target->fight_ob(me);
			else target->kill_ob(me);
		}
	}

    // lesser busy time for hell player.
        me->start_busy(3); 
	return 1;
}
