// firefox 2011.12
// modified by Rocky@XYJ-CN 
// enhance fair amount of benfit for lingtai player.
#include <ansi.h>


#define DEBUG           0
#define MULTI_FACTROR   2

int perform(object me, object target)
{
    int is_lingtai_player = 0;    
	int weapon_damage = me->query_temp("apply/damage") * MULTI_FACTROR;
	object weapon = me->query_temp("weapon");
	int skill = me->query_skill("qianjun-bang", 1);	
	int cost = 50 + me->query("force_factor");


    if (me->query("family/family_name") == "����ɽ���Ƕ�")
    {
        is_lingtai_player = 1;
    }    
    
	target = BTL->get_victim(me, target);

	if(!target || !me->is_fighting(target))	return notify_fail("����������ֻ����ս����ʹ�ã�\n");
	if(skill < 60)	return notify_fail("���ǧ�������𻹲�����\n");
	if(me->query("force") < cost) return notify_fail("����������㣡\n");
	if(!cd_start(me, "im_pfm", 5)) return notify_fail("�����õ�̫��̫�ľͲ����ˡ�\n");

	me->add("force", -cost);
    
    // increase the hit chance by keeping the target busy.
    // and also increase the weapon damange.
    if (is_lingtai_player)
	{	
        me->add_temp("apply/damage", weapon_damage);
        me->set_temp("pili_powerup", 1);    
        
        if (!target->is_busy())
        {
            // 1 second is sufficient, the following 3 hits will be finished in no time.
            target->start_busy(1);       
            target->set_temp("pili_busy",1);
        }

	}

	message_vision(HIC"\n$N���㾫������һת��������������$n���������У�\n"NOR, me, target);

    if (is_lingtai_player && random(3) == 0)
    {
        me->set_temp("QJB_perform", 7);
    }
    else
    {
        me->set_temp("QJB_perform", 4);
    }
	COMBAT_D->do_attack(me, target, weapon);
	me->set_temp("QJB_perform", 1);
	COMBAT_D->do_attack(me, target, weapon); 
	me->set_temp("QJB_perform", 6);
	COMBAT_D->do_attack(me, target, weapon);
	me->delete_temp("QJB_perform");

	if (me->query_temp("pili_powerup") && is_lingtai_player)
	{
      me->add_temp("apply/damage", -weapon_damage);
      me->delete_temp("pili_powerup");
      
      if (target->query_temp("pili_busy"))
      {
          target->delete_temp("pili_busy");
          target->start_busy(0);        
      }
	}

	BTL->fight_enemy(target, me);
	BTL->start_no_move(me, 3);

	return 1;
}
