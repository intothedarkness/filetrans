// hxl@dhxy.org 2002-7
#include <ansi.h>


inherit F_CLEAN_UP;

void create() { seteuid(ROOT_UID); }

//属性关键字对应的中文含义描述表

mapping desc_list=
(["fight_damage":"单招攻击力",
 "perform_damage":"武技攻击力",
 "cast_damage":"魔法攻击力",
 "need_spi":"装备所需要灵性",
 "need_mana":"装备所需要法力",
 "need_dx":"装备所需要道行(年)",
]);

int main(object me, string arg)
{
	object ob;
	int flag;//一排放两个属性,所以当flag=2 的时候,就换行.初始值为1;
	int desc_count;//属性数量.
	string *attr_en_list;//字符数组,用来存储属性关键字列表
	int i;
	string desc_msg="";
	flag=1;
	
	if (!arg) return notify_fail ("你想要查看什么物品的属性?\n");
	ob=present(arg,me);
	if (!ob) return notify_fail ("你想要查看什么物品的属性?\n");
	if (!ob->query("Is_Diablo_Obj"))
	{
		write("普通物品:\n");
		if (ob->query("armor_prop/armor"))
		desc_msg+=GRN"普通防御值: "+ob->query("armor_prop/armor")+"\n"+NOR;
		if (ob->query("weapon_prop/damage"))
		desc_msg+=GRN"普通攻击力: "+ob->query("weapon_prop/damage")+"\n"+NOR;
		write(desc_msg);
		return 1;
	}
	desc_msg=HIG"特殊物品: "NOR;
	if (ob->query("diablo/not_identified"))
		desc_msg+=HIG"(未鉴定)"NOR;
	desc_msg+="\n";
	if (ob->query("armor_prop/armor"))
		desc_msg+=GRN"普通防御值: "+ob->query("armor_prop/armor")+"\n"+NOR;
	if (ob->query("weapon_prop/damage"))
		desc_msg+=GRN"普通攻击力: "+ob->query("weapon_prop/damage")+"\n"+NOR;
	attr_en_list=keys(desc_list);
	desc_count=sizeof(attr_en_list);
	for (i=0;i<desc_count;i++)
	{
		if (ob->query("diablo/"+attr_en_list[i]))
		{
			desc_msg+=GRN+desc_list[attr_en_list[i]]+": "+ob->query("diablo/"+attr_en_list[i])+NOR;
			if (flag==2) 
			{
				desc_msg+="\n";
				flag=0;
			}
			else 
			{
				
				desc_msg+="             ";
			}
			flag+=1;
		}
	}
	desc_msg+="\n";
	write(desc_msg);
	return 1;
}