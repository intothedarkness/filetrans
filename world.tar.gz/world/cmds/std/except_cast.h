// except_cast.h
// xfile@bjxyj 2004-12-28 12:28
// purpose : definition for peaceful cast.
//

string * peaceful_cast = 
({
	"lifeheal",	
});