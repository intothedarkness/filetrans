// lingwu_set
// created by Rocky for self study
// 2015.2.28
// Align with Huadao's change of reincarnation/number.
// player will get more benifit when the "reincarnation/number" increased.
#include <ansi.h>

#define BAND_RANGE 500

inherit F_CLEAN_UP;

void list_result();
int main(object me, string skill_name)
{
    string chs_skill_name, msg, *sname;
    int skill_level, start_level, i, sizeof_lingwu;    
    int no_limit = 0;
    mapping m = me->query("lingwu");
    int rein_level = (int)me->query("reincarnation/number");
    sizeof_lingwu = sizeof(m);
    
    
    
    if(!skill_name)
    {
        if (sizeof_lingwu <= 0)
        {
            return notify_fail("你还没有任何领悟设定，设定领悟等级请用指令 lingwu_set <技能> <起始等级>\n");
        }
        else 
        {
            sname  = sort_array( keys(m), (: strcmp :) );
            printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            for (i = 0; i < sizeof_lingwu; i++)
            {
                if (!find_object(SKILL_D(sname[i]))) continue;
                no_limit = (!function_exists("valid_enable", find_object(SKILL_D(sname[i]))) && sname[i] != "force");
                printf("   %-28s - 领悟起始等级：%-5d  领悟结束等级： " + (no_limit ? "%-5s\n" : "%-5d\n") + NOR, 
                to_chinese(sname[i]) + " (" + sname[i] + ")",
                m[sname[i]], 
                no_limit ? "无上限" : m[sname[i]] + rein_level * 100 + BAND_RANGE);              
            }
            printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            return 1;
        }
    }
 
    if(sscanf(skill_name, "%s %d", skill_name, start_level) != 2 ) 
        return notify_fail("指令格式 lingwu_set <技能> <起始等级>\n");
    
    if (start_level < 250)
        return notify_fail("起始级别最低为250级。\n");
    
    chs_skill_name = to_chinese(skill_name);
    skill_level = me->query_skill(skill_name, 1);
    seteuid(getuid());    
    
    if (!skill_level)
        return notify_fail("你还不会这项技能。\n");
    
    if (me->query("lingwu/"+skill_name))
    {       
        return notify_fail("你已经设定了"+ chs_skill_name  +"的起始级别。\n");
    }
    
    me->set("lingwu/"+skill_name,  start_level); 
    msg = sprintf("好，你将%s的领悟起始级别设定为%d级。\n",  chs_skill_name, start_level);
    printf(msg);    
    return 1;
}

int help(object me)
{
        write(@HELP
指令格式：lingwu <技能种类>

这个指令让你领悟某个种类的技能，领悟会消耗一定数量的潜能。

要求条件 ： 技能大于250级

当你的技能已经超过你的师傅，你可以通过领悟提高自己本身的技能，
不必向师傅学习，但领悟最多可以提升定量的等级，玩家可以自行设
定每项技能的起始级别（每种技能起始级别只能设定一次，设定后则
不能更改）比如：

    lingwu_set ningxie-force 350

则你可以从350级开始领悟冰谷凝血功直到850级，超过850级，便还
需要和师傅切磋方可提高。

另外，转生可以提高领悟级别，每转生一次可以多领悟100级，比如
果你的转生为1次，可以领悟500 + 100级，则为950级，以此类推。
    
小提示：玩家设定的起始级别越高，收益越大，但到达起始级别之前
花费的时间也越长，如何安排领悟起止区间需要审慎，因为一旦设定
好则不能更改。    
    
其他相关指令 : practice、study、lingwu
HELP
        );
        return 1;
}

