// lingwu
// created by Rocky for self study
// 2015.2.28
// Align with Huadao's change of reincarnation/number.
// player will get more benifit when the "reincarnation/number" increased.

#include <ansi.h>

#define BAND_RANGE 500

inherit F_CLEAN_UP;

int main(object me, string arg)
{
    string skill_name, chs_skill_name;
    int skill_level, start_level, time;
    int upper, sen1;
    int amount, qskill, qlearned, i;
    int sen_cost = 300 / (me->query_int() > 0 ? 2 * me->query_int() : 1);
    
    int rein_level = (int)me->query("reincarnation/number");
    
    if(!arg)
        return notify_fail("指令格式：lingwu <技能>\n");        
 
  if(sscanf(arg, "%s for max", arg) == 1)
        time = (me->query("sen") - 10) / sen_cost;
    else if(sscanf(arg, "%s for %d", arg, time) != 2 ) 
        time =  1;
    if(time<1) time = 1;
    if(time > 1000) time = 1000;
    
    // set parameters.
    skill_name = arg;
    chs_skill_name = to_chinese(skill_name);
    skill_level = me->query_skill(skill_name, 1);
    seteuid(getuid());    
    
    if (!skill_level)
        return notify_fail("你还不会这项技能。\n");
    
    if (skill_level < 250)
        return notify_fail("你的"+ chs_skill_name + "还没有达到无师自通的境界。\n");
    
    start_level = (int)me->query("lingwu/"+skill_name);
    
    if (!start_level || start_level < 250)
        return notify_fail("你的" + chs_skill_name + "还没有设定起始级别。\n");
    
    if (skill_level < start_level)
    {        
         return notify_fail("你的" + chs_skill_name + "还没有到达你设定的起始级别。\n");
    }

    if( !SKILL_D(skill_name)->valid_learn(me) ) 
        return 0;
    
    if (environment(me)->query("no_fight") ||  environment(me)->query("no_magic"))
        return notify_fail("这里不是练功的地方。\n");

    if (me->is_fighting())
        return notify_fail("你已经在战斗中了，学一点实战经验吧。\n");

    if (me->is_busy())
        return notify_fail("你现在很忙，不能练功。\n");
        
    if(MISC_D->random_capture(me,20000,0)) 
        return 1;

    message_vision("$N闭上双目，默念了几句" + chs_skill_name + "的口诀，尝试领悟其中的奥义。\n", me);
    
    upper= (int)me->query("potential")-(int)me->query("learned_points");
    if(time>upper) time=upper;

    if(upper<=0)
        return notify_fail("你的潜能已经发挥到极限了，没有办法再领悟了。\n");

    if(!skill_level)
    {
        qskill=1; qlearned=0; amount=0;
    }
    else
    {
        qskill=me->query_skills()[skill_name]+1;
        qskill*=qskill;
        qlearned=me->query_learned()[skill_name];
        amount = qlearned;
    }

    if( amount > qskill )
    {
        for(i=0; i<time; i++)
            amount += random(me->query_int())+1;
    }
    else
    {
        for(i=0; i<time; i++)
        {
            amount += random(me->query_int())+1;
	      if( amount > qskill )  {i++;break;}
        }
    }

    amount -= qlearned;
    time = i;
    sen_cost *= time;

    // start to improve skills.
    if ((int)me->query("sen") > sen_cost)
    {
        if ((string)SKILL_D(skill_name)->type() == "martial"
            &&	skill_level * skill_level * skill_level / 10 > (int)me->query("combat_exp"))
        {
            printf("也许是实战经验不够，你总是无法领会其中的奥义。\n",);
            return 1;
        }
        else if ((string)SKILL_D(skill_name)->type() == "magic"
            && skill_level * skill_level * skill_level / 10 > (int)me->query("daoxing"))
        {
            printf("也许是道行不够，你总是无法领会其中的奥义。\n");
            return 1;
        }
        else
        {
            if (skill_level < (start_level + rein_level * 100 + BAND_RANGE)
                || (!function_exists("valid_enable", find_object(SKILL_D(skill_name))) && skill_name != "force"))
            {
                printf("片晌后，你睁开双目，似乎有了些心得。\n");
                me->improve_skill(skill_name, amount);
                me->add("learned_points",time);

            }
            else
            {
                printf("你的%s已经领悟到达极限了，需要和别人切磋方可提高了。\n", chs_skill_name);               
            }
        }
    }
    else 
    {
        me->start_busy(1);
        return notify_fail("你现在太累了，没有办法继续领悟了。\n");
    }

    me->receive_damage("sen", sen_cost );
    return 1;
}

int help(object me)
{
        write(@HELP
指令格式：lingwu <技能种类>

这个指令让你领悟某个种类的技能，领悟会消耗一定数量的潜能。

要求条件 ： 技能大于250级

当你的技能已经超过你的师傅，你可以通过领悟提高自己本身的技能，
不必向师傅学习，但领悟最多可以提升定量的等级，玩家可以自行设
定每项技能的起始级别（每种技能起始级别只能设定一次，设定后则
不能更改）比如：

    lingwu_set ningxie-force 350

则你可以从350级开始领悟冰谷凝血功直到850级，超过850级，便还
需要和师傅切磋方可提高。

另外，转生可以提高领悟级别，每转生一次可以多领悟100级，比如
果你的转生为1次，可以领悟500 + 100级，则为950级，以此类推。
    
小提示：玩家设定的起始级别越高，收益越大，但到达起始级别之前
花费的时间也越长，如何安排领悟起止区间需要审慎，因为一旦设定
好则不能更改。

其他相关指令 : practice、study、lingwu_set
HELP
        );
        return 1;
}
