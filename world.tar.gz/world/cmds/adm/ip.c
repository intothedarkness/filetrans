//Cracked by Roath
// checkip.c 
// writed by xfile@bjxyj
// 2005-1-4 

#include <ansi.h>
#include <net/dns.h>

#define __DEBUG 0

int help();

int sort_user1(object ob1, object ob2);
int sort_user2(object ob1, object ob2);
int list_by_user_id( object me, string arg );
int list_all( object me );

inherit F_CLEAN_UP;

void create() { seteuid(getuid()); }

int main( object me, string arg )
{
	return arg ? list_by_user_id( me,  arg ) : list_all( me );
}

int list_by_user_id( object me, string arg )
{
	object user, user_lg;	
	string ip, str, str1;
	int i, b_online_flag;
	object * all_users = filter_array( objects(), (: userp :));
	
	
	if ( !arg )
		return notify_fail("什么？\n");
		
	user = find_player( arg );
	if ( !user )
	{
		user_lg = new(LOGIN_OB);
		user_lg->set( "id", arg );
		if(!user_lg->restore()) 
		{
			destruct( user_lg );
			return notify_fail("没有这个玩家。\n");
		}
		ip = user_lg->query("last_from");	
	}
	else
	{
		ip = query_ip_number( user );
	}
	
	b_online_flag = (user) ? 1 : 0;

#if __DEBUG
	write( "stack : list_by_user_id \n" + user_lg->query("name") + ip);
#endif //__DEBUG
					
	
	
	
	str = "目前与 " + CYN 
		+ ( b_online_flag ? user->query("name") : user_lg->query("name") )
		+ "(" 
		+ arg
		+ ")"  
		+ NOR 
		+ " 相同ＩＰ"
		+ "(" 
		+ ip 
		+ ")" 
		+ "的连线玩家\n";
	
	str += "————————————————————————————————————————\n";
	for ( i = 0; i < sizeof( all_users ); i ++ )
	{		
		if ( !all_users[i] ) continue;
		if ( query_ip_number( all_users[i] ) == ip 
		&& all_users[i]->query("name") 
		&& all_users[i]->query("id") )
		{
  			str1 = " " + all_users[i]->name(1) + GRN + "(" + all_users[i]->query("id") +")"+NOR;        
                      	str = sprintf("%s%s ", str, str1 );
		}
	}
	str += NOR + "\n————————————————————————————————————————\n";
        me->start_more(str);
       
        
        // destruct the login object.
        if ( !b_online_flag )
        	destruct( user_lg );
        	
        return 1;
	
}

// check all of the users and list them out.
// 
int list_all(object me)
{
	
        string str, str1, strip1, strip2, strip3;
        object *list, *ob;
        int i, j, k;
        
	str = "※ " CYN + MUD_NAME + NOR " ※ 相同ＩＰ的连线玩家\n\n";
        str += "ＩＰ地址　　　　　　姓名(id name)\n";
        str += "————————————————————————————————————————\n";

        ob = users();
        list = sort_array(ob, (: sort_user2 :));
        list = sort_array(list, (: sort_user1 :));

        i = sizeof(list);
        strip1 = "0.0.0.0";
        strip2 = "0.0.0.0";
        strip3 = "0.0.0.0";
        while( i-- )
        {
                j = i+1;
                k = i-1;
                strip1 = query_ip_number(list[i]);
                if ( i != sizeof(list)-1 )
                        strip2 = query_ip_number(list[j]);
                if ( i != 0 )
                        strip3 = query_ip_number(list[k]);

                if ( i == sizeof(list)-1 )
                {
                        if ( strip1 == strip3
                        && list[i]->query("name") 
			&& list[i]->query("id") )
                        {
                                str1 = " "+list[i]->name(1)+GRN+"("+list[i]->query("id")+")"+NOR;
                                str = sprintf("%s %-15s%s",
                                        str,
                                        strip1,
                                        str1,
                                        );
                        }
                }
                else
                {
                        if ( i == 0 )
                        {
                                if ( strip1 == strip2
                                 && list[i]->query("name") 
				 && list[i]->query("id")  )
                                {
                                        str1 = " "+list[i]->name(1)+GRN+"("+list[i]->query("id")+")\n"+NOR;
                                        str = sprintf("%s%s",
                                                str,
                                                str1,
                                                );
                                }
                        }
                        else
                        {
                                if ( strip1 == strip2 && strip1 == strip3
                                 && list[i]->query("name") 
				 && list[i]->query("id")  )
                                {
                                        str1 = " "+list[i]->name(1)+GRN+"("+list[i]->query("id")+")"+NOR;
                                        str = sprintf("%s%s",
                                                str,
                                                str1,
                                                );
                                }
                                else if ( strip1 == strip2
                                 && list[i]->query("name") 
				 && list[i]->query("id")  )
                                {
                                        str1 = " "+list[i]->name(1)+GRN+"("+list[i]->query("id")+")\n"+NOR;
                                        str = sprintf("%s%s",
                                                str,
                                                str1,
                                                );
                                }
                                else if ( strip1 == strip3
                                 && list[i]->query("name") 
				 && list[i]->query("id")  )
                                {
                                        str1 = " "+list[i]->name(1)+GRN+"("+list[i]->query("id")+")"+NOR;
                                        str = sprintf("%s %-15s%s",
                                                str,
                                                strip1,
                                                str1,
                                                );
                                }
                        }
                }
        }

        str += NOR + "————————————————————————————————————————\n";

        me->start_more(str);
        return 1;
}

int sort_user1(object ob1, object ob2)
{
        string name1, name2;

        name1 = query_ip_number(ob1);
        name2 = query_ip_number(ob2);

        if (intp(name1)) name1 = "";
        if (intp(name2)) name2 = "";
        if (name1 > name2) return -1;
        if (name1 < name2) return 1;

        return (int)ob2->query("combat_exp") - (int)ob1->query("combat_exp");
}

int sort_user2(object ob1, object ob2)
{
        string name1, name2;

        name1 = ob1->query("id");
        name2 = ob2->query("id");

        if (intp(name1)) name1 = "";
        if (intp(name2)) name2 = "";
        if (name1 > name2) return -1;
        if (name1 < name2) return 1;

        return (int)ob2->query("combat_exp") - (int)ob1->query("combat_exp");
}

int help()
{
        write("
指令格式 : 
	ip 或
	ip 玩家ID

这个指令可以列出在线上指定相同ＩＰ的玩家或
所有相同ＩＰ的玩家。

相关指令： finger
	   ipfrom
	   
"
        );
        return 1;
}

