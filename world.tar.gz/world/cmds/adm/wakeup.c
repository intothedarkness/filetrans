#include "/doc/help.h"
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object ob,string arg,object obj)
{
	if (!arg) return notify_fail ("usage:wakeup <id>\n");
	ob = LOGIN_D->find_body(arg);
	if (!ob){ 
	if (!(ob=present (lower_case(arg), environment(this_player()))) )
		return notify_fail ("周围没有"+arg+"\n");
	}
//	ob->remove_call_out("revive");
//	ob->revive();
	ob->reincarnate();
	write("Ok.\n");
	destruct(obj); 

	return 1;
}

int help()
{
       write( @TEXT

指令格式：wakeup <sb.>
使某人苏醒

TEXT
       );
       return 1 ;
}
