//modify by huadao .20140614.

#include <ansi.h>
inherit F_CLEAN_UP;
int main(object me, string arg)
{
int total;
     object ob;
	int rebirth1,number;

	 if(!arg)
      return notify_fail("指令为chasm id\n");

		ob = find_player(arg);

     if(!ob) ob = find_living(arg);

     if (!ob) return notify_fail("没这个人啊。。。。。咬死你,:D\n");

		tell_object(me,ob->query("name")+"的数据如下：\n\n");

	 if (ob->query("betrayer") || ob->query("betray/count"))
		{
		tell_object(me,ob->query("name")+HIR+"不是"+ob->query("family/family_name")+NOR"纯号，判师"+HIR+(3+ (int)ob->query("betray/count"))+NOR"次\n");
		} else {
		tell_object(me,ob->query("name")+HIR+" 是 "+ob->query("family/family_name")+NOR"纯号\n");
		}

//////////////////////////////////////////////////////////////////      
//added by huadao for 转生次数和救命毫毛的查看。20160304.
		rebirth1 = ob->query("obstacle/rebirth");
		number = ob->query("reincarnation/number");
		tell_object(me,ob->query("name")+"转生"+HIR+((int)ob->query("reincarnation/number"))+NOR"次，共"+HIR+( -(int)ob->query("obstacle/rebirth") )+NOR"根救命毫毛\n");
//		line += sprintf(" 你到目前为止共转生 %d 次，现有 %d 根救命毫毛。\n\n", number, 3-rebirth1 );
//////////////////////////////////////////////////////////////////      
		tell_object(me,ob->query("name")+"的寿命是"+HIR+chinese_number((int)ob->query("life/life_time"))+NOR"岁\n");
		tell_object(me,ob->query("name")+"已经吃了"+HIR+chinese_number((int)ob->query("rsg_eaten"))+NOR"个人参果\n");
		tell_object(me,ob->query("name")+"体格="+ob->query("str")+" 根骨="+ob->query("con")+"\n");
		tell_object(me,ob->query("name")+"悟性="+ob->query("int")+" 灵性="+ob->query("spi")+"\n");
		tell_object(me,ob->query("name")+"定力="+ob->query("cps")+" 容貌="+ob->query("per")+"\n");
		tell_object(me,ob->query("name")+"胆识="+ob->query("cor")+" 福缘="+ob->query("kar")+"\n");

		total = (int)ob->query("str") + (int)ob->query("con") + (int)ob->query("int") + (int)ob->query("spi") + 
				(int)ob->query("cps") + (int)ob->query("per") + (int)ob->query("cor") + (int)ob->query("kar");

		tell_object(me,ob->query("name")+"的天赋总数是："+ total +"\n");
//        tell_object(me,ob->query("name")+"lift_time="+ob->query("life/life_time")+"\n\n");
		return 1;
}
