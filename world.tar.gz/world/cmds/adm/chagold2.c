
#include <net/dns.h>
#include <ansi.h>

inherit F_CLEAN_UP;

void create() { seteuid(getuid()); }

mixed main(object me, string arg, int remote)
{
    
    object *list,g_ob,s_ob,c_ob, * inv;
    string str,load,cmds,comp;
    int tc,gc,sc,cc,j;
    int i, t_ppl_cnt, cnt, count, wcnt = 0;
    int opt_long, opt_id, opt_wiz, opt_party;

    str = HIR+"☆ " + MUD_NAME + " 当前在线玩家资料金钱统计\n\n"+NOR;
    str += HIG"帐号            姓名        银票  金子  银子  铜板  存款(金子) \n"NOR;
    str += HIY"———————————————————————————————————————\n"NOR;
    list = users();
    j=sizeof(list);
    while( j-- ) {
        if( !environment(list[j]) || !me->visible(list[j])) continue;
        inv = all_inventory(list[j]);  
        if (g_ob = present("cash", list[j]))
            tc = g_ob->query_amount();
        else
            tc = 0;
        if (g_ob = present("gold", list[j]))
            gc = g_ob->query_amount();
        else
            gc = 0;
        if (s_ob = present("silver", list[j]))
            sc = s_ob->query_amount();
        else
            sc = 0;
        if (c_ob = present("coin", list[j]))
            cc = c_ob->query_amount();
        else
            cc = 0;    
            
        str = sprintf("%s%-15s %-10s%3d张  %3d两 %3d两 %3d文   %6s %3d\n",
                str,
                list[j]->query("id"),list[j]->name(1),tc, gc,sc,cc,
                MONEY_D->money_str(((int)list[j]->query("balance")/10000)*10000),list[j]->query("age")
            );
    }
        
    str += HIY"———————————————————————————————————————\n"NOR;

      load=query_load_average();

      if(sscanf(load,"%s cmds/s, %s comp lines/s", cmds,comp)!=2) {//By waiwai@2001/07/05
	str = sprintf(WHT"%s"NOR WHT"有"HIG" %d"NOR WHT" 位玩家连线中，"HIR"%d"NOR WHT" 位玩家断线中，系统执行速率：%s \n", str, t_ppl_cnt,cnt, query_load_average());
          } else {
              str = sprintf(WHT"%s"NOR WHT"共有"HIG" %d "NOR WHT"位玩家连线中，"HIR"%d"NOR WHT" 位断线中,"+
                      "平均每秒执行"HIB" %s "NOR WHT"条指令"+
                      ((!remote&&wizardp(me))?"，编译"HIB" %s"NOR WHT" 行源程序":"")+
                      "\n"NOR,
                      str, sizeof(list), cnt,cmds, comp);
          }//这里用"sizeof(list)"会产生不准确的数据。

	if( remote ) return str;
	me->start_more(str);

//    write(str);
    return 1;

}

int sort_user(object ob1, object ob2)
{
    if( wizardp(ob1) && !wizardp(ob2) ) return -1;
    
    if( wizardp(ob2) && !wizardp(ob1) ) return 1;

    if( wizardp(ob1) && wizardp(ob2) )
        return (int)SECURITY_D->get_wiz_level(ob2) 
            - (int)SECURITY_D->get_wiz_level(ob1);
    
    return (int)ob2->query("combat_exp") - (int)ob1->query("combat_exp");
}

int help()
{
write(@HELP
指令格式 : chagold

这个指令可以列出所有在线上的玩家的金钱以及身上物品的数量。

相关指令： finger, who
HELP
    );
    return 1;
}

