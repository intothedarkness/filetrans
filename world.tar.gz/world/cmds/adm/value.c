// CMDS /cmds/usr/value.c
// Created by waiwai@2001/06/05
// 原本为了工作方便做此指令
// 后因觉得有必要下放，所以下放给玩家

#include "/doc/help.h"
#include <command.h>

inherit F_CLEAN_UP;

int main(object me, string arg)
{
	string option, target, msg, desc, banghui;
	object obj, area;

	if (me!=this_player(1)) return 0;

	seteuid( geteuid(me) );

	if (!arg) return notify_fail("指令格式 : value <物件ID>\n" );

	if( sscanf(arg, "%s %s", option, target)!=2 ) target = arg;

	// 巫师允许以路径查看物件
	if( wizardp(me) ) {
	obj = find_object(target);
	if (!obj) obj = present(target, me); // 自身携带
	if (!obj) obj = present(target, environment(me)); // 同一房间
	if (!obj) obj = find_object( resolve_path(me->query("cwd"), target) ); // 路径模式
	if (!obj) return notify_fail("没有这样物件。\n");
	} else { // 玩家只能查看自身的
	if (!obj) obj = present(target, me);
	if (!obj) return notify_fail("你身上没有这样物件。\n");
	}

	if( obj->is_character() )
       	return notify_fail("看清楚一点，那不是一个物品！！！\n");

	desc = obj->query("name")+"("+obj->query("id")+")";

	// 以细致模式设置查看物品的价值
	if( obj->query("value") &&  !obj->query("base_value") ) 
	msg = sprintf( "\n%s的价值为 →  每%s%s\n"NOR,
		desc, obj->query("unit"), MONEY_D->money_num( obj->query("value") ) );
	else
//	if( obj->value() ) 
//	msg = sprintf( "\n%s的价值为 →  每%s%s\n",
//		desc, obj->query("unit"), MONEY_D->money_num( obj->value() ) );
	if( obj->query("base_value") ) {
	if( (int)obj->query_amount() == 1 )
	msg = sprintf( "\n%s的价值为 →  每%s%s\n"NOR,
		desc, obj->query("base_unit"), MONEY_D->money_num( obj->query("base_value") ) );
	else
	if( (int)obj->query_amount() > 1 )
	msg = sprintf( "\n%s的价值为 →  %d%s总值%s\n"NOR,
		desc, (int)obj->query_amount(), obj->query("base_unit"), 
		MONEY_D->money_num( obj->query("value")*(int)obj->query_amount() ) );
	}
	else
	msg = sprintf( "\n%s目前未设价值。\n"NOR, desc);
	msg+= "──────────────────────────\n";
	if( obj->query_autoload() ) msg+= desc+"目前设定为：离线不掉。\n";
	if( obj->query("deadfly") ) msg+= desc+"目前设定为：死亡消失。\n";
	if( obj->query("des") ) msg+= desc+"目前设定为：仍掉消失。\n";
	if( obj->query("no_sell") ) msg+= desc+"目前设定为：不能买卖。\n";
	if( obj->query("no_get") ) msg+= desc+"目前设定为：不能拾获。\n";
	if( obj->query("no_give") ) msg+= desc+"目前设定为：不能给人。\n";
	if( obj->query("no_drop") ) msg+= desc+"目前设定为：不能扔弃。\n";
	if( obj->query("no_steal") ) msg+= desc+"目前设定为：不能被偷。\n";
	if( obj->query("no_remove") ) msg+= desc+"目前设定为：不能脱掉。\n";
	if( obj->query("no_break") ) msg+= desc+"目前设定为：不会破损。\n";
	if( obj->query("combine") ) msg+= desc+"目前设定为：组合物件属性。\n";
	if( obj->query("no_put") ) msg+= desc+"目前设定为：不能放到容器。\n";
	if( obj->query("no_putto") ) msg+= desc+"目前设定为：不能进行捐献。\n";
	if( obj->query("no_stock") ) msg+= desc+"目前设定为：不能放到黑店。\n";
	if( obj->query("no_putin") ) msg+= desc+"目前设定为：不能放到保险库。\n";
	if( obj->query("can_putin") ) msg+= desc+"目前设定为：可以放到保险库。\n";
	if( obj->query("keep_this") ) msg+= desc+"目前设定为：记号属性物件。\n";
	if( obj->query("can_be_enchased") ) msg+= desc+"目前设定为：可镶嵌属性物件。\n";
	if( obj->query("can_auction") ) msg+= desc+"目前设定为：可合并属性物件。\n";
	if( obj->query("hide") ) msg+= desc+"目前设定为：可召唤隐藏物件。\n";

	if( obj->query("female_only") ) {
		if( me->query("gender")!="女性"  )
		msg+= desc+"目前设定为：女性专用。你不能使用。\n";
		else
		msg+= desc+"目前设定为：女性专用。你可以使用。\n";
	}

	if( obj->query("wiz_only") ) {
		if( !wizardp(me) )
		msg+= desc+"目前设定为：巫师专用。你不能使用。\n";
		else
		msg+= desc+"目前设定为：巫师专用。你可以使用。\n";
	}

	if( obj->query("npc_only") ) {
		if( !wizardp(me) && userp(me) )
		msg+= desc+"目前设定为：NPC专用。你不能使用。\n";
		else
		msg+= desc+"目前设定为：NPC专用。你可以使用。\n";
	}

	if( obj->query("owner_id") ) {
		if( obj->query("owner_id")!=getuid(me) )
		msg+= desc+"目前设定为："+obj->query("owner_id")+"私有物件，你不能使用。\n";
		else
		msg+= desc+"目前设定为："+obj->query("owner_id")+"私有物件，你可以使用。\n";
	}

	if( obj->query("self_id") ) {
		if( obj->query("self_id")!=getuid(me) )
		msg+= desc+"目前设定为："+obj->query("self_id")+"私有物件，你不能使用。\n";
		else
		msg+= desc+"目前设定为："+obj->query("self_id")+"私有物件，你可以使用。\n";
	}

	if( obj->query("vip_only") ) {
		if( !me->query("vip")  )
		msg+= desc+"目前设定为：VIP专用物件，你不能使用。\n";
		else
		msg+= desc+"目前设定为：VIP专用物件，你可以使用。\n";
	}

	if( obj->query("family_only") ) {
		if( me->query("family/family_name") != obj->query("family_only") )
		msg+= desc+"目前设定为："HIR+obj->query("family_only")+NOR"门派专用物件。\n";
		else
		msg+= desc+"目前设定为："HIG+obj->query("family_only")+NOR"门派专用物件。\n";
	}
/*
       area=new("/obj/area");
	area->create(obj->query("area_name"));
      	obj->set("banghui",(string)area->query("banghui"));
       destruct(area);
	banghui=(string)obj->query("banghui");
*/
	if( obj->query("area_name") ) {
		if( me->query("banghui")!=obj->query("area_name") ) 
		msg+= desc+"目前设定为："HIR+obj->query("area_name")+NOR"地盘所属物件。\n";
		else
		msg+= desc+"目前设定为："HIG+obj->query("area_name")+NOR"地盘所属物件。\n";
	}

	if( obj->query("owner_id") ) {
		if( me->query("id")!=obj->query("owner_id") ) 
		msg+= desc+"目前设定为："HIR+obj->query("owner_id")+NOR"个人所属物件。\n";
		else
		msg+= desc+"目前设定为："HIG+obj->query("owner_id")+NOR"个人所属物件。\n";
	}

	if( obj->query("need_xz") ) {
		if( me->query("12_xz") != obj->query("need_xz") )
		msg+= desc+"目前设定为：需要星座"HIR+obj->query("need_xz")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要星座"HIG+obj->query("need_xz")+NOR"。\n";
	}

	if( obj->query("need_force") ) {
		if( me->query("max_force") < obj->query("need_force") )
		msg+= desc+"目前设定为：需要最大内力"HIR+obj->query("need_force")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要最大内力"HIG+obj->query("need_force")+NOR"。\n";
	}

	if( obj->query("need_mana") ) {
		if( me->query("max_mana") < obj->query("need_mana") )
		msg+= desc+"目前设定为：需要最大法力"HIR+obj->query("need_mana")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要最大法力"HIG+obj->query("need_mana")+NOR"。\n";
	}

	if( obj->query("keepto") ) {
	if( log_id(me) != obj->query("keepto") )
		msg+= desc+"目前设定为：被记号给"HIR+obj->query("keepto")+NOR"物件。\n";
		else
		msg+= desc+"目前设定为：被记号给"HIG+obj->query("keepto")+NOR"物件。\n";
	}


	if( obj->query("need_zhongzu") ) {
		if( me->query("zhongzu") != obj->query("need_zhongzu") )
		msg+= desc+"目前设定为：需要种族"HIR+obj->query("need_zhongzu")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要种族"HIG+obj->query("need_zhongzu")+NOR"。\n";
	}

	if( obj->query("need_class") ) {
		if( me->query("occupation") != obj->query("need_class") )
		msg+= desc+"目前设定为：需要职业"HIR+obj->query("need_class")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要职业"HIG+obj->query("need_class")+NOR"。\n";
	}

	if( obj->query("need_sx") ) {
		if( me->query("12_sx") != obj->query("need_sx") )
		msg+= desc+"目前设定为：需要生肖"HIR+obj->query("need_sx")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要生肖"HIG+obj->query("need_sx")+NOR"。\n";
	}


	if( obj->query("need_ultimate") ) {
		if( me->query("ultimate") != obj->query("need_ultimate") )
		msg+= desc+"目前设定为：需要五行"HIR+obj->query("need_ultimate")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要五行"HIG+obj->query("need_ultimate")+NOR"。\n";
	}

	if( obj->query("need_str") ) {
		if( me->query_str() < obj->query("need_str") )
		msg+= desc+"目前设定为：需要力量"HIR+obj->query("need_str")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要力量"HIG+obj->query("need_str")+NOR"。\n";
	}

	if( obj->query("need_spi") ) {
		if( me->query_spi() < obj->query("need_spi") )
		msg+= desc+"目前设定为：需要灵性"HIR+obj->query("need_spi")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要灵性"HIG+obj->query("need_spi")+NOR"。\n";
	}

	if( obj->query("need_level") ) {
		if( me->query("level") < obj->query("need_level") )
		msg+= desc+"目前设定为：需要等级"HIR+obj->query("need_level")+NOR"。\n";
		else
		msg+= desc+"目前设定为：需要等级"HIG+obj->query("need_level")+NOR"。\n";
	}


	if( obj->query("make_time") ) msg+= desc+"出产日期为："+obj->query("make_time")+"。\n";
	if( obj->query("weapon_prop") && me->query("kusong_max_spear") ) 
	msg+= desc+"隐含攻击力为："+me->query("kusong_max_spear")+"。\n";

	if( obj->query("can_insert_hold") ) msg+= desc+"目前可打孔数："+obj->query("can_insert_hold")+"个。\n";

	msg+= "──────────────────────────\n";

	write(msg);

	return 1;
}

int help(object me)
{
	write(@HELP

指令格式 : value <物件ID>

物件属性指令。

利用此一指令可将一个物件的实际价值显示出来。
并且可以将一个物件的大部分附属的属性显示出来。
所查看的物品只能是自身携带的物件属性物品。

相关指令：look，keep，keepto

Created by waiwai@2002/12/05

HELP
    );
    return 1;
}
