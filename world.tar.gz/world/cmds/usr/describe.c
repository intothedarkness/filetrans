//Cracked by Roath
// modified by xfile@bjxyj
// purpose: 	for mutiline description inputing.
// date:	2004.11.25
// 
// describe.c

#include "ansi.h"

inherit F_CLEAN_UP;

int editing( object me, string des_str )
{
	string *txt = explode(des_str, "\n");
	if( (wizardp(me) && sizeof(txt) > 20) || sizeof(txt) > 8 )
	{
		write("对不起，请将您对自己的描述控制在八行以内。\n");
		return -1;
	}
		
	des_str = replace_string(des_str, "$BLK$", BLK);
        des_str = replace_string(des_str, "$RED$", RED);
        des_str = replace_string(des_str, "$GRN$", GRN);
        des_str = replace_string(des_str, "$YEL$", YEL);
        des_str = replace_string(des_str, "$BLU$", BLU);
        des_str = replace_string(des_str, "$MAG$", MAG);
        des_str = replace_string(des_str, "$CYN$", CYN);
        des_str = replace_string(des_str, "$WHT$", WHT);
        des_str = replace_string(des_str, "$HIR$", HIR);
        des_str = replace_string(des_str, "$HIG$", HIG);
        des_str = replace_string(des_str, "$HIY$", HIY);
        des_str = replace_string(des_str, "$HIB$", HIB);
        des_str = replace_string(des_str, "$HIM$", HIM);
        des_str = replace_string(des_str, "$HIC$", HIC);
        des_str = replace_string(des_str, "$HIW$", HIW);
        des_str = replace_string(des_str, "$NOR$", NOR);
        
	me->set("long", des_str + NOR);
	write("Ok.\n");
}

int main(object me, string arg)
{
	if ( !arg || arg != "start" )
	{
		return notify_fail("指令格式：describe start 开始自己的描述\n"
		"注意：请将您对自己的描述控制在八行以内\n");
	} 
        // start to edit.
       	this_player()->edit( (: editing, this_player() :) );
	return 1;
}


int help()
{
	write(@TEXT
指令格式：describe start开始自己的描述

这个指令让你设定当别人用 look 指令看你时，对你的描述。
例如：$HIY$此人正是传说中看不见，摸不到，江湖人称 没有人$NOR$
TEXT
	);
	return 1;
}
