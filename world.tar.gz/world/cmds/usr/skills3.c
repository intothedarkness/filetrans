#include <ansi.h>

inherit F_CLEAN_UP;

int main(object me, string arg)
{
	object ob;
	mapping skl, lrn, map;
	string *sname, *mapped, banghui, tianfu;
	string k_name="", e_name="", o_name="", msg="";
	int i,k=0,e=0,o=0, sk;

	seteuid(getuid());

	if(!arg)
		ob = me;
	else {
		ob = present(arg, environment(me));
		if (!ob) ob = find_player(arg);
		if (!ob) ob = find_living(arg);
	       if (!ob) return notify_fail("你要察看谁的武功技能状态？\n");
	}
	if( ob!=me && !wizardp(me) 
	&& !ob->is_apprentice_of(me) 
	&& !me->is_apprentice_of(ob) 
	&& (!userp(ob) || getuid(ob)!=me->query("bonze/dadangid"))
	&& (!userp(ob) || getuid(ob)!=me->query("couple/id")))
		return notify_fail("只有巫师或有师徒关系的人能察看他人的技能。\n");


	if( wiz_level(me) < wiz_level(ob) )
		return notify_fail("你要察看谁的武功技能状态？\n");

	skl = ob->query_skills();

	
	if(!sizeof(skl)) {
		write( (ob==me ? "你" : ob->name()) + "目前并没有学会任何技能。\n");
		return 1;
	}

	write("                          〓〓  "+ob->name(1)+" 所学技能表  〓〓\n"
		NOR"┏━━━━━━━━━━━━━━━━━━━━━━┯━━━━┯━━┯━━━━━━━━┓\n"
		   "┃"YEL"       名               称"NOR
"                  │"YEL" 描  述"NOR" │"YEL"等级"NOR"│"YEL"   经 验 点 数"NOR"  ┃\n"
		   "┠──────────────────────┴────┴──┴────────┨\n");

	sname  = sort_array( keys(skl), (: strcmp :) );

	map = ob->query_skill_map();
	if( mapp(map) ) mapped = values(map);
	if( !mapped ) mapped = ({});

	lrn = ob->query_learned();
	if( !mapp(lrn) ) lrn = ([]);

	for(i=0; i<sizeof(skl); i++) {
	sk = lrn[sname[i]]*100/((skl[sname[i]]+1)*(skl[sname[i]]+1));

	if( SKILL_D(sname[i])->type()=="knowledge" ) {
//	k_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d/%8d┃\n",
	k_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d - [%3d%%]┃\n",

	(member_array(sname[i], mapped)==-1? "  ": HIR"√"NOR),
	(lrn[sname[i]] >= (skl[sname[i]]+1) * (skl[sname[i]]+1)) ? HIR : "",
	to_chinese(sname[i]) + " (" + sname[i] + ")",
	SKILL_D(sname[i])->level_description(skl[sname[i]]),
	skl[sname[i]], (int)lrn[sname[i]],sk);

	k+=1;
	}
	else if ( function_exists("valid_enable", find_object(SKILL_D(sname[i]))) ) {
//	e_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d/%8d┃\n",
	e_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d - [%3d%%]┃\n",

	(member_array(sname[i], mapped)==-1? "  ": HIR"√"NOR),
	(lrn[sname[i]] >= (skl[sname[i]]+1) * (skl[sname[i]]+1)) ? HIR : "",
	 to_chinese(sname[i]) + " (" + sname[i] + ")",
	SKILL_D(sname[i])->level_description(skl[sname[i]]),
	skl[sname[i]], (int)lrn[sname[i]],	sk);

	e+=1;
	 } else {
//	o_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d/%8d┃\n",
	o_name+=sprintf("┃"NOR" %s%s%-40s" NOR " - %-10s %5d %8d - [%3d%%]┃\n",

	(member_array(sname[i], mapped)==-1? "  ": HIR"√"NOR),
	(lrn[sname[i]] >= (skl[sname[i]]+1) * (skl[sname[i]]+1)) ? HIR : "",
	to_chinese(sname[i]) + " (" + sname[i] + ")",
	SKILL_D(sname[i])->level_description(skl[sname[i]]),
	skl[sname[i]], (int)lrn[sname[i]],sk);

	o+=1;
	}

	}
	if( k>0 ) {
	msg+="┣━━━━━━━━━━━━━━━━"+((k<12)?(""+chinese_number(k)):(chinese_number(k)))+
	"项知识技能"NOR"━━━━━━━━━━━━━━━━━┫\n"NOR;
	msg+=k_name;
	}
	if( k<1 && e>0 ) {
	msg+="┣━━━━━━━━━━━━━━━━"+((e<12)?(""+chinese_number(e)):(chinese_number(e)))+
	"项特殊技能"NOR"━━━━━━━━━━━━━━━━━┫\n"NOR;
	msg+=e_name;
	}
	if( k>0 && e>0 ) {
	msg+="┣━━━━━━━━━━━━━━━━"+((e<12)?(""+chinese_number(e)):(chinese_number(e)))+
	"项特殊技能"NOR"━━━━━━━━━━━━━━━━━┫\n"NOR;
	msg+=e_name;
	}
	if( k<1 && e<1 ) {
	msg+="┣━━━━━━━━━━━━━━━━"+((o<12)?(""+chinese_number(o)):(chinese_number(o)))+
	"项基本技能"NOR"━━━━━━━━━━━━━━━━━┫\n"NOR;
	msg+=o_name;
	}
	if( (k>0 || e>0) && o>0) {
	msg+="┣━━━━━━━━━━━━━━━━"+((o<12)?(""+chinese_number(o)):(chinese_number(o)))+
	"项基本技能"NOR"━━━━━━━━━━━━━━━━━┫\n"NOR;
	msg+=o_name;
	}
	msg+="┗━━━━━━━━━━━━━━━━ [ "HIR"西游记"NOR" ] ━━━━━━━━━━━━━━━━━┛\n"NOR;
	if( userp(me) && userp(ob) ) {
	msg+=" "+(ob==me ? "你" : ob->name(1))+"目前共学过"+chinese_number(k+e+o)+"项技能 \n"NOR;
	}
	else
	msg+=ob->name(1)+"目前共拥有"+chinese_number(k+e+o)+"项技能 \n";
       
	write(msg);
	return 1;
}

int help(object me)
{
        write(@HELP

指令格式 : skills/sk [<某人>]

这个指令可以让你查询自己所学过的武功技能的综合情况

你也可以指定一个和你有师徒，夫妻关系的对象
用 skills 可以查知对方的武功技能状况。

HELP
    );
    return 1;
}