//modify by huadao.2010.9.10


#include <ansi.h>
inherit F_CLEAN_UP;
string *npc_banghui=({
	"明教",
	"日月教",
	"天地会",
	"丐帮",
});


int main(object me, string arg)
{
	mixed *dir;
	string *id;
	mapping data;
	object lingpai;
	string msg,banghui;
	int i;
	if(! arg)	{
	dir=get_dir("/data/guild/",0);
	if(! dir)	return notify_fail("目前没有任何帮会。\n");
	msg=sprintf("%-16s%-16s%-10s%-10s%-10s\n",
		"帮会名称","帮主","帮众数","NPC数","城堡数");
	msg+="\n------------------------------------------------------------\n";
	lingpai=new("/obj/lingpai");
	for(i=0;i<sizeof(dir);i++)	{
		if(sscanf(dir[i],"%s.o",banghui)==1)	{
			lingpai->create(banghui);
//			msg+=sprintf("%-16s%-10s%-10d%-10d%-10d\n",
			msg+=sprintf("%s%-16s%-16s%-10d%-10d%-10d""\n",
			member_array(banghui,npc_banghui)!=-1?HIG:"",
			banghui,lingpai->query("bangzhu"),sizeof(lingpai->query("player")),sizeof(lingpai->query("npc")),sizeof(lingpai->query("area")));
	}
	}
	destruct(lingpai);
	msg+="\------------------------------------------------------------\n";
	}
	else if(arg =="-l")	{
		if(! (banghui=me->query("banghui")))
		return notify_fail("你没有参加任何帮会，无法显示具体细节。\n");
		lingpai=new("/obj/lingpai");
		lingpai->create(banghui);
		if(lingpai->query("no_use"))	{
		destruct(lingpai);
		return notify_fail("你的帮会文件有问题，请与巫师联系。\n");
		}
		msg="「"+banghui+"」帮会成员\n";
	msg+="\n------------------------------------------------------------\n";
		data=lingpai->query("player");
		if(! mapp(data))	data=([]);
		id=keys(data);
		for(i=0;i<sizeof(id);i++)	{
			msg+=sprintf("%-32s%s",data[id[i]]+"("+id[i]+")",
			(i%2==1? "": "\n"));
		}
		destruct(lingpai);
	msg+="\n------------------------------------------------------------\n";
	}
	else	return notify_fail("命令格式：banghui [-l]\n");
	me->start_more(msg);
	return 1;
}



int help(object me)
{
        write(@HELP
指令格式：banghuix [-l]
本指令用来显示目前所有帮会状况。
使用-l参数可查看所在帮会详细资料。
HELP
        );
        return 1;
}
