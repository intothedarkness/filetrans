//Cracked by Roath
// finger.c
// modified by xigua@dhxy 2000 5 13
#include <ansi.h>
inherit F_CLEAN_UP;

void create()
{
	seteuid(getuid());
}

int main(object me, string arg)
{       object ob,ob1;
	
	        if( time()-(int)me->query_temp("finger_end") < 30&& !wizardp(me) )
                return notify_fail(WHT"防止系统负担过重，请在30秒后使用此命令！\n"NOR);
	if( !arg ) {
		if( (int)me->query("sen") < 50 )
			return notify_fail("你的精神无法集中。\n");
    
    if ( time() - me->query_temp("finger_time") < 60 )
      return notify_fail("请稍候再尝试本命令!\n");
		
		if( !wizardp(me) )
			me->receive_damage("sen", 50);
		me->start_more( FINGER_D->finger_all() );
//		write( FINGER_D->finger_all() );
	} else {
	    
	    // mon 9/1/98 the following chars will cause an error.
	    arg=replace_string(arg,"#"," ");
	    arg=replace_string(arg,"."," ");

		if( !wizardp(me)&&(int)me->query("sen") < 15 && time()-me->query_temp("finger_time")<30  )
			return notify_fail("你的精神无法集中。\n");
		if( !wizardp(me) )
			me->receive_damage("sen", 15);
	        ob1 = LOGIN_D->find_body(arg);
		if(ob1&&ob1->query("env/no_finger")) return notify_fail("没有这个玩家。\n");
		write( FINGER_D->finger_user(arg) );
	        ob=find_player(arg);
                if (ob&&me->visible(ob)&&(me!=ob)) {
			if (wizardp(ob)&&wiz_level(ob)>=wiz_level(me))
				tell_object(ob,NOR+me->short(1)+"正在探听你的消息!\n"NOR);                 
			else
               if(!wizardp(me)) tell_object(ob,NOR"啊....嚏...,你打了一个大喷嚏，好像有人在想你了。\n"NOR);
			
		}
	}

        me->set_temp("finger_end",time());
	return 1;
}

int help(object me)
{
  write(@HELP
指令格式： finger
           finger [使用者英文代号]
           finger [使用者英文代号]@Mudname
 
这个指令，如果没有指定使用者姓名，会显示出所有正在线上玩家
的连线资料。反之，则可显示有关某个玩家的连线，权限等资料。
 
see also : who, mudlist
HELP
    );
    return 1;
}
 
