//modify by huadao.2010.9.10
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object me, string arg)
{
	string banghui,bangzhu_id,msg;
	object lingpai;
	if(me->is_fighting()||me->is_busy())
		return notify_fail("你正忙着呢。\n");
	if(! (banghui=me->query("banghui")))
		return notify_fail("你没有参加任何帮会，无需脱离。\n");
	if(! arg)
		return notify_fail("你要脱离什么帮会？\n");
	if(arg != banghui)
		return notify_fail("你不是这个帮会的成员。\n");
        lingpai=new("/d/bangpai/obj/lingpai");
        lingpai->create(banghui);
        if(lingpai->query("no_use"))    {
                destruct(lingpai);
                return notify_fail("你的帮会文件有问题，请与巫师联系。\n");
        }
	if(me->query("id")==lingpai->query("bangzhu_id"))	{
		msg="你是帮会「"+me->query("banghui")+"」的帮主，脱离前最好指定新任帮主！\n";
		msg="脱离帮会将会损失一百年道行和十万武学！\n";
	}
	else	msg="你是帮会「"+me->query("banghui")+"」的帮众。\n";
			msg="脱离帮会将会损失一百年道行和十万武学！\n";
	msg +="你真的要脱离吗(y/n)？";
	write(msg);
	destruct(lingpai);
	input_to("yes_or_no",me,banghui);
	return 1;
}

int yes_or_no(string str,object me,string banghui,string bangzhu_id,string msg)
{
	mapping data;
	object lingpai;
	str=lower_case(str);
	if(str=="y"||str=="yes")	{
		lingpai=new("/d/bangpai/obj/lingpai");

        lingpai->create(banghui);
		if( lingpai->query("no_use"))	{
			destruct(lingpai);
			return notify_fail("你的帮会文件有问题，请与巫师联系。\n");
		}
		if(userp(me))	data=lingpai->query("player");
		else	data=lingpai->query("npc");
		if(! mapp(data))	data=([]);
		map_delete(data,me->query("id"));
		if(userp(me))	lingpai->set("player",data);
		else	lingpai->set("npc",data);
		if(me->query("id")==lingpai->query("bangzhu_id"))	{
			lingpai->set("bangzhu_id","???");
			lingpai->set("bangzhu","???");
		}
	   message_vision(YEL"$N脱离了「"+banghui+"」。\n"NOR,me);
       message("channel:rumor",YEL"【帮会势力】"+me->query("name")+"脱离了"+
                "帮会「"HIW+banghui+NOR+YEL"」！\n"NOR,users());
	me->add("daoxing",-100000);
	me->add("combat_exp",-100000);
	if (me->query("daoxing") < 0 )
		me->set("daoxing",0);
	if (me->query("combat_exp") < 0 )
		me->set("combat_exp",0);


	me->delete("banghui");
	if(!undefinedp(me->query("score")))
		me->delete("score");
	if(!undefinedp(me->query("bh_rank")))
		me->delete("bh_rank");
	if(!undefinedp(me->query("rank_lv")))
		me->delete("rank_lv");
	if(!undefinedp(me->query("title")))
		me->set("title",RED+banghui+"叛徒"NOR);
       me->save();
	lingpai->save();
	   msg="你脱离了「"+me->query("banghui")+"」。\n";

	if(! sizeof(lingpai->query("player")) && 
		! sizeof(lingpai->query("npc")))	{
		rm("/data/guild/"+banghui+".o");
		message("channel:rumor",YEL"【帮会势力】帮会「"HIW+banghui+NOR+YEL
                        "」土崩瓦解了！\n"NOR,users());
	}
	destruct(lingpai);
	return 1;
	}
	write("好吧，请想清楚后再做决定．\n");
	return 1;
}
int help(object me)
{
        write(@HELP
指令格式：tuoli <帮会名称>
这个指令可以使你脱离帮会,前提是你必须是该帮会成员。
脱离帮会将会损失玩家十万武学和一百年道行。
HELP
        );
        return 1;
}
