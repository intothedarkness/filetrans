// Last Modified By Pkyou@xyj 2002-06-12 19:00
//2010.06.20 huadao.
inherit F_CLEAN_UP;

#include <ansi.h>
// #include <dntg.h>
#include <dntg.h>

int telling1 (object who);
int telling2 (object who);
int telling3 (object who);
int telling4 (object who);

string name;

int main(object me, string arg)
{
        object ob;

        if( !arg ) {
                ob = me;
                name = "你";
        } else if (wizardp (me)) {
                ob = find_player(arg);
                if(!ob) ob = find_living(arg);
                if(!ob) ob = LOGIN_D->find_body(arg);
                if(!ob || !me->visible(ob)) return notify_fail("没有这个人。\n");
                name = ob->query("name");
        } else
                return 0;

        telling1(ob);
        telling2(ob);
        telling3(ob);
//        telling4(ob);
        
        return 1;
}

int help()
{
        write(@TEXT
指令格式：obstacles <某人>

显示某人西行求取真经的资料。 

请见：help qujing
TEXT
        );
        return 1;
}

int telling1 (object who)
{
  int size = sizeof(obstacles);
  string *names = keys(obstacles);
  string *strs = allocate (size);
  int nb = 0;
  int i;

  for (i = 0; i < size; i++)
  {
    strs[i] = "none";
  }

  for (i = 0; i < size; i++)
  {
    if (who->query("dntg/"+names[i])=="done")
    {
      strs[nb] = obstacles[names[i]];
      nb++;
    }
  }
  if (nb == 0)
  {
    write (name+"还没有做过大事。\n");
  }
  else
  {
    write (name+"大闹天宫已经过了"+chinese_number(nb)+"关：\n");
    who->set("dntg/number",nb);
    strs = (string *)sort_array (strs, 1);
    for (i = 0; i < nb; i++)
    {
      write ("    "+strs[i]+"\n");
    }
  }
  return 1;
}

int telling2 (object who)
{
  int size = sizeof(obstacles);
  string *names = keys(obstacles);
  string *strs = allocate (size);
  int nb = 0;
  int i;

  for (i = 0; i < size; i++)
  {
    strs[i] = "none";
  }

  for (i = 0; i < size; i++)
  {
    if (who->query("dntg/"+names[i])!="done")
    {
      strs[nb] = obstacles[names[i]];
      nb++;
    }
  }

  if (nb == 0)
  {
    write (name+"大闹天宫已经功德圆满。\n");
  }
  else
  {
    write (name+"大闹天宫还须过"+chinese_number(nb)+"关：\n");
    strs = (string *)sort_array (strs, 1);
    for (i = 0; i < nb; i++)
    {
      write ("    "+strs[i]+"\n");
    }
  }
  return 1;
}

int telling3 (object who)
{

  if (who->query("dntg/wuxingshan")=="done")
  {
    write (name+"已经开启了取经任务。\n");
  }
  else
  {
    write (name+"还没有开启取经任务。\n");
  }
  return 1;
}
/*
int telling4 (object who)
{
  int size = sizeof(obstacle1);
  string *names = keys(obstacle1);
  string *strs = allocate (size);
  int nb = 0;
  int i;

  for (i = 0; i < size; i++)
  {
    strs[i] = "none";
  }

  for (i = 0; i < size; i++)
  {
    if (who->query("dntg/"+names[i])!="done")
    {
      strs[nb] = obstacle1[names[i]];
      nb++;
    }
  }

  if (nb == 0)
  {
    write (name+"你已经开始西行取经了。\n");
  }
  else
  {
    write (name+"要西天取经还须过"+chinese_number(nb)+"道劫难：\n");
    strs = (string *)sort_array (strs, 1);
    for (i = 0; i < nb; i++)
    {
      write ("    "+strs[i]+"\n");
    }
  }
  return 1;
}
*/