// Verify-Skill.c
// Created by Rocky@XYJ-CN
// 2015 March

#include <ansi.h>
#include <skill.h>

inherit F_CLEAN_UP;
#define DEBUG 0 
#define C_LINE  "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"

// all the base skills set.
string* valid_base_type = ({
        "unarmed",
        "sword",
        "blade",
        "dagger",
        "spear",
        "stick",
        "staff",
        "throwing",
        "whip",
        "axe",
        "hammer",
        "force",
        "dodge",
        "parry",
        "zouxiao",
        "spells",
        "fork",
        "mace",
        "rake",
        "stealing",
        "smoking",
});

// helper function retrieves all valid enables.
string get_valid_enables(object skill)
{
    int i;
    string valid_enables = "";
    
    for (i = 0; i < sizeof(valid_base_type); i++)
    {
        if (skill->valid_enable(valid_base_type[i]))
        {
            valid_enables += sprintf("%-14s ", to_chinese(valid_base_type[i]) 
            + "(" + valid_base_type[i] + ")");            
        }
    }
    return valid_enables;
}

int main(object me, string arg)
{
    string  file, dir, filename;
    string  msg, msg1;        
    int     i, l, is_force, is_spells;
    int     special_attack;
    mixed   *all_file;     
    object  sk;
    string  enable;

    // zero init the flags.
    is_spells = 0;
    is_force = 0;

    seteuid(getuid());

    // get the right input.
    if (!arg)
        return notify_fail("指令格式：verify-skill <技能名称>\n");

    if (!stringp(file = SKILL_D(arg)) || file_size(file + ".c") <= 0)
        return notify_fail("没有这种技能。\n");

    // start to proceed...
    msg = to_chinese(arg) + "(" + arg + ")的详细属性：\n";
    msg += C_LINE;
    msg += "  技能名称：  " + to_chinese(arg) + "(" + arg + ")\n";

    if (SKILL_D(arg)->valid_enable("force"))
    {
        is_force = 1;
    }
    if (SKILL_D(arg)->valid_enable("spells"))
    {
        is_spells = 1;
    }

#if DEBUG
    printf("arg = %s\n", arg);
#endif

    sk = get_object(SKILL_D(arg));
    enable = get_valid_enables(sk);

#if DEBUG
    printf("enable = %s\n", enable);
#endif

    if (enable != "")
    {
        msg += "\n  技能用途：  " + enable + "\n";
    }

    // double check about the if it is really no valid_enable.
    // might be necessary sometime.
    if (!function_exists("valid_enable", find_object(SKILL_D(arg))))
    {
        msg += "\n  技能种类：  基本技能\n";
        msg += C_LINE;
        write(msg);
        return 1;
    }
    else
    {
        msg +=  "\n  技能种类：  特殊技能\n";
    }
    
    msg1 = "";
    special_attack = 0;

    // call the SKILL_D->xxx to get the directory name.
    // feed the input args with "", kind of hacky here.
    if (1 == is_spells)
    {
        dir = SKILL_D(arg)->cast_spell_file("");
        // baguazhou is a special case, make a hack here,
        // and no skill actually uses conjure_magic_file() in XYJ yet.
        if(!dir)
        {
            dir = SKILL_D(arg)->scribe_spell_file("");
        }
    }
    else if(1 == is_force)
    {
        dir = SKILL_D(arg)->exert_function_file("");
    }
    else
    {
        dir = SKILL_D(arg)->perform_action_file("");
    }
    
#if DEBUG
    // this 2 flag can't be true at same time, they should be 
    // mutually exclusive 
    printf("is_spells = %d is_force = %d\n", is_spells, is_force);
    printf("dir = %s\n", dir);
#endif
    
    if (!dir)
    {
        msg1 += "";
    }
    else
    {
        all_file = get_dir(dir);
        if (! sizeof(all_file))
        {
            msg1 += "";
        }
        else
        {
            for (i = 0; i < sizeof(all_file); i++)
            {
                filename = all_file[i];
                l = strlen(filename);
                if (filename[l - 1] == 'c' && filename[l - 2] == '.')
                {
                    // format the message.
                    special_attack++;
                    msg1 += (1 == special_attack ? 
                             sprintf("%d. ", special_attack) :
                             sprintf("              %d. ", special_attack));
                    
                    if (1 == is_spells)
                    {
                        msg1 += "cast ";
                    }
                    else if(1 == is_force)
                    {
                        msg1 += "exert ";
                    }
                    else
                    {
                        msg1 += "perform "; 
                    }
                    
                    msg1 += sprintf("%s\n", filename[0..l - 3]);
                }
            }

            if (msg1 != "")
            {  
                if (1 == is_spells)
                {
                    msg += "\n  特效法术：  ";
                }
                else if(1 == is_force)
                {
                    msg += "\n  特效内功：  ";
                }
                else
                {
                    msg += "\n  特效攻击：  ";
                }
                
                msg += msg1;
            }
        }
    }
    msg += C_LINE;
    
    // print'em out.
    write(msg);    
    return 1;
}

int help(object me)
{
        write(@HELP
指令格式：verify-skill <技能名称>

这个指令允许玩家查看指定的技能的特效用途。

相关指令：skills

HELP);
        return 1;
}

