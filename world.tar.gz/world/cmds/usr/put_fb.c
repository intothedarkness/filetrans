// -------------------------------------------------------------------
// put_fb.c
//
// the reason of creating this file is I really do not want to
// mess up the existing command ji.c, the special fabao is now
// some kind of property instead of real item.
// 2015 4.8
// -------------------------------------------------------------------

#include <ansi.h>
inherit F_CLEAN_UP;

#define FABAO_SUIPIAN_PROP              "fabao_system/suipian/"
#define FABAO_FABAO_PROP                "fabao_system/fabao/"
#define OBJ_DIR                         "/services/sys/task/mieyao/obj/"
#define MSG_CREATE_FB                   "你从锦囊里取出一件%s。\n"
#define MSG_CREATE_FB_FAIL              "你身上已经放不下任何东西了。\n"
#define COMMAND_TITLE                   HIC + "\n法宝锦囊里目前有：\n" + NOR
#define MSG_EMPTY_BAG                   HIC + "法宝锦囊是空的。\n" + NOR
#define FABAO_LIST_TITLE                HIC + "法宝名称                法宝数量\n" + NOR
#define FORMAT                          "%-24s%-30d\n"

#define DEBUG 0

mapping fabao_name_map = 
([
    "yinyang jing"      :  "阴阳镜",
    "feilong zhang"     :  "飞龙杖",
    "yuru yi"           :  "玉如意",
    "fuyao suo"         :  "缚妖索",
    "linglong ta"       :  "玲珑塔",
    "zhaoyao jing"      :  "照妖镜",
    "fantian yin"       :  "番天印",
    "guiqi ling"        :  "鬼泣铃",
    "hundun zhong"      :  "混沌钟",
]);

mapping fabao_file_map = 
([
    "阴阳镜" :  "yinyang-jing.c",
    "飞龙杖" :  "feilong-zhang.c",
    "玉如意" :  "yuru-yi.c",
    "缚妖索" :  "fuyao-suo.c",
    "玲珑塔" :  "linglong-ta.c",
    "照妖镜" :  "zhaoyao-jing.c",
    "番天印" :  "fantian-yin.c",
    "鬼泣铃" :  "guiqi-ling.c",
    "混沌钟" :  "hundun-zhong.c",
]);

void create() { seteuid(getuid()); }

void put_fabao(string arg)
{
    int num_of_fabaos;
    object * fabao_objs;
    int flag_of_putall = 0; 

    mapping fabao_prop = _player->query(FABAO_FABAO_PROP);
    int num_of_map = sizeof(fabao_prop);
    
    fabao_objs = all_inventory(_player);
    fabao_objs = filter_array(fabao_objs, (: $1->query("base_prop") == "fabao" :));
    num_of_fabaos = sizeof(fabao_objs);
    
    if (arg == "all")
    {
        flag_of_putall = 1;
    }
    
    for (int i = 0; i < num_of_fabaos; i++)
    {
        string fb_name = fabao_objs[i]->get_name();
        
        if (!flag_of_putall && fb_name != fabao_name_map[arg]) continue;
        
        if (!sizeof(fabao_prop))
        {
            fabao_prop = ([fabao_objs[i]->get_name() : fabao_objs[i]->query_amount()]);
        }
        else if(undefinedp(fabao_prop[fabao_objs[i]->get_name()]))
        {
            fabao_prop += ([fabao_objs[i]->get_name() : fabao_objs[i]->query_amount()]);
        }
        else
        {
            fabao_prop[fabao_objs[i]->get_name()] += fabao_objs[i]->query_amount(); 
        }
        
        printf( "你将" + chinese_number(fabao_objs[i]->query_amount()) +
             "件" + fabao_objs[i]->get_name() + "放回锦囊中。\n");
        destruct(fabao_objs[i]);
    }

    _player->set(FABAO_FABAO_PROP, fabao_prop);
}
int list_fabao()
{
    mapping fabao_prop = _player->query(FABAO_FABAO_PROP);
    int num_of_map = sizeof(fabao_prop); 
    
    if(num_of_map <= 0)
    {
        printf(MSG_EMPTY_BAG);
        return 1;
    }
    else
    {
        string  *   fabao_strings = keys(fabao_prop);
        int     *   num_of_fabao = values(fabao_prop);
        
        printf(COMMAND_TITLE);
        printf(HIC + LINE1 + NOR);
        printf(FABAO_LIST_TITLE);      
        printf(HIC + LINE2 + NOR);
        
        for (int i = 0; i < num_of_map; i ++)
        {
            printf( HIY  + FORMAT + NOR,
                fabao_strings[i] + "(" +
                (OBJ_DIR + fabao_file_map[fabao_strings[i]])->parse_command_id_list()[0] + ")",
                num_of_fabao[i]);
        }
        
        printf(HIC + LINE1 + NOR);
    }
    return 1;
}

int main(object me, string arg)
{
   if(!arg) 
        return list_fabao();
    
    put_fabao(arg);    
    list_fabao();
    
    return 1;
}

int help(object me)
{
    write(@HELP
指令格式 :  put_fb <法宝ID> | all

这个指令可以让你把一件特殊法宝放回到法宝锦囊里。

put_fb all      把所有法宝都放进锦囊
put_fb <法宝ID> 把指定法宝放进锦囊


相关指令：combine_fb, get_fb

HELP);
    return 1;
}

