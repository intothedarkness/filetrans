// ------------------------------------------------------
// combine.c (/cmds/usr/combine_fb.c)
// Created by Rocky to combine the Suipian to fabao 
// File history:
//  1. 4/4/2015 Rocky created the initial file.
//  
// ------------------------------------------------------
#include <ansi.h>

inherit F_CLEAN_UP;

#define COMMAND_TITLE                   HIC + "合并法宝\n" + NOR
#define PIECES_LIST_TITLE               HIC + "碎片种类    碎片数量    合并后法宝名称   合并后法宝数量    合并后碎片剩余\n" + NOR
#define FORMAT                          "%-12s%-12d%-17s%-18d%-17d\n"
#define FABAO_SUIPIAN_PROP              "fabao_system/suipian/"
#define FABAO_FABAO_PROP                "fabao_system/fabao/"
#define NUM_OF_SUIPIAN_PER_FABAO        10
#define COMBINE_MSG1                    HIC + "只见$N微闭双目，试着运转法力将碎片合并。\n" + NOR
#define COMBINE_MSG2                    HIW + "霎时间只见万道光华疾闪而过，$N赶紧将炼制好的法宝收入锦囊中。\n\n" NOR
#define MSG_EMPTY_BAG                   HIC + "法宝锦囊是空的。\n" + NOR
#define FABAO_LIST_TITLE                HIC + "法宝名称    法宝数量\n" + NOR
#define FORMAT_FABAO_LIST               "%-12s%-12d\n"
#define FABAO_COMMAND_TITLE             HIC + "\n法宝锦囊里目前有：\n" + NOR

void create() { seteuid(getuid()); }

// ------------------------------------------------------
mapping suipian_fabao_map = 
([
    "金碎片"  :  "阴阳镜",
    "木碎片"  :  "飞龙杖",
    "水碎片"  :  "玉如意",
    "火碎片"  :  "缚妖索",
    "土碎片"  :  "玲珑塔",
    "阴碎片"  :  "照妖镜",
    "阳碎片"  :  "番天印",
    "风碎片"  :  "鬼泣铃",
    "雷碎片"  :  "混沌钟",
]);

int list_fabao()
{
    mapping fabao_prop = _player->query(FABAO_FABAO_PROP);
    int num_of_map = sizeof(fabao_prop); 
    
    if(num_of_map <= 0)
    {
        printf(MSG_EMPTY_BAG);
        return 1;
    }
    else
    {
        string  *   fabao_strings = keys(fabao_prop);
        int     *   num_of_fabao = values(fabao_prop);
        
        printf(FABAO_COMMAND_TITLE);
        printf(HIC + LINE1 + NOR);
        printf(FABAO_LIST_TITLE);      
        printf(HIC + LINE2 + NOR);
        for (int i = 0; i < num_of_map; i ++)
        {
            
            printf( HIY  + FORMAT_FABAO_LIST + NOR,
             fabao_strings[i],
             num_of_fabao[i]);
        }
        printf(HIC + LINE1 + NOR);
    }
    return 1;

}
// print out all the possibilities.
int list_suipian()
{
    int         qualified_to_combine = 0;
    mapping     suipian_prop = _player->query(FABAO_SUIPIAN_PROP);
    int         num_of_map = sizeof(suipian_prop);    
                
    if (num_of_map > 0)
    {
        string  *   suipian = keys(suipian_prop);
        int     *   num_of_suipian = values(suipian_prop);

        printf(COMMAND_TITLE);        
        printf(HIC + LINE1 + NOR);
        printf(PIECES_LIST_TITLE);      
        printf(HIC + LINE2 + NOR);
         
        for (int i = 0; i < num_of_map; i++)
        {
            printf( HIY  + FORMAT + NOR,
                suipian[i], 
                (int)num_of_suipian[i],
                suipian_fabao_map[suipian[i]],
                (int)num_of_suipian[i] / NUM_OF_SUIPIAN_PER_FABAO,
                (int)num_of_suipian[i] % NUM_OF_SUIPIAN_PER_FABAO,
            );
            if ((int)num_of_suipian[i] / NUM_OF_SUIPIAN_PER_FABAO)
            {
                qualified_to_combine = 1;
            }
        }
        printf(HIC + LINE1 + NOR);
        
        return qualified_to_combine; 
    }
    else
    {
        printf(HIC"你现在手里没有任何法宝碎片。\n" NOR);
    }
    return 0;
}

void do_combine(string arg)
{
    mapping     suipian_prop = _player->query(FABAO_SUIPIAN_PROP);
    int         num_of_map = sizeof(suipian_prop);    
    string  *   suipian = keys(suipian_prop);
    int     *   num_of_suipian = values(suipian_prop);
    
    if( arg[0..0] == "y" || arg[0..0] == "Y" )
	{
        if(environment(_player)->query("short") != "女娲补天处")
        {
            printf("你不能在这里合并碎片。\n");
            return;
        }
        msv(COMBINE_MSG1, _player);
        
        for (int i = 0; i < num_of_map; i++)
        {
            int num_of_fabao = num_of_suipian[i] / NUM_OF_SUIPIAN_PER_FABAO;
            if(num_of_fabao > 0)
            {
                _player->add(FABAO_FABAO_PROP + suipian_fabao_map[suipian[i]], num_of_fabao);
                _player->set(FABAO_SUIPIAN_PROP + suipian[i], num_of_suipian[i] % NUM_OF_SUIPIAN_PER_FABAO);
            }
        }
        
        msv(COMBINE_MSG2, _player);
        list_suipian();
        list_fabao();
        _player->add("mana", -1000);
        _player->start_busy(5);
    }
    else 
    {
        printf(HIC + "好的，你决定放弃。\n" + NOR);
    }
}

int main(object me)
{
    if (me->is_busy())
        return notify_fail("你现在正忙。\n");

    if (me->is_fighting())
        return notify_fail("你现在正在打架，没时间做这些事情。\n");

    if(me->query("mana") < 1000)
        return notify_fail("你的法力不够了。\n");

    if(list_suipian())
    {
        printf(HIR + "你确定要合并所有碎片么?(Yes/No)\n" + NOR);
        input_to( (: do_combine :) );         
    }
    else
    {
        return notify_fail(HIR + "碎片数量不足，暂时不能合并法宝。\n" + NOR);
    }
    return 1;
}

int help(object me)
{
        write(@HELP
指令格式 : combine

这个指令可以让你将法宝碎片合并成一种新的特殊用途的法宝，并
放入锦囊中。

相关指令：get_fb, put_fb

HELP);
        return 1;
}
