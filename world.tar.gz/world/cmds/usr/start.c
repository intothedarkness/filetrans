//2010.06.20 huadao.

#include <ansi.h>

inherit F_CLEAN_UP;
inherit F_DAMAGE;

int main(object me, string arg)
{
	string spells, spl, trg;
	  object stone=find_object("/d/dntg/hgs/stone");
	 int dx;


          if( environment(me)->query("short") != "生死轮回处")
      	  return notify_fail("你不能在这里投胎。\n");
          if(me->query("dntg/fail")>5 )
	        return notify_fail("你这不是大闹天宫，你是存心大闹西游记，-f吧。\n");
  
  if (!stone) stone=load_object("/d/dntg/hgs/stone");
  if (stone->query("busy")) 
    return notify_fail("有人已经在大闹天宫了，稍后尝试。\n"); 


        dx=(me->query("daoxing")/2+me->query("combat_exp"));

        if(dx < 500000)
	        return notify_fail("你还不具备大闹天宫的能力，再修炼修炼吧。\n");
	        
        if(me->query("dntg/done")>0 )
	        return notify_fail("你已经开始大闹天宫了！\n");

        if(me->query("dntg/done")==12 )
	        return notify_fail("你已经闹完天宫了，莫非还想再闹一次？\n");

				if((int)me->query("dntg/start")==1 )
					return notify_fail("你已经开始大闹天宫了！\n");

				if( me->is_busy() )
					return notify_fail("( 先忙完手头上的事再开始大闹天宫吧。)\n");
				
         message_vision(HIB+"$N感觉身体像被抽空了一样，魂魄与肉身正在慢慢分开。。。。。。\n"+NOR, me);

				  tell_object(me,"你选择投胎灵猴开始大闹天宫，你还有"+HIR+(5-me->query("dntg/fail"))+NOR"次机会！\n");
					me->set("dntg/start",1);
           me->remove_call_out("unconcious");
  				 me->unconcious();
  				 me->announce();

         call_out("faint1",2,0);
   				return 1;      
}

void faint1()
{
	   object me=this_player();
	
 						message_vision(HIB+"一股灵气从$N的脑门冲顶而出，向着东边飞走了。。。。。。\n"+NOR, me);
              me->move("/d/dntg/hgs/stone");   
 				  message("channel:chat", HIM + "【谣言】某人：听说"+
     me->query("name")+"("+me->query("id")+")投胎转世化作灵猴降生在"HIY"仙石"HIM"中。\n"NOR,users());

 //	       tell_object(me,HIR+"你眼前突然一黑，一股灵气从你脑门冲顶而出。。。。。。\n"NOR);
 //         call_out("faint2",10),0;
	}	
void faint2()
{
	   object me=this_player();
	 
	       
//	        tell_object(me,HIY+"恍惚间，你慢慢恢复了知觉。。。。。。\n"NOR);


				  tell_object(me,"你选择投胎灵猴开始大闹天宫，你还有"+HIR+(5-me->query("dntg/fail"))+NOR"次机会！\n");
					me->set("dntg/start",1);
				  message("channel:chat", HIM + "【谣言】某人：听说"+
     me->query("name")+"("+me->query("id")+")投胎转世化作灵猴降生在"HIY"仙石"HIM"中。\n"NOR,users());
          me->move("/d/dntg/hgs/stone");
	        me->delete_busy();
	}		
int help (object me)
{
        write(@HELP
指令格式：

 
HELP
        );
        return 1;
}
