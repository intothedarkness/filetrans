//bianxing.配合转生福利使用。created by huadao for reset_gender
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object me, string arg)
{
	int namelength=0;

	if( !me->query_temp("reset_gender") ){
    	printf( "什么？\n\n" );
    	return 1;
	}

	if( !arg ){
    	printf( CYN "\n\n你目前的性别为："+me->query("gender") +"\n" NOR );
    	printf( CYN "\n请输入 “bianxing 男性” 或者 “bianxing 女性” \n" NOR );
    	printf( CYN "\n来完成性别转换。 \n\n" NOR );
    	return 1;
	}
	
	if( arg=="none" ) {
		printf(CYN "\n\n你放弃更改性别的权利。\n\n" NOR );
		me->delete_temp("reset_gender");
		return 1;
	}

	if (arg == me->query("gender"))
	{
		printf(CYN "\n\n这不就是你现在的性别吗？瞎折腾！\n" NOR);
    	printf( CYN "\n你目前的性别为："+me->query("gender") +"\n" NOR );
    	printf( CYN "\n请输入 “bianxing 男性” 或者 “bianxing 女性” \n" NOR );
    	printf( CYN "\n来完成性别转换。 \n\n" NOR );
    	return 1;
	}

	if (arg == "男性")
	{
		me->set("gender", "男性");
	} else if (arg == "女性")
		{
		me->set("gender", "女性");
	} else 
		{
		printf(CYN "\n\n对不起，您只能选择男性或女性的角色！\n" NOR);
		printf(CYN "\n请重新输入。\n" NOR);
    	printf( CYN "\n\n你目前的性别为："+me->query("gender") +"\n" NOR );
    	printf( CYN "\n请输入 “bianxing 男性” 或者 “bianxing 女性” \n" NOR );
    	printf( CYN "\n来完成性别转换。 \n\n" NOR );
    	return 1;
	}

		me->delete_temp("reset_gender");
		printf(CYN "\n\n恭喜，性别变更完成！\n" NOR );
		printf(CYN "\n你将性别设定为“"+ me->query("gender") +"”。\n\n" NOR );
    	return 1;
}

int help(object me)
{
    write(@HELP
指令格式: bianxing 男性 | 女性 | none

重新设定性别，玩家在2转完成以后，每次转生都有
一次变更性别的机会，体验一下不同的角色扮演。

bianxing 不加参数显示你目前的性别。
bianxing none  放弃变更自己的性别。

HELP
    );
	return 1;
}
 
