//setname.配合转生福利使用。created by huadao for reset_name
#include <ansi.h>
inherit F_CLEAN_UP;

int check_legal_name(string, int);
 
int main(object me, string arg)
{
	int namelength=0;

	if( !me->query_temp("reset_name") ){
    		printf( "什么？\n\n" );
    		return 1;
	}

	if( !arg ){
    		printf( CYN "\n\n你目前的中文名：\n" NOR );
    		printf( CYN "\n"+me->query("name") +"\n\n" NOR );
    		return 1;
	}
	
	if( arg=="none" ) {
		me->delete("added_name");
		printf(CYN "\n\n你放弃修改中文名的权利。\n" NOR );
		me->delete_temp("reset_name");
		return 1;
	}

	if(me->query("reincarnation/number") >= 5){
		namelength=18;
	}
	else if(me->query("reincarnation/number") >= 3){
		namelength=16;
	}
	else if(me->query("reincarnation/number") >= 1){
		namelength=14;
	}
	else namelength=12;
	
	if(check_legal_name(arg, namelength) == 0) return 1;	
	
	me->set("added_name", arg);
	me->set("name", me->query("added_name"));
	me->delete_temp("reset_name");
	printf(CYN "\n\nok!\n" NOR );
	printf(CYN "\n你将中文名修改为“"+ me->query("name") +"”。\n\n" NOR );

    	return 1;
}
 
int check_legal_name(string addname, int namelength)
{
       	int i;

	i = strlen(addname);

	if(namelength<=0){
		write("对不起，目前你还不能给自己设中文名。\n");
    		return 0;
	}

	if(namelength < strlen(addname)){
    		printf("对不起，目前你最多只能设%s个中文字作为中文名。\n", chinese_number(namelength/2));
    		return 0;
	}

	while(i--) {
               	if( addname[i]<=' ' ) {
                       	write("对不起，你的中文名不能用控制字元。\n");
                       	return 0;
               	}
               	if( i%2==0 && !is_chinese(addname[i..<0]) ) {
                       	write("对不起，请您用「中文」设中文名。\n");
                       	return 0;
               	}
       	}
	return 1;
}
int help(object me)
{
    write(@HELP
指令格式: setname ***

重新设定中文名，默认中文名在1到6个中文字之间，
每次转生，玩家都可以免费重新设定一次中文名字，
1转可以设定上限7个中文字，3转8个，5转9个。

setname 不加参数显示你目前的中文名。
setname none  放弃修改中文名。

HELP
    );
	return 1;
}
 
