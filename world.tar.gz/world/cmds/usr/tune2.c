#include <ansi.h>

inherit F_CLEAN_UP;

int main(object me, string arg)
{
        string *tuned_ch, *tunes_ch;
        string str;
        object who;
        mapping tunes;

        tuned_ch = me->query("channels");

        if( !arg ) {
                if( !pointerp(tuned_ch) || !sizeof(tuned_ch) )
                        write("你现在并没有收听任何频道。\n");
                else
                        write("你现在收听的频道：" + implode(tuned_ch, ", ") + "。\n");
                return 1;
        }

        if( arg == "xiaodao" || arg == "sldh" || arg == "rultra" || arg == "ultra") {
                write(arg+" 频道是系统频道，你不能关闭。。。\n");
                return 1;
        }

        if( pointerp(tuned_ch) && member_array(arg, tuned_ch)!=-1 ) {
                write("关闭 " + arg + " 频道。\n");
                tuned_ch -= ({ arg });
                me->set("channels", tuned_ch);
                return 1;
        }
        else {
        if(sscanf(arg,"-a %s",arg)==1) {

                who = find_player(arg);
                if (!who) who = LOGIN_D->find_body(arg);
                if (!who) return notify_fail("没有这个人。\n");

        if( who == me ) return notify_fail("脑子秀豆？\n");

        if(!wizardp(me) || wiz_level(me) < wiz_level(who)) return 0;

        tunes = who->query("channels");
        if( mapp(tunes) || sizeof(tunes)!=0 ) {
                write(CYN+log_id(who) + 
                        sprintf("目前开启的公用频道共有"+sizeof(tunes)+"项："NOR"\n%O\n"NOR, tunes));
                return 1;
                } else 
                write(log_id(who) + "目前没有开启任何的公用频道。。。\n");
                return 1;
        }
        else {
        if(sscanf(arg,"-d %s %s",str, arg)==2)  {

        if(!wizardp(me) || wiz_level(me) < wiz_level(who)) return 0;

                who = find_player(str);
                if (!who) who = LOGIN_D->find_body(str);
                if (!who) return notify_fail("没有这个人。\n");

        if( who == me ) return notify_fail("脑子秀豆？\n");

        tunes_ch = who->query("channels");
        if( pointerp(tunes_ch) && member_array(arg, tunes_ch)!=-1 ) {
                write("关闭 "+who->name()+" 的 " + arg + " 频道成功。\n");
                tunes_ch -= ({ arg });
                who->set("channels", tunes_ch);
                return 1;
                } else 
                write(log_id(who) + "目前没有开启这个频道，请用 tune -a <ID> 查看其频道状态！\n");
                return 1;
        }
        }

        if(sscanf(arg,"-e %s %s",str, arg)==2)  {

        if(!wizardp(me) || wiz_level(me) < wiz_level(who)) return 0;

                who = find_player(str);
                if (!who) who = LOGIN_D->find_body(str);
                if (!who) return notify_fail("没有这个人。\n");

        if( who == me ) return notify_fail("脑子秀豆？\n");

        tunes_ch = who->query("channels");
        if( pointerp(tunes_ch) && member_array(arg, tunes_ch)==-1 ) {
                write("增加 "+who->name()+" 的 " + arg + " 频道成功。\n");
                tunes_ch += ({ arg });
                who->set("channels", tunes_ch);
                return 1;
                } else 
                write(log_id(who) + "目前已经开启这个频道，请用 tune -a <ID> 查看其频道状态！\n");
                return 1;
        }

        }

}

int help(object me)
{
        write(@HELP

指令格式：tune [<频道名称>]
          tune [-a | -d | -e] <ID> [<频道名称>] <巫师专用>

这个指令让你选择是否要收听某一频道的讯息，如果没有指定频道名称，就会列出
你目前收听中的频道，如果指定了频道，原来收听中的就会关掉，反之打开。

如果你对一个没有收听中的频道讲话，会自动将它打开。
要对一个频道讲话，只要用：

<频道名称> <讯息> ....

例子：
  chat hello everyone!
  
目前系统允许玩家正常可以收听使用的频道如下：
rumor、chat、music、party、xyj、sldh

HELP
        );
        return 1;
}

