//Cracked by Roath
// whousebug

inherit F_CLEAN_UP;
int where_all();

int main(object me, string str)
{
   object ob, where, *ob_list;
   int i;

   if (!str)
     return where_all();
}

int where_all()
{
    string str;
    object *list;
    int i, j, ppl_cnt,k;
    object me, where;
        me = this_player();
        str =  "北京站在线玩家取经关过关情况统计：" +"\n"; 
        str += "—————————————————————————————————————\n";
        str += "玩家代号      玩家姓名          过关次数        玩家位置\n";
        str += "—————————————————————————————————————\n";
        list = users();
    j = sizeof(list);
    while( j-- ) {
        where=environment(list[j]);
              if( !where ) continue;
//       str = sprintf("%s%-14s%-18s%-18d%-s(%s)\n",
       str = sprintf("%s%-14s%-18s%-8d%-s(%s)\n",
                                str,
                                list[j]->query("id"),
                                list[j]->query("name"),
                                list[j]->query("obstacle/number"),
                               "        ",
            file_name(where)
                        );
                }
        str += "—————————————————————————————————————\n";
    me->start_more(str);
    return 1;
}
