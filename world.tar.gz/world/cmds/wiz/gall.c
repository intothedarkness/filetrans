//Cracked by Roath
#include <ansi.h>
inherit F_CLEAN_UP;

int main(object me, string arg)
{
        object *users, present;
        int i;
        
        int bIsMonitored = 0; 

        if( !arg || arg=="" )
                 return notify_fail("指令格式：gall <物品文件名>\n");

	if( !sscanf(arg, "%*s.c") )
		arg += ".c";
	
	if ( file_size( arg ) == -1 )
		return notify_fail("文件不存在或者非物品文件。\n");

        seteuid(getuid());
        users = users();
        i = sizeof(users);
        while(i--) 
        {
        	// make a filter here by xfile 2005-5-24
        	if ( !environment( users[i] ) 			// player has no room somehow
        	|| !interactive( users[i] ) 
        	|| base_name( environment( users[i] ) ) == "/d/wiz/punish" 
        	|| base_name( environment( users[i] ) ) == "/d/wiz/guest"  // player in punish room or in prison
        	|| query_idle( users[i] ) > 300 		// player have idled for a long time
        	|| users[i]->query_temp( "netdead" ) )		// player was in net dead status
        	continue;
        	
        	// modified by xfile@bjxyj
                present = new( arg );               
                
                // if the object has is_monitored flag, it'll
                // flood the monitor channel, so strip off
                // the flag here.                
                if ( present->query("is_monitored") )
                {
                	bIsMonitored = 1;
                	present->set( "is_monitored",0 );
                }                	
                present->move(users[i]);
                present->set( "is_monitored", bIsMonitored );                
/*                
                tell_object( users[i], HIW "天上隐隐约约的传来一阵叮叮当当的响声...\n\n" +
                                      HIY "响声过后只见一个东西从天上直掉下来，正好落入你的怀中！\n\n" NOR );                                     
*/                     
                }
        log_file("static/GALL", sprintf("%s%s give all %s (%s)\n",me->query("name"),"(" + me->query("id") + ")" ,
                        arg,ctime(time()) ) );        
        write("物品发放完毕。\n");
        return 1;
}

int help()
{
       write( @TEXT
指令格式 : gall <物品文件名>

用处：发放物品到所有的在线玩家。
TEXT
       );
       return 1 ;
}