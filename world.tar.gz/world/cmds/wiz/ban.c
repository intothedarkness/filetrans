//Cracked by Roath
// ban.c
// modified by xfile@bjxyj for log file.

void create()
{
	seteuid(getuid());
}

int main(object me, string arg)
{
	string site;
	string reason;
	string action;

	if (!arg)
	{
	   BAN_D->print();
	   return 1;
	}
	   
	if( sscanf(arg, "%s %s because %s", action, site, reason) != 3 )
		return notify_fail("指令格式：ban + | - <使用者ＩＰ> because <原因>\n");
		
	// else if (sscanf(arg, "+ %s", site) == 1) 
	//{
	//	if (site[sizeof(site)-1] == '*' ||
	//	    site[sizeof(site)-1] == '?' ||
	//	    site[sizeof(site)-1] == '+')
	//		write("不能禁以 *, +, ? 结尾的地址。\n");
	//	else
	
	if (site[sizeof(site)-1] == '*' ||
		site[sizeof(site)-1] == '?' ||
		site[sizeof(site)-1] == '+')
			return notify_fail("不能禁以 *, +, ? 结尾的地址。\n");
			
	if ( action == "+" )
	{
		// add banned site.
		log_file("static/BAN", sprintf("[%s] %s add banned site %s because %s.\n",
			ctime(time())[0..15], geteuid(this_player(1)), site, reason));			
		BAN_D->add(site);
		write("ok.\n");
		return 1;
	}
	else if ( action == "-" )
	{
		// remove banned site.
		log_file("static/BAN", sprintf("[%s] %s remove banned site %s because %s.\n",
			ctime(time())[0..15], geteuid(this_player(1)), site, reason));			
		BAN_D->remove(site);		
		return 1;
	}
	else 
		return notify_fail("指令格式：ban + | - <使用者ＩＰ> because <原因>\n");
		
	return 1;

	
	
}

int help(object me)
{
	write(@HELP
指令格式：ban [+|- site] because reason

当有人搞破坏时可以拒绝其相关IP的连线。
HELP
	);
	return 1;
}
