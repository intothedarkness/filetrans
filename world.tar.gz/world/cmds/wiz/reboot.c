// [1;31m此文件禁止随意移动和更改[0m
// CMDS  /cmds/wiz/reboot.c


#include <net/daemons.h>
#include <getconfig.h>
#include <mudlib.h>
#include <command.h>

inherit F_CLEAN_UP;

// 启动的时间
int start_reboot = 0;
int last_notice = 0;

int is_rebooting() { return start_reboot != 0; }

private void reboot_mud();

int main(object me, string arg)
{
        string str;
        int n;
	string wiz_status;

	if( me != this_player(1) ) return 0;
	
	wiz_status = SECURITY_D->get_status(me);
	if( wiz_status != "(admin)" && wiz_status != "(arch)" && wiz_status != "(wizard)" )
		return notify_fail(HIC"只有(wizard)级别以上的巫师才能重新启动"+INTERMUD_NAME+" \n"NOR);

        if (! arg) {
                write("指令格式: reboot | after <n> | now | cancel \n");
                return 1;
        }

        str = log_id(me);
        if (arg == "now") {
                if (! find_object(SECURITY_D) ||
                    ! find_object(SIMUL_EFUN_OB) ||
                    ! find_object(MASTER_OB))
                        shutdown(0);
                        
	        if (! is_root(me)) {
		        write("你没有权限强制停止" + INTERMUD_NAME + "。\n");
                        return 1;
                }
		write_file("/log/static/LASTTIME", BJTIME_CMD->chinese_time(1,ctime(time()))+"\n", 1);
		write_file("/log/static/LASTCRASH", log_id(me) + " reboot(-n) "+INTERMUD_NAME+"\n", 1);
		log_file("static/reboot", log_id(me) + " reboot(-f) "+INTERMUD_NAME+" 时间在："+log_time()+"\n");
                message_system(str + "强行启动了" + INTERMUD_NAME + "。");
                shutdown(0);
                return 1;
        }

        if (sscanf(arg, "after %d", n) != 1) {
                if (arg != "now") {
                        if (arg != "cancel") {
                                write("参数错误，请查看帮助。\n");
                                return 1;
                        }

			if (start_reboot) {
                               start_reboot = 0;
                               set_heart_beat(0);
                               message_system(HIR+str + "取消了启动，游戏继续进行。。。"NOR);
		log_file("wizcmds/reboot", 
		log_id(me) + " reboot(-cancel) 取消了启动"+INTERMUD_NAME+" 时间在："+log_time()+"\n");
                                write("Ok.\n");
                                return 1;
                        }

                        write("现在MUD正在正常的运行。\n");
                        return 1;
                }
                message_system(str + "重新启动了" + INTERMUD_NAME + "。");
                reboot_mud();
        }

        if (n < 1) {
                write("没有这么短的时间，你不如选择 now 立刻启动。\n");
                return 1;
        }

        if (n > 10) {
                write("这么久？你只能在1～10分钟之间做出选择。\n");
                return 1;
        }

        if(start_reboot != 0) return notify_fail(HIW"\nMUD已经在 reboot 了。。。。\n"NOR);

        start_reboot = time() + n * 60;
        last_notice = time();
        set_heart_beat(1);
        message_system(HIW+str + "决定在 " HIR+ n +HIW " 分钟以后重新启动" + INTERMUD_NAME + "。"NOR);
	log_file("static/reboot", log_id(me) + " reboot(-a"+n+") "+INTERMUD_NAME+" 时间在："+log_time()+"\n");
	write_file("/log/static/LASTCRASH", log_id(me) + " reboot(-a"+n+") "+INTERMUD_NAME+"\n", 1);
	write_file("/log/static/LASTTIME", BJTIME_CMD->chinese_time(1,ctime(time()))+"\n", 1);

        return 1;
}

private void heart_beat()
{
        int t;
        int n;
        string str;

        if (! start_reboot) return;

        n = start_reboot - time();
        if (n < 1) {
                reboot_mud();
                return;
        }

        if (n >= 60) str = (n / 60) + "分钟"; else
                     str = "";
        if (n % 60) str += (n % 60) + "秒";

        t = time() - last_notice;
        if ((n >= 60 && t >= 60) || (n < 60 && n >= 10 && t >= 10) || n < 10) {
                message_system(HIW+INTERMUD_NAME + "将在 " HIR+ str +HIW " 以后重新启动，请抓紧时间处理你的人物。"NOR);
                last_notice = time();
        }
}

private void reboot_mud()
{
	object *user, link_ob, me;
	int i;

	message_system(HIW"西游记重新启动游戏主机，请稍候几分钟再尝试连线。。。。\n"NOR);

       user = filter_array(objects(), (: userp :));
	for (i = 0; i < sizeof(user); i++)	{
		if (! environment(user[i])) continue;
		user[i]->delete("mieyao/time_start1"); //By waiwai added.
		user[i]->delete("mieyao/time_start"); //By waiwai added.
//              user[i]->delete("quest");
		user[i]->save();
		link_ob = user[i]->query_temp("link_ob");
		if (objectp(link_ob)) link_ob->save();
	}

        // 保存所有的守护进程的数据
        reset_eval_cost();
	if (find_object(DNS_MASTER)) DNS_MASTER->send_shutdown();
/*
        if (find_object(NAME_D))     NAME_D->mud_shutdown();
        if (find_object(FAMILY_D))   FAMILY_D->mud_shutdown();
        if (find_object(KZZNPC))   KZZNPC->mud_shutdown();
*/
	shutdown(0);
}

int help (object me)
{
        write(@HELP

指令格式: reboot | after <n> | now | cancel
 
重新起动游戏。如果采用 now 参数，则系统强制启动，而不保存任何
进度，这是供系统出错时使用的。而使用 after n 则系统将在 n 分
钟以后重新启动。

使用了 now 参数则 after 无效。

如果使用了 after 参数，可以使用 cancel 参数终止启动的过程。
为了避免系统显示错误，请尽量想好再执行指令，不要随意使用 cancel 
终止启动过程。。。

HELP );
        return 1;
}
