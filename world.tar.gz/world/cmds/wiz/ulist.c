// rewrite by Rocky@XYJ-CN
// allow argument to find out specified user euid.
// this will be very helpful to debug some bug only gives user euid
// 2015. March.

#include <ansi.h>
inherit F_CLEAN_UP;

int main(object me, string str)
{
    object *ob;
    int i, b_find;
    string full_euid = "/obj/";
    ob = filter_array(children(USER_OB),(: userp :));
    i = sizeof(ob);
    b_find = 0;

    if (!str)
    {
        while (i--) 
        {
            write(sprintf("%15s : %30s\n",ob[i]->query("id"),
            file_name(ob[i])));
        }
        return 1;
    }
    else 
    {
        full_euid += str;
        for (int j = 0; j < i; j ++)
        {
            if (full_euid == file_name(ob[j]))
            {
                printf(HIR + str + " = " + ob[j]->query("name") + "(" 
                + ob[j]->query("id") + ")\n" + NOR);
                b_find = 1;
                break;
            }
        }
    }
    
    if (!b_find)
        printf("没有找到你要找的玩家。\n");
    
    return 1;
}

int help(object me)
{
write(@HELP
指令格式 : ulist | <user euid>
    
无参数：将线上所有玩家的/obj/user number 显示出来。
有参数：打印出指定EUID的玩家
HELP
    );
    return 1;
}

