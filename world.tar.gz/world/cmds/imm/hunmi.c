#include "/doc/help.h"
#include <ansi.h>
inherit F_CLEAN_UP;
int main(object me, string arg)
{
object ob;
	 if (me!=this_player(1))	return 0;
  seteuid( getuid(me) );

	if (!arg) return notify_fail("指令格式: hunmi <living>\n");
	ob = present(arg, environment(me));
	if (!ob) return notify_fail("找不到这个生物。\n");
  message_vision("天空中一道神光倏然而下罩住了$n，$n应声摔倒在地上！！\n",me,ob);
	ob -> unconcious();
     return 1;
}

int help(object me)
{
 write(@HELP
指令格式: hunmi <id>
使某人立刻昏迷不醒

HELP
 );
 return 1;
}
