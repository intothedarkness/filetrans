//Cracked by Roath
#include <ansi.h>
inherit F_CLEAN_UP;
int main(object me, string arg)
{
     object ob;
    if(!arg)
      return notify_fail("指令为list <id>,查看玩家一些data\n");
    ob = find_player(arg);
     if(!ob) ob = find_living(arg);
      if (!ob) return notify_fail("没这个人啊。。。。。苯死。。。\n");
      
    tell_object(me,"玩家："+ob->query("name")+" ID:"+ob->query("id")+"\n\n");  
    tell_object(me,"寿命:"+ob->query("life/life_time")+"岁\n");
    tell_object(me,"吃了:"+ob->query("rsg_eaten")+"人参果\n");
    tell_object(me,"拥有:"+ob->query("gxdian")+"点功勋点\n");
    tell_object(me,"杀人总数:"+ob->query("MKS")+"\n");
    tell_object(me,"杀玩家数:"+ob->query("PKS")+"\n");
    tell_object(me,"钱庄总数:"+ob->query("balance")+"\n");
    tell_object(me,"开始房间:"+ob->query("startroom")+"\n");
    tell_object(me,"体格:"+ob->query("str")+"    胆识:"+ob->query("cor")+"\n");
    tell_object(me,"悟性:"+ob->query("int")+"    灵性:"+ob->query("spi")+"\n");
    tell_object(me,"定力:"+ob->query("cps")+"    容貌:"+ob->query("per")+"\n");
    tell_object(me,"根骨:"+ob->query("con")+"    福缘:"+ob->query("kar")+"\n");
        
    return 1;
}
