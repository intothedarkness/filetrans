// by firefox 11/21/2009


#include <ansi.h>

//预定义的buff


//捆绑，


//


