#include <ansi.h>
//#define Is_Diablo_Npc 1//是否属于diablo系统中的NPC的标记
void drop(object npc,object user,int obj_level);
string random_file(string dir_path);//从dir_path目录中随机选取一个文件

void diablo(object npc,object user)
{
   int npc_exp,npc_dx,npc_total;
   int user_exp,user_dx,user_kar;
   int obj_level=1;//装备等级
   int user_success;//成功机率
   int user_kar_and_success;
   if (!npc) return;
   if (!userp(user)) return;
   //获得npc属性
   npc_exp=npc->query("combat_exp");
   npc_dx=npc->query("daoxing");
   
   npc_total=npc_exp+npc_dx;//把武学和道行相加.用于判断掉出装备的等级
   //获得user属性
   user_exp=user->query("combat_exp");
   user_dx=user->query("daoxing");
   user_kar=user->query("kar");
   user_success=user->query("成功机率");
   user_kar_and_success=user_success+user_kar;
//   if (npc_total<500000 && random(user_kar_and_success)<40) 
//  	return;
   //判断是否应该掉出装备.
   if ( (random(80)+random(user_success)+random(user_kar)) >1) 
   {
   	//计算应该掉出哪个等级的装备
   	if (npc_total>8000000 && (random(user_kar_and_success)>random(300) ) ) obj_level=6;
   	else if (npc_total>6000000 && (random(user_kar_and_success)>random(250) )) obj_level=5;
   	else if (npc_total>4000000 && (random(user_kar_and_success)>random(200) )) obj_level=4;
   	else if (npc_total>2000000 && (random(user_kar_and_success)>random(150) )) obj_level=3;
   	else if (npc_total>1000000 && (random(user_kar_and_success)>random(100) )) obj_level=2;
   	else obj_level=1;
   	drop(npc,user,obj_level);
   }
}

void drop(object npc,object user,int obj_level)
{
   object env;
   object obj;
   string temp_str;//temp_str="armor" or temp_str="weapon";
   string dir_path;//存放物品文件的目录名
   string file_name;
   string file_full_name;
   env=environment(npc);
   if (!env) return ;
   if (random(50)>25) temp_str="armor";
   else temp_str="weapon";
   dir_path="/obj/diablo_obj/"+temp_str+"/"+obj_level+"";
   file_name=random_file(dir_path);
   file_full_name=dir_path+"/"+file_name;
   //判断是否存在file
   if (file_size(file_full_name) <0) 
   {
   	message_vision(file_full_name,npc);
   	return ;
   }
   obj=new(file_full_name);
   obj->move(env);
   message_vision(GRN+"从$N身上掉了出来一"+obj->query("unit")
                     +obj->name()+""GRN"「等级："+obj_level+" 」\n"+NOR,npc);
   return;
}

string random_file(string dir_path)
{
   mixed *file;
   int j;
   file = get_dir( dir_path+"/*.c", -1 );
   if( !sizeof(file) ) return "";
   j = random(sizeof(file));
   return file[j][0];
}
