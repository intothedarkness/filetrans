// Last Create by PKYOU@DHXY 2002/05/11


#include <ansi.h>

string char_id;
string char_name;

object select_character();
int give_gift();

static mixed *story = ({
        "五庄观人参果园。。。",
        "猪八戒:“猴哥也不知道去哪了。”",
        "猪八戒蹑手蹑脚的爬上了人参果树。",
        "沙僧赞叹不已：“这果树的确非人间之物。”",
        "猪八戒哼哼道：“管它什么的，先摘个俺老猪尝尝鲜。”",
       "沙僧：“阿弥陀佛，出家人竟然做起了盗贼，善哉！”",
        "猪八戒顺手打下了一个人参果，但人参果却钻到地里不见了！",
        "$N[$ID]：“俺老孙来也”！",
        "$N[$ID]：“八戒，这果子用手摘不得。”",
        "猪八戒脸上露出疑惑的表情。",
        "$N[$ID]：“我刚才去镇元大仙老头那里偷来一把金击子，一个托盘。”",
        "猪八戒迷惑道：“咦？",
        "$N[$ID]：“沙师弟，你们有所不知，这人参果必须用这二件宝贝方才可以打下！”",
      "沙僧：“大师兄，还是你有神通。。。”",
        "$N一个猴跳跃到了树上，用金击子打下一枚人参果，顺势用托盘接了个正着！",
        "“猪八戒与沙僧连声叫好”",
        (: give_gift :),
});

void create()
{
        seteuid(getuid());
        if (! objectp(select_character()))
        {
                STORY_D->remove_story("story5");
                destruct(this_object());
                return;
        }
}

string prompt() { return HIR "【西游记】" NOR; }

object select_character()
{
        object *obs;
        object ob;
obs = filter_array(users(), (: ! wizardp($1) &&
                              living($1) &&
                              $1->query("daoxing") < 3456000 &&
                              $1->query_kar() > 20 &&
                              $1->query("combat_exp") > 100000 &&
                            ! $1->query("doing") :));
        
        if (! sizeof(obs))
                return 0;

        ob = obs[random(sizeof(obs))];
        char_id = ob->query("id");
        char_name = ob->name(1);
        return ob;
}

mixed query_story_message(int step)
{
        mixed msg;

        if (step >= sizeof(story))
                return 0;

        msg = story[step];

        if (stringp(msg))
        {
                msg = replace_string(msg, "$N", char_name);
                msg = replace_string(msg, "$ID", char_id);
        }
        return msg;
}

int give_gift()
{
        object ob;
        object gob;

        ob = find_player(char_id);
        if (! ob) return 1;

        STORY_D->remove_story("story5");

        gob = new("/d/obj/drug/renshen-guo");
        gob->move(ob, 1);
        CHANNEL_D->do_channel(this_object(), "rumor", "听说" + ob->name(1) +
                              "打下了镇元大仙的人参果。");
        return 1;
}

