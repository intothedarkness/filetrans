// Last Create by PKYOU@DHXY 2002/05/14

#include <ansi.h>

string char_id;
string char_name;

void   stop_story();
object select_character();
int stop;               //是否需要终止故事
int give_gift();

mixed *story = ({
        "寿星：老夫近来身体欠安，不知道是为什么？",
        "福星：寿星也会身体感到不适？",
        "禄星：老夫这里有交梨一枚，寿星不妨试试。",
        "寿星：嗯...多谢！",
        "福星：我这里也有火枣一枚，不知效果如何。",
        "禄星：既然寿星身体欠安，那我与福星先下棋了。",
        "寿星：多谢二老仙丹，老夫也有一碧藕。",
        "话音未落，一条黑影闪过。",
        "禄星大叫：是谁？",
        "那黑影并不搭腔，顺势一把夺过寿星手中三枚仙丹。",
        "福星上前与那黑影就是一掌！",
        "黑影连忙运气迎头接住福星这一掌。",
         "福星被震得眼花缭乱，气血翻涌，大叫不好。",
         "$N[$ID]一拱手：多谢三老灵丹妙药，晚辈出手若是重了，得罪了！",
         "说罢，$N一抱拳：“后回有期”便驾云而去！",
        (: give_gift :),
});

void create()
{
        seteuid(getuid());
        if (! objectp(select_character()))
        {
                STORY_D->remove_story("story6");
                destruct(this_object());
                return;
        }
}

string prompt() { return HIR "【西游记】" NOR; }

object select_character()
{
        object *obs;
        object ob;
obs = filter_array(users(), (: ! wizardp($1) &&
                                                 living($1) &&
                                                 $1->query_skill("force", 1) > 100 &&
                                                 ! $1->query("doing") :));
        
        if (! sizeof(obs))
                return 0;

        ob = obs[random(sizeof(obs))];
        char_id = ob->query("id");
        char_name = ob->name(1);
        return ob;
}

mixed query_story_message(int step)
{
        mixed msg;

        if (step >= sizeof(story))
                return 0;

        msg = story[step];

        if (stringp(msg))
        {
                msg = replace_string(msg, "$N", char_name);
                msg = replace_string(msg, "$ID", char_id);
        }
        return msg;
}

int give_gift()
{
        object ob;
        object gob;

        ob = find_player(char_id);
        if (! ob) return 1;

        STORY_D->remove_story("story6");

        gob = new("/adm/daemons/story/obj/qipan");
        gob->move(ob, 1);
        CHANNEL_D->do_channel(this_object(), "rumor", "听说" + ob->name(1) +
                              "在蓬莱仙岛抢得三枚仙丹。");
        return 1;
}

