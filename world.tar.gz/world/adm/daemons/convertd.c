/**
    Convertd.c
    Recreated by Rocky@xyj for FluffOS 2015-Jan.
    FLuffOS supports below new efuns, so we don't need to make encoding translation in LPC world, we could call the efun interface directly.

	1. int set_encoding(string);
	2. string to_utf8(string, string);
	3. string utf8_to(string, string);
	4. int *str_to_arr(string);
	5. string arr_to_str(int *);
	
	since we are not support flag USE_ICONV in FluffOS, the efuns is not exported yet, if we turn it on, we could open up the code below.
*/

#pragma optimize

#include <mudlib.h> 
inherit F_DBASE;

string GB2BIG (string str)
{
	/* for future use.
	
	string utf8_string;
	string big5_string;
	
	utf8_string = to_utf8(str, "GB2312");
	big5_string = utf8_to(utf8_string, "BIG5");
	
	return big5_string;
	
	*/
	return str;
}

string BIG2GB (string str)
{
	/* for future use.
	
	string utf8_string;
	string gb2312_string;

	utf8_string = to_utf8(str, "BIG5");	
	gb2312_string = utf8_to(utf8_string, "GB2312");
	
	return gb2312_string;
	*/
	return str;
}

string input (string str, object me)
{
    
#ifndef GB_AND_BIG5
    return str;
#endif

    if (! str || ! me)
        return str;
    if (me->query_encoding() == 1)
    {
        return BIG2GB(str);
    }
    return str;
}

string output (string str, object me)
{

#ifndef GB_AND_BIG5
        return str;
#endif

    if (! str || ! me)
        return str;
    if (me->query_encoding() == 1)
    {
        return GB2BIG(str);
    }
    return str;
}

void create()
{
   seteuid(getuid());
   set("name", "GB BIG5 converter");
   set("id", "GB BIG5 converter");
}