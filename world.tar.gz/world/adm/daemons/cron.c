//Cracked by Roath

#include <ansi.h>
#include <command.h>
#include <globals.h>
#include <net/daemons.h>
#include <net/macros.h>
#include <obstacle.h>

int LAST_HARD_DIS= 0;
void init_cron();
void autosave();
void dianmao();
//void emery();

void create()
{
        seteuid( ROOT_UID );
        init_cron();
}

int query_last_hard_dis()
{
        return LAST_HARD_DIS;
}
int set_last_hard_dis()
{
        LAST_HARD_DIS = time();
        return time();
}

void init_cron()
{
        mixed *local;
        local = localtime(time());
        if ( !((local[1])%40)) autosave();
        if ( !((local[1])%30)) dianmao();
  //      if ( !((local[1])%53)) emery();

        if ( !((local[1])%40))
       if (random(5))TASK_D->init_dynamic_quest();
        else TASK_D->init_dynamic_quest(1);
        call_out("init_cron", 60);  
}

void autosave()
{
 object *user ;
 int i;
        user = users();
       message("system", HIY "自动更新西游记使命榜。\n"NOR, users());
        for(i=0; i<sizeof(user); i++) 
        user[i]->save();
}

void dianmao()
{
 object *user;
 int size1,i;
 size1 = sizeof(obstacles);
 user = users();
        for(i=0; i<sizeof(user); i++)
        {
           if ( user[i]->query("obstacle/number") == size1 )
           {
           user[i]->set("dianmao",1);
           }
        }
}         
/*
void emery()
{
        object emery=new("/d/jz/obj/diren");
        message("system", HBMAG"大唐危难，叛军四伏。\n"NOR, users());
        emery->move("/d/westway/west3");
        emery->move("/d/kaifeng/east4");
        emery->move("/d/changan/broadway5");
}
       
*/
