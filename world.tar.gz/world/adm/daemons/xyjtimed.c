// #pragma optimize
// #pragma save_binary

#include <command.h>

// 定义元年一月一日一时一刻的时间
// 定义为999900000是这个时间是西游记建立日期
// 是按照实际现实日期计算所得
#define XYJ_TIME 999900000
#define ONE_YEAR_TIME 172800  // 每年所需要的时间,这里为48小时

inherit F_CLEAN_UP;
mapping check_time(int time_now);
string day_event(){ return NATURE_D->outdoor_room_event(); }

string check_season();			// 纪年季节
string check_month_desc();			// 月份前缀
string check_sxt(object ob);		// 生肖图谱
string check_xzt(object ob);		// 星座图谱
string check_weather_season();		// 时辰季节
string check_daoxing(int gain);		// 道行调用
string check_usr_birthday(object ob);	// 个人生日
/**************************************************************************************************/

mapping check_time(int time_now)
{   int t;
    int year,month,day,hour,quarter;
    mapping date;
    string time;

    t = time_now-XYJ_TIME;
        if(t>=0){
        time = "西游记创世";
        year = t / ONE_YEAR_TIME;
        t -=year*ONE_YEAR_TIME;
        } else {
          time ="西游记创世前";
          t =(-1)*t;
          year =t / ONE_YEAR_TIME;
          t = ONE_YEAR_TIME - (t-year*ONE_YEAR_TIME);
        }

       month = t/(30*480);  t -=month*30*480;
       day  =t/480;          t -=day*480;
       hour =t/20;           t -=hour*20;
       quarter =t/5;

      // 此处年月日需要加一.
       year++; month++; day++;
       date =([
          "YEAR"     : time+((year==1)?"元":chinese_number(year)) + "年",
          "MONTH"    : (month==1)?"元月":chinese_number(month) +"月",
          "MONTHH"   : (month==1)?"13":month +"月",
          "DAY"      : chinese_number(day) +"日",
          "DAYY"     : day,
          "HOUR"     : chinese_number(hour) +"时",
          "HOURR"    : hour,
          "QUARTER"  : (!quarter)?"零刻":chinese_number(quarter)+"刻",
          ]);

        return date;
}
/**************************************************************************************************/

// 纪年的调用暂时还可以用模糊的月份方式吧
string check_season()
{
	string month;
	string season;
	string time;
	int hour;

	mapping date=check_time(time());
	month=date["MONTH"];
	hour=date["HOURR"];

	if(hour <6 && hour>0)                time="凌晨";  
	     else if(hour<8 && hour >=6)     time="早上";    
	     else if(hour<12 && hour>=8)     time="上午";   
	     else if(hour==12)               time="中午";     
	     else if(hour<19 && hour>12)     time="下午";    
	     else if(hour<24 && hour>=19)    time="晚上";    
	     else if (hour==24 || hour==0)   time="子夜";   

	switch (month) {
	       case "十二月":
               season = "初冬的"+time; break;
	       case "元月":
	         season = "隆冬的"+time; break;
	       case "二月":
               season = "冬末的"+time; break;
	       case "三月":
               season = "初春的"+time; break;
	       case "四月":
               season = "春季的"+time; break;
	       case "五月":
               season = "春末的"+time; break;
	       case "六月":
               season = "初夏的"+time; break;
	       case "七月":
               season = "盛夏的"+time; break;
	       case "八月":
               season = "夏末的"+time; break;
	       case "九月":
               season = "初秋的"+time; break;
	       case "十月":
               season = "秋季的"+time; break;
	       case "十一月":
               season = "深秋的"+time; break;
       } 
       return season;
}
/**************************************************************************************************/

string check_weather_season()
{
	string get_season;
	string season;
	get_season= NATURE_D->check_seasonF();

      if( day_event() == "event_dawn" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的凌晨"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的凌晨"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的凌晨"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的凌晨"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的凌晨"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的凌晨"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的凌晨"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的凌晨"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的凌晨"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的凌晨"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的凌晨"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的凌晨"; break;
	       case "Default-Sun":
	       season = "晴朗的凌晨"; break;
		default: // 凌晨缺省时的描述
	       season = "晴朗的凌晨"; 
       } 
	}

      if( day_event() == "event_sunrise" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的早晨"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的早晨"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的早晨"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的早晨"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的早晨"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的早晨"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的早晨"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的早晨"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的早晨"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的早晨"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的早晨"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的早晨"; break;
	       case "Default-Sun":
	       season = "晴朗的早晨"; break;
		default: // 早晨缺省时的描述
	       season = "晴朗的早晨"; 
       } 
	}

      if( day_event() == "event_morning" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的上午"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的上午"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的上午"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的上午"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的上午"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的上午"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的上午"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的上午"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的上午"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的上午"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的上午"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的上午"; break;
	       case "Default-Sun":
	       season = "晴朗的上午"; break;
		default://上午缺省时的描述
	       season = "晴朗的上午"; 
       } 
	}

      if( day_event() == "event_noon" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的正午"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的正午"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的正午"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的正午"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的正午"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的正午"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的正午"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的正午"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的正午"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的正午"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的正午"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的正午"; break;
	       case "Default-Sun":
	       season = "晴朗的正午"; break;
		default: // 正午缺省时的描述
	       season = "晴朗的正午"; 
       } 
	}

      if( day_event() == "event_afternoon" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的下午"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的下午"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的下午"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的下午"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的下午"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的下午"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的下午"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的下午"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的下午"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的下午"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的下午"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的下午"; break;
	       case "Default-Sun":
	       season = "晴朗的下午"; break;
		default: // 下午缺省时的描述
	       season = "晴朗的下午"; 
       } 
	}

      if( day_event() == "event_evening" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的傍晚"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的傍晚"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的傍晚"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的傍晚"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的傍晚"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的傍晚"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的傍晚"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的傍晚"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的傍晚"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的傍晚"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的傍晚"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的傍晚"; break;
	       case "Default-Sun":
	       season = "晴朗的傍晚"; break;
		default: // 傍晚缺省时的描述
	       season = "晴朗的傍晚"; 
       } 
	}

      if( day_event() == "event_night" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的夜晚"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的夜晚"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的夜晚"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的夜晚"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的夜晚"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的夜晚"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的夜晚"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的夜晚"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的夜晚"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的夜晚"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的夜晚"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的夜晚"; break;
	       case "Default-Sun":
	       season = "晴朗的夜晚"; break;
		default://夜晚缺省时的描述
	       season = "晴朗的夜晚"; 
       } 
	} 

      if( day_event() == "event_midnight" ) {
       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       season = "初春的午夜"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       season = "春季的午夜"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       season = "春末的午夜"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       season = "初夏的午夜"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       season = "盛夏的午夜"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       season = "夏末的午夜"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       season = "初秋的午夜"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       season = "秋季的午夜"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       season = "深秋的午夜"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       season = "初冬的午夜"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       season = "隆冬的午夜"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       season = "冬末的午夜"; break;
	       case "Default-Sun":
	       season = "晴朗的午夜"; break;
		default: // 午夜缺省时的描述
	       season = "晴朗的午夜"; 
       } 
	}


       return season;
}

// Added By waiwai@2002/12/05
// 季节前缀需要更加准确才行
string check_month_desc()
{
	string get_season;
	string month_desc;
	get_season= NATURE_D->check_seasonF();

       switch (get_season) {
	       case "SpringA-Sun":
	       case "SpringA-Rain":
	       case "SpringA-Wind":
	       month_desc = "初春的"; break;
	       case "SpringB-Sun":
	       case "SpringB-Rain":
	       case "SpringB-Wind":
	       month_desc = "春季的"; break;
	       case "SpringC-Sun":
	       case "SpringC-Rain":
	       case "SpringC-Wind":
	       month_desc = "春末的"; break;
	       case "SummerA-Sun":
	       case "SummerA-Rain":
	       case "SummerA-Wind":
	       month_desc = "初夏的"; break;
	       case "SummerB-Sun":
	       case "SummerB-Rain":
	       case "SummerB-Wind":
	       month_desc = "盛夏的"; break;
	       case "SummerC-Sun":
	       case "SummerC-Rain":
	       case "SummerC-Wind":
	       month_desc = "夏末的"; break;
	       case "AutumnA-Sun":
	       case "AutumnA-Rain":
	       case "AutumnA-Wind":
	       month_desc = "初秋的"; break;
	       case "AutumnB-Sun":
	       case "AutumnB-Rain":
	       case "AutumnB-Wind":
	       month_desc = "秋季的"; break;
	       case "AutumnC-Sun":
	       case "AutumnC-Rain":
	       case "AutumnC-Wind":
	       month_desc = "深秋的"; break;
	       case "WinterA-Sun":
	       case "WinterA-Snow":
	       case "WinterA-Wind":
	       month_desc = "初冬的"; break;
	       case "WinterB-Sun":
	       case "WinterB-Snow":
	       case "WinterB-Wind":
	       month_desc = "隆冬的"; break;
	       case "WinterC-Sun":
	       case "WinterC-Snow":
	       case "WinterC-Wind":
	       month_desc = "冬末的"; break;
	       case "Default-Sun":
	       month_desc = "晴朗的"; break;
		default://夜晚缺省时的描述
	       month_desc = "晴朗的"; 
       } 

       return month_desc;
}
/**************************************************************************************************/

// 西游记纪年时间的生日
string check_usr_birthday(object ob)
{
	mapping date=check_time(ob->query("birthday"));
       return date["YEAR"]+date["MONTH"]+date["DAY"]+date["HOUR"];
}
/*
string check_sxt(object ob)
{
	string get_sx;
	string sxt;
	mixed *local;
	// 这个方式暂时禁止
	// 原因在chinesed.c里面已经做了说明
//	get_sx = CHINESE_D->check_sx(ob);
	get_sx = ob->query("12_sx");

       switch (get_sx) {

	       case "子鼠":
	       sxt = 
WHT"
 ◢"NOR BWHT WHT"▁"NOR"    "BWHT WHT"▁"NOR WHT"◣"WHT"
 █"BBLU BLK"▁"NOR BWHT CYN"▏"NOR BWHT BLK" ."NOR BBLU HIW"◣"NOR BWHT BLK"▁"NOR" 
    "BWHT"▁▁▁"HIR"="NOR HIR"@="HIW" 
| ◢"BBLU"◤  ◥"NOR HIW"◣
 \\ "NOR BYEL" "NOR BBLU WHT"  ×  "NOR BYEL" "NOR"
 "BWHT BLK"◢"NOR BLK BWHT"█▃▃█◣"NOR"    [生肖]：子鼠
"; break;

	       case "丑牛":
	       sxt = 
HIY"
 ◢        ◣ 
 ◥"BYEL HIY"◤    ◥"NOR HIY"◤"NOR YEL"
◥◤"NOR BYEL BLK" .  . "NOR YEL"◥◤"HIW"
  ◢"BWHT HIR" ︵︵ "NOR HIW"◣"NOR"  
  "BWHT YEL"_▁"NOR" "BWHT YEL"▁"NOR" "BWHT YEL"▁_"NOR HIY"  
    ◥"NOR BRED HIY"▁"NOR HIY"◤"NOR"       [生肖]：丑牛 
"; break;

	       case "寅虎":
	       sxt = 
YEL"
   ◣  ◢   
 ◢"BYEL BLK" .~~. "NOR YEL"◣ 
◢"NOR BYEL BLK"≡"BWHT RED"◥◤"BYEL BLK"≡"NOR YEL"◣"HIY"
 ◥"BWHT HIY"◣"BLK"∣"BWHT HIY"◢"NOR HIY"◤"HIW" 
 ◢"HIY"▆"BYEL"  "NOR HIY"▆"HIW"◣ 
 ``"NOR BYEL YEL"▆"BLK BYEL"×"NOR BYEL YEL"▆"NOR HIW"''"NOR"    [生肖]：寅虎
"; break;

	       case "卯兔":
	       sxt = 
HIW"
  ◢█  █◣"NOR"
    "BWHT RED"▌"NOR"  "BRED WHT"▌"NOR HIW" 
  ◢"NOR BWHT YEL"▔"HIR".."NOR BWHT YEL"▔"NOR HIW"◣
  ◢"NOR BWHT HIR"≡●≡"NOR HIW"◣
   ("NOR BMAG YEL"▕"NOR BWHT YEL"∣"NOR BMAG YEL"▏"NOR HIW")  
◢"NOR BWHT YEL"▕"NOR BMAG HIW",,"NOR"  "BMAG HIW",,"NOR BWHT YEL"▏"NOR HIW"◣"NOR"    [生肖]：卯兔
"; break;

	       case "辰龙":
	       sxt = 
HIY"
   ◢    ◣  
   ◥◣◢◤   
  ◥"NOR BYEL" "NOR BWHT BLK".\\/."NOR BYEL" "NOR HIY"◤  
 "HIR"__"HIY"◥"NOR BWHT BLK" ≡ "NOR HIY"◤"HIR"__ 
"HIC"◢"BCYN"◣"NOR HIY"◥"NOR BWHT".."NOR HIY"◤"NOR HIC BCYN"◢"NOR HIC"◣
"HIW"▼▼"HIY"﹋  ﹋"HIW"▼▼"NOR"    [生肖]：辰龙
"; break;

	       case "巳蛇":
	       sxt = 
HIR"
  ∩           
"HIW"◢"NOR BWHT"   "NOR HIW"◣"NOR RED"  ╲    
"HIR"` /"NOR WHT"◤"RED"◥"BWHT"╲"NOR WHT"◣"NOR RED"╲  
       ◥"NOR BWHT"╲"NOR RED"  ▎
 ◢"NOR BGRN RED"◥"NOR GRN"◣"NOR WHT"◢"RED"◤  ▌
 "HIW"◥"NOR BWHT RED"◣◣"NOR BGRN RED"◤ ◣"RED"◤"NOR"     [生肖]：巳蛇
"; break;

	       case "午马":
	       sxt =
"    "BRED" "NOR WHT"◣  ◢"NOR BRED" "NOR"     
    "HIW"◢"HIB"██"HIW"◣    
    "NOR BLU BWHT"  .◥.  "NOR"      
 "BRED WHT"▅"NOR WHT" ◥"NOR BWHT BLK"＿＿"NOR WHT"◤ "NOR BRED WHT"▅"NOR" 
 "HIW"■ ◢"NOR BWHT BLK" oo "NOR HIW"◣ ■"NOR"
 "HIW"◥ ◥"NOR BWHT HIR"▃▃"NOR HIW"◤ ◤"NOR"     [生肖]：午马
"; break;

	       case "未羊":
	       sxt = 
CYN"
   ◢◢"HIW"     
 ◢"BWHT BLK" . "NOR HIW"◣"NOR"     
 "BWHT RED"〞    "NOR HIW"         
  ◢"NOR BWHT BLK"╱    "NOR HIW"◣/"NOR"
  "BWHT BLK"▕  ▁"NOR HIW"     
  ◤◤ ◥ ◥"NOR"    [生肖]：未羊
"; break;

	       case "申猴":
	       sxt = 
HIY"
   ◢"BYEL HIW"▄▄"NOR HIY"◣"NOR"   
  "HIW"("NOR BWHT BLK"  .  .  "NOR HIW")"NOR"  
  "BYEL BLK"▔"NOR BWHT BLK" /..\\ "BYEL"▔"NOR"  
  "HIY"◥"NOR BWHT HIR" (＝) "NOR HIY"◤"NOR"  
  "HIY"█"NOR BWHT BLK"▏  ▕"NOR HIY"█"NOR"  
  "HIY"◥"NOR BWHT HIY"◣"BLK"×"HIY"◢"NOR HIY"◤"HIR"~~~"NOR"    [生肖]：申猴
"; break;

	       case "酉鸡":
	       sxt = 
"
 "HIR"◥◣◣"NOR"    
 "HIY"◢"HBWHT BLK".   "NOR"  "WHT"◢◣
  "HBWHT HIR"▉ "NOR HIW"◤◢█◣"NOR"
   "HBWHT BLK"▕,,▕"NOR HIW"▇◥
   ◥"HBWHT BLK"▔▔"NOR HIW"◤"HIY"
      ⊥"NOR"      [生肖]：酉鸡
"; break;

	       case "戌狗":
	       sxt = 
HIW"
  ,,,,"NOR"      
  "BWHT BLK" ."RED"▇"NOR"
"BWHT BLK"〞  "HIR"◥"NOR HIW"    ◢"NOR"
  "HIW"◢█◣◢◣"NOR"
  "BWHT BLK" ∣ ▁▁  "NOR"
  "HIW"◤◤  ◥◥"NOR"    [生肖]：戌狗
"; break;

	       case "亥猪":
	       sxt = 
HIW"
◢◣   ◢◣"NOR"
 "HIW"▇"NOR BWHT BLK".___."NOR HIW"▇"NOR"
"HIW"◢"NOR HIY BWHT"◢"NOR BYEL YEL"▌ "NOR HIY BWHT"◣"NOR HIW"◣"NOR"
"HIW"◥"NOR BWHT HIR" ◥"NOR BRED HIG"_"NOR BWHT HIR"◤ "NOR HIW"◤"NOR"
"HIY"◢"NOR BWHT HIY"◣"BLK"___"HIY"◢"NOR HIY"◣"NOR"
"HIW"◤◥   ◤◥"NOR"    [生肖]：亥猪
"; break;

		default:
	       sxt = ""; 
       } 

       return sxt;
}


string check_xzt(object ob)
{
	string get_xz;
	string xzt;
	mixed *local;
	get_xz = ob->query("12_xz");
}
*/
//纯数字格式，中文格式在Combated.c
//里面COMBAT_D->chinese_daoxing()
string check_daoxing(int gain)
{            int year,day,hour;
             string str;

             year=gain/1000;
             day=(gain-year*1000)/4;
             hour=(gain-year*1000-day*4)*3;
             str="";
             if(year) str=str+(year)+"年";
             if(day) str=str+(day)+"天";
             if(hour) str=str+(hour)+"时辰";

             return str;
}

string query_time(int time)
{
        string msg;
        int day, hour, min;
        
        time=time()-time;
        
        msg="";
        day=time/86400;
        hour=time%86400/3600;
        min=time/60%60;

        if(min<1)
                min=1;
        if(day)
                msg+=sprintf("%d天", day);
        if(day<10 && hour)
                msg+=sprintf("%d小时", hour);
        if(!day && hour<20 && min )
                msg+=sprintf("%d分钟", min);

        return msg;
}

string query_timec(int time)
{
        string msg;
        int day, hour, min;
        
        time=time()-time;
        
        msg="";
        day=time/86400;
        hour=time%86400/3600;
        min=time/60%60;
        if(min<1)
                min=1;
        if(day)
                msg+=sprintf("%s天", chinese_number(day));
        if(day<10 && hour)
                msg+=sprintf("%s小时", chinese_number(hour));
        if(!day && hour<20 && min)
                msg+=sprintf("%s分钟", chinese_number(min));
        return msg;
}

/**************************************************************************************************/

public int record_rumor(mixed obs, string topic, mixed event_ob)
{
        object ob;
        string title;
        int n;

        if (objectp(obs)) obs = ({ obs }); else
        if (! arrayp(obs)) return 0;

        if (! stringp(title = event_ob->query_detail(topic)))
                return 0;

        if (stringp(event_ob)) event_ob = base_name(find_object(event_ob)); else
                               event_ob = base_name(event_ob);
        n = 0;
        foreach (ob in obs) {
                if (! playerp(ob) || ! ob->query("out_family")) continue;
                if (ob->query("rumor/" + topic)) continue;
                ob->set("rumor/" + topic, event_ob);
                message("vision", "你掏出地图册，翻到最后面，写下了有关『" +
                                  topic + "』的记录。\n", ob);
                n++;
        }

        return n;
}
