#include <ansi.h>

inherit SSERVER;

int perform(object me, object target)
{
    int damage;
    string msg;
    object weapon;
    int skill;

    if (!target) target = offensive_target(me);

    if (!objectp(weapon = me->query_temp("weapon"))
        || (string)weapon->query("skill_type") != "spear")
        return notify_fail(RED"装备枪才能使用「祭枪」\n"NOR);

    if (!target) target = offensive_target(me);
    if (!target
        || !target->is_character()
        || !me->is_fighting(target) || !living(target))
        return notify_fail("你只能在战斗中使用。\n");

         if(me->query("family/family_name")!="火云洞")
             return notify_fail("你不是火云洞弟子，无法使用该技能。\n");


    if ((int)me->query_skill("huoyun-qiang", 1) < 60)
        return notify_fail("你火云枪法不够娴熟，使不出「祭枪」。\n");

    if ((int)me->query_skill("spear", 1) < 60)
        return notify_fail("你基本枪法不够娴熟，使不出「祭枪」。\n");

    if ((int)me->query_skill("huomoforce", 1) < 60)
        return notify_fail("你火魔心法过低，使不出「祭枪」。\n");

    if (me->query_skill_mapped("force") != "huomoforce")
        return notify_fail("这一招式必须配合火魔心法才能使用。\n");
    if (me->is_busy())
        return notify_fail("你现在正忙着！！\n");

    if (me->query_skill_mapped("spells") != "pingtian-dafa")
        return notify_fail("这一招式必须配合平天大法才能使用。\n");

    if ((int)me->query_skill("huomoforce", 1) < 60)
        return notify_fail("你的火魔心法火候不够，使不出「祭枪」。\n");

    if ((int)me->query("max_force") < 600)
        return notify_fail("你内力修为不足，无法运足内力。\n");

    if ((int)me->query("force") < 600) {
        return notify_fail("你现在内力不足，不能继续使用「祭枪」！\n");
    }

    skill = me->query_skill("huoyun-qiang", 1);

    message_vision(HIW"\n$N猛然大喝一声: "BLINK + HIR"「祭枪」 \n"NOR, me, target);

    msg = HIR "$N右手持枪,枪尖向左肩一划，一阵血珠溅满枪头，紧接着枪随右臂刺出，一片血光裹住漫天血光枪影向$n狂风般呼啸刺去，\n";

    if (random(me->query("combat_exp")) > (int)target->query("combat_exp") / 3)
    {
        damage = skill / 5 + random((int)target->query("max_force") / 100);
//          damage *= 3;
          damage *= 5;
        if (damage > 0) 
        {
            msg += "$n疾忙侧身避让，但血枪之光疾闪，只觉眼前一阵血红，枪尖劈面而下，鲜血飞溅，惨声大嚎！\n";
            me->add("force", -150);
            me->start_busy(2);
            target->receive_wound("kee", damage, me);
        }
    }
    else
    {
        msg += "可是$n侧身避让，不慌不忙，躲过了$N的血枪。\n";        
        me->start_busy(2 + random(2));
    }
    
    msg += NOR;
    
    message_vision(msg, me, target);

    if (!target->is_fighting(me)) 
    {
        if (living(target)) 
        {
            if (userp(target)) target->fight_ob(me);
            else target->kill_ob(me);
        }
    }

    return 1;
}
