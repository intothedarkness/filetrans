// cast...jingang.c

inherit SSERVER;

#define CD			20

int cast(object me, object target)
{
	int invocation_time;
	object soldier;

	if( !me->is_fighting() )
		return notify_fail("只有战斗中才能召唤金刚！\n");

	if( me->query("mana") < 150 )
		return notify_fail("你的法力不够了！\n");

	if(!cd_start(me, "invoke", CD)) 
		return notify_ok("你刚叫过金刚，他们都被你叫烦了！\n");
	
	me->add("mana", -150);
	
	message_vision("$N喃喃地念了几句咒语。\n", me);	

	seteuid(getuid());
	soldier = new("/obj/npc/jingang");
	soldier->move(environment(me));
	soldier->invocation(me);
	soldier->set_temp("invoker",me);

	return 1;
}


