#include <ansi.h>

inherit SSERVER;

int scribe(object me,object ob)
{
	object seal;
//add by huadao .20100630.
    if (me->is_busy() || me->query_temp("pending/exercising")
		|| me->query_temp("doing_xiudao") || me->query_temp("doing_chanting"))
		return notify_fail("你现在正忙着呢。\n");

	if( (int)me->query("mana") < 100)
		return notify_fail("你的法力不足。\n");
	if( (int)me->query("sen") < 100)
		return notify_fail("你的精神无法集中。\n");
	
	
	message_vision("$N咬破手指，伸手在桃符纸上画了几下。\n", me);
	
//modified by huadao for jjf.2010-9-27
    ob->add_amount(-1);
//	destruct(ob);

	seteuid(getuid());
	seal=new("/d/jjf/obj/peace_seal");
	seal->move(me);

	me->start_busy(2);
	return 1;
}
	
