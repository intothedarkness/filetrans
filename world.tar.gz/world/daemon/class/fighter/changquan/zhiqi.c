// zhiqi.c 窒气诀

#include <ansi.h>

inherit SSERVER;

int perform(object me)
{
        string msg;
        object weapon, target;
        int skill, ap, dp, dodge_decrease, zs_number;

        me->clean_up_enemy();
        target = me->select_opponent();

        skill = me->query_skill("changquan",1) + me->query_skill("lengquan-force",1);

        if( !me->is_fighting() )
                return notify_fail("「窒气诀」只能在战斗中使用。\n");

        if( (int)me->query("force") < 350 )
                return notify_fail("你的内力还不够高！\n");

        if( (int)me->query_skill("unarmed") < 60 )
                return notify_fail("你的拳法还不到家，无法体现长拳的必杀技巧！\n");

         if( target->is_busy() )
                return notify_fail(target->name() + "目前正自顾不暇，不必使用「窒气诀」了！\n");

        if( (int)me->query_skill("changquan", 1) < 60)
                return notify_fail("你长拳的修为不够，不能够体会窒气诀! \n");

        if( (int)me->query_skill("lengquan-force", 1) < 60)
                return notify_fail(HIM "你的冷泉神功修为不足，不能随便使用窒气诀! \n" NOR);

        if(me->query("family/family_name")!="将军府")
                return notify_fail("你不能用别派的特殊攻击\n");

        if( me->query_skill_mapped("unarmed") != "changquan")
                return notify_fail("你没有激发长拳，无法运用窒气诀！\n");

        msg = HIY "$N大喝一声，使出长拳中的必杀技「" HIR "窒气诀" HIY "」，双拳势如雷霆，向$n击去。\n"NOR;
        message_vision(msg, me, target);

        ap = me->query("combat_exp") / 2 + skill * 500;
        dp = target->query("combat_exp") / 3;
        if( dp < 1 )
                dp = 1;

	zs_number=(int)me->query("reincarnation/number") - (int)target->query("reincarnation/number");

//        if( random(ap) > dp )
//每一次转生会影响1/3的基础数据。changed by huadao.2019.04.10
        if( random(ap*(1+zs_number/3)) > dp )
        {
                if(userp(me))
                        me->add("force",-100);
                msg = HIG"$N的拳风隐含风雷，“澎”的一声打在$n身上！\n"NOR;
                msg += HIB"$n只觉得一阵疾风刮过，顿时呼吸不畅，脚步不由慢了下来！\n"NOR;
                dodge_decrease = (int)target->query("apply/dodge") / 8;
                target->add_temp("apply/dodge", -dodge_decrease);
                target->start_busy(4);
                me->start_busy(random(2));
        }
        else
        {
                msg = HIG"$n似乎有所感应，连忙倒退数丈，闪过了那阵疾风！\n"NOR;
                if(userp(me)) me->add("neili",-100);
//              target->start_busy(4);
//这里是个大bug，中与不中对方都有busy，而且不中效果更好，紧急修复。modify by huadao,20181220.
                me->start_busy(2);
//增加失败后自己的busy，原先失败后对方有busy，自己么有，现在增加为固定2秒。added by huadao .2018.12.20.
        }
		message_vision(msg, me, target);
		return 1;
}
