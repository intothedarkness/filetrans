//呆呆拳  大米也疯狂 ：D

#include <ansi.h>

inherit SSERVER;

int perform(object me, object target)
{
        object weapon;
	string msg,str;         
	if( !target ) target = offensive_target(me);

        if( !target
        ||      !target->is_character()
        ||      target->is_corpse()
        ||      target==me)
                return notify_fail("你要对谁施展呆呆拳？\n");

        if(!me->is_fighting())
                return notify_fail("呆呆拳只能在战斗中使用！\n");
                
        if( time()-(int)me->query_temp("xiao_end") < 5 )
          return notify_fail("绝招用太多容易被对手看破！\n");

        if((int)me->query("force") < 100 )
                return notify_fail("你的内力不够！\n");

        if((int)me->query("kee") < 200 )
                return notify_fail("你的气血不足，没法子施用外功！\n");

        if((int)me->query_skill("idle-foce", 1) < 100)
                return notify_fail("你的发呆大法还不够呆，无法呆住别人！\n");

	me->delete("env/brief_message");

	message_vision("\n$N一个划步,竟打出一套组合拳！\n", me);

	COMBAT_D->do_attack(me, target, me->query_temp("weapon"));
        COMBAT_D->do_attack(me, target, me->query_temp("weapon"));
	COMBAT_D->do_attack(me, target, me->query_temp("weapon"));
	me->receive_damage("kee", 30);
	me->add("force", -10);
	
        if( !target->is_fighting(me) ) {
                if( living(target) ) {
                        if( userp(target) ) target->fight_ob(me);
                        else target->kill_ob(me);
                }
        }
        if (target->query("eff_kee")<0 || (!living(target) && target->query("kee")<0))  
                       {
                       	str=target->name()+HIM"被"+me->name()+"用一招"NOR+HIW"「呆呆拳」"+HIM"打死了。";
	                 message("channel:rumor",HIM"【谣言】某人："+str+"\n"NOR,users());
	               }
        me->set_temp("xiao_end",time());
	me->start_busy(2);
	return 1;
}

