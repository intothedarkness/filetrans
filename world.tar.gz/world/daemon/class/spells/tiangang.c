// Created by huadao for reincarnation's tiangang skills.20140502
// Modified by Rocky to shuffle the fake objects.
// 地煞技能可以召唤强力npc协助防御；
// npc随着转生次数的提升，个数成倍增长；
// npc完全符合玩家本身属性，防PK利器；

#define DEBUG 0

#include <ansi.h>
inherit SSERVER;

int cast(object me, object target)
{
	int tiangang_time, i; 
	object soldier;
    object * objs;
    int num = ( (int)me->query("reincarnation/number") - 6 );


	tiangang_time= 120; 

	if( me->query("reincarnation/number") < 6 
		|| !me->query("reincarnation/number") 
		|| me->query("reincarnation/skills/tiangang_learned") != "done")
		return notify_fail("什么？\n");

	if( (time()-me->query("last_tiangang")) < tiangang_time )
		return notify_fail("泼怪，休得心焦气躁！\n");
	
	if( (int)me->query("mana") <4*(int)me->query_skill("spells"))
		return notify_fail("你的法力不够了！\n");

	if( (int)me->query("sen") < 200 )
		return notify_fail("你的精神无法集中！\n");

	me->add("mana", -100*( (int)me->query("reincarnation/number") - 5 ) );

	message_vision(HIC "$N使一个身外身的手段：把毫毛揪下一把，用口嚼得粉碎，望上一喷，叫声“变”！变有" +chinese_number((int)me->query("reincarnation/number") - 5)+ "个"+me->query("name")+"，都是一样打扮！\n" NOR, me);

    for(i = 0; i < num+1; ++i)
	{
#if DEBUG
        printf("i = %d\n", i);
#endif        
    	soldier = new("/obj/npc/tiangang_hufa");    	
        soldier->move(environment(me));
    	soldier->invocation(me);
    	soldier->set_temp("invoker",me);
    	me->set("last_tiangang",time());
	}
    
    // shuffle the ID list to protect the real one.
   	message_vision(HIC "$N的眼前一花，人影晃来晃去，你分不清哪个是真哪个是假。\n" NOR, me);
    objs = all_inventory(environment(me));
    shuffle(objs);
        
    for (i = 0; i < sizeof(objs); i ++)
    {
        objs[i]->move(environment(me));
    }
    
	return 1;
}

int help (object me)
{
        write(@HELP
指令格式: cast disha

天罡技能可以召唤强力npc协助防御；
召唤的npc随着转生次数的提升，个数和威力极大增长；

HELP );
	return 1;
}
