// cracked by huadao.2019.11.08
//三头六臂,主旨busy技，附带其他效果。
//三头八臂
 
#include <ansi.h>
inherit SSERVER;

int cast(object me, object target)
{
	object *inv, obj, ridee;
	object where = environment(me);
	string msg, *hit, *miss, *hitone, *missone, *hittwo, *misstwo, *hitthree, *missthree, *hitfour, *missfour, *cast1, *cast2;

	//Sn=n*a1+n(n-1)d/2
	//武学道行等差为5M，算上转生，学习和练功的时间，实际计算时用10M。
	//法力等差为100，实际计算用200。
	int d = 10000000;
	int how_long = 0;
	int cost_mana = 0;
	int last_buddha, success, i, targeteffkee, targeteffsen;
	int myzs, mycon, myspi, mykar, mystr, myint, mycor, myper, mycps, myexp, mydx, mymana;
	int targetzs, targetcon, targetspi, targetkar, targetstr, targetint, targetcor, targetper, targetcps, targetexp, targetdx, targetmana;

	mystr = (int)me->query("str");
	mycon = (int)me->query("con");
	myint = (int)me->query("int");
	myspi = (int)me->query("spi");
	myper = (int)me->query("per");
	mycps = (int)me->query("cps");
	mycor = (int)me->query("cor");
	mykar = (int)me->query("kar");
	myzs = (int)me->query("reincarnation/number");
	myexp = (int)((me->query("combat_exp")+myzs*30000000+myzs*(myzs-1)*d/2)/10000);
	mydx = (int)((me->query("daoxing")+myzs*30000000+myzs*(myzs-1)*d/2)/10000);
	mymana = (int)((me->query("mana")+myzs*200+myzs*(myzs-1)*200/2));

	if( !target ) target = offensive_target(me);

	if( !target
	||	 !target->is_character()
	||	 target->is_corpse()
	||	 target==me)
	return notify_fail("不在战斗中，现什么形？\n");

	if( !wizardp(me) )
	{
	if( myzs	< 11 )
	return notify_fail("你所学的法术中没有这种功能。\n");
	
	if( time()-me->query("last_buddha") <	(60-myzs) ) 
	return notify_fail("泼怪，稍安勿躁！\n");

	if( target->is_busy() )
	return notify_fail("不必恃强，你且暂退。\n");

	if( me->query("mana")	< 1000 )
	return notify_fail("你的法力不够了！\n");
	}

	targetstr = (int)target->query("str");
	targetcon = (int)target->query("con");
	targetint = (int)target->query("int");
	targetspi = (int)target->query("spi");
	targetper = (int)target->query("per");
	targetcps = (int)target->query("cps");
	targetcor = (int)target->query("cor");
	targetkar = (int)target->query("kar");
	targetzs = (int)target->query("reincarnation/number");
	targetexp = (int)((target->query("combat_exp")+targetzs*30000000+targetzs*(targetzs-1)*d/2)/10000);
	targetdx = (int)((target->query("daoxing")+targetzs*30000000+targetzs*(targetzs-1)*d/2)/10000);
	targeteffkee=(int)target->query("eff_kee");
	targeteffsen=(int)target->query("eff_sen");
	targetmana = (int)((target->query("mana")+targetzs*200+targetzs*(targetzs-1)*200/2));

	obj=me->query_temp("weapon");

//乾坤圈
//(exp)
//(str)
//(con)
	hitone = ({
	HIY "$n只顾苦战，却不知天上坠下这兵器，打中了天灵，立不稳脚，跌了一跤。\n\n" NOR,
	HIY "$n不曾提防，夹颈一圈，“呵呀”一声，跌倒在地。\n\n" NOR,
	HIY "见此宝落将下来，$n方要脱身，怎免此厄，正中顶上。\n\n" NOR,
	HIY "$n躲不及，正中顶门，脑浆迸出。\n\n" NOR,
	HIY "正中$n顶门，打得脑浆迸出，翻跌在地。\n\n" NOR,
	HIY "正落在$n头上，只打的脑浆迸流，在地上挺直。\n\n" NOR,
	HIY "正中$n后心，打了个饿虎扑食，跌倒在地。\n\n" NOR,
	HIY "打中$n肩甲，打了个带断皮开，筋断骨折。\n\n" NOR,
	});
	missone = ({
	HIY "$n用指上放一道白光如线，长出一朵庆云，高有数丈，上有八角，角上乃金灯，缨络垂珠，护持顶上。\n\n乾坤圈见金灯自然消化，毫不能伤。\n\n" NOR,
	HIY "$n用左手一指，指上放出一道白光，高有一二丈，顶上现一朵庆云，旋在空中护于顶上。\n\n乾坤圈方至顶云，如雪见烈焰一般，自灭无踪。\n\n" NOR,
	HIY "$n顶上现庆云，有一亩田大，上放五色毫光，金灯万盏，点点落下，如檐前滴水不断。\n\n那乾坤圈未到跟前，已化作灰尘飞去。\n\n" NOR,
	HIY "$n看见乾坤圈落下来，把袖口望上一迎。\n\n乾坤圈如芥子落于大海之中，毫无动静。\n\n" NOR,
	HIY "$n把口一张，有斗大一朵金莲喷出。\n\n左手五指里有五道白光垂地倒往上卷，白光顶上有一朵莲花，花上有五盏金灯。\n\n那圈不粘其身，自然安妥。\n\n" NOR,
	HIY "$n大呼曰：“来的好！”口吐金花，把乾坤圈敌住在空中。\n\n乾坤圈只是乱翻，不得落将下来。\n\n" NOR,
	});
//混天绫
//(dx)
//(int)
//(spi)
	hittwo = ({
	HIR "只见光华灿烂，漫天烈火，将$n就平空的拿去。\n\n" NOR,
	HIR "迸发红光万丈，金光散去已将$n缚得笔直。\n\n" NOR,
	HIR "只听得一声响，将$n拿去，绑缚起来。\n\n" NOR,
	HIR "只见一道金光，就将$n平空的拿去了。\n\n" NOR,
	HIR "只见光华灿烂，$n已被拿了。\n\n" NOR,
	HIR "一道金光，如电射目，已将$n拿住。\n\n" NOR,
	});
	misstwo = ({
	HIR "$n笑曰：“来得好！”\n\n急忙取出一个金钱，也祭起空中。\n\n只见混天绫跟着金钱落在地上，都被$n收了。\n\n" NOR,
	});
//金砖
//(mana)
//(per)
//(cps)
	hitthree = ({
	HIY "正中$n，打了护心镜，纷纷粉碎。\n\n" NOR,
	HIY "正中$n，只打的星飞云散，瓦解冰消。\n\n" NOR,
	HIY "正中$n后心，当真霞光万道，魂飞魄散。\n\n" NOR,
	HIY "正中$n肩甲，扑的打了一跌，三魂出窍。\n\n" NOR,
	HIY "正中$n顶门上，打得个一派金光，散漫于地。\n\n" NOR,
	HIY "正中$n肩窝，打的筋断骨折，跌倒在地。\n\n" NOR,
	HIY "正中$n臂膊，打的皮开肉绽，血肉横飞。\n\n" NOR,
	});
	missthree = ({
	HIY "$n笑曰：“此小物也！”\n\n用中指一指，金砖落在地下，毫不能伤。\n\n" NOR,
	HIY "$n用手一指：“此物不落，更待何时？”\n\n金砖落将下来，成为齑粉。\n\n" NOR,
	HIY "$n把身子一扭，杳然无迹无踪。\n\n" NOR,
	HIY "$n四下吃亏，大叫一声，借土遁走了。\n\n" NOR,
	HIY "$n见事不好，借土遁化清风而去。\n\n" NOR,
	});
//九龙神火罩
//(zs)
//(cor)
//(kar)
	hitfour = ({
	HIR "$N用手一拍，只见九条火龙一齐吐出烟火，遍地烧来。\n\n" NOR,
	HIR "$N用两手一拍，那罩内腾腾焰起，烈烈火生，九条火龙盘绕。\n\n一声雷响，把$n真形炼出。\n\n" NOR,
	HIR "$N双手一拍，只见现出九条火龙，将罩盘绕，$n顷刻烧成灰烬。\n\n" NOR,
	HIR "$N把手一拍，罩里现出九条火龙围绕，霎时间，$n化灰烬。\n\n" NOR,
	});
	missfour = ({
	HIR "$n见罩落将下来，知道不好，一个翻身，就地下去了。\n\n" NOR,
	HIR "$n叫声：“哎呀！”化道青光逃去。\n\n" NOR,
	HIR "$n情知：“不好！”化道赤光闪去。\n\n" NOR,
	HIR "$n喝道：“疾！”化道青气飞去。\n\n" NOR,
	HIR "哪知$n法术神奇，反借火光遁去。\n\n" NOR,
	});
//总结
	hit = ({
	HIR "$N笑曰："+target->name()+HIR"，你今日难免此厄也！\n\n" NOR,
	HIR "$N在光里言曰：“"+target->name()+HIR"，今日放不得你！”\n\n" NOR,
	HIR "$N厉声曰：“"+target->name()+HIR"！休想回去！此处乃是你归天之地！”\n\n" NOR,
	HIR "$N大呼曰：“"+target->name()+HIR"！你不可情强，此处是你的死地了！”\n\n" NOR,
	});
	miss = ({
	HIR "$n笑曰：“米粒之珠，也放光华。”\n\n"NOR,
	HIR "$n叫道：“"+me->name()+HIR"，再把你的宝贝用几件来，看我法术如何？”\n\n"NOR,
	HIR "$n笑曰：“万邪岂能侵正。”\n\n"NOR,
	HIR "$n叫声：“不好！”将身一闪，让个空。”\n\n"NOR,
	});
	cast1 = ({
	HIC "\n$N奋怒，大喝一声，叫：“变！”\n\n"NOR,
	HIC "\n三头六臂惊天地，忿怒哪吒扑帝钟。\n\n"NOR,
	HIC "\n忽若忿怒哪吒，忽若日面月面。\n\n"NOR,
	HIC "\n$N大喝一声“变！”\n\n"NOR,
	HIC "\n$N喝声“莫无礼，看我神通！”\n\n"NOR,
	});
if (!me->query_temp("weapon"))
	{
	cast2 = ({
	HIC "$N变做三头六臂，恶狠狠，手中兵器，变做千千万万，着$n就打！\n\n\n"NOR,
	HIC "$N现了三头六臂，恶狠狠，手持六般兵器，丫丫叉叉，扑面来打！\n\n\n"NOR,
	HIC "$N变做三头六臂，把手中兵器幌一幌，变作万万千千，真个好杀！\n\n\n"NOR,
	});
	} else {
	obj=me->query_temp("weapon");
	cast2 = ({
	HIC "$N变做三头六臂，恶狠狠，手中"+obj->name()+HIC"，变做千千万万，着$n就打！\n\n\n"NOR,
	HIC "$N现了三头六臂，恶狠狠，手持"+obj->name()+HIC"，丫丫叉叉，扑面来打！\n\n\n"NOR,
	HIC "$N变了三头六臂，把手中"+obj->name()+HIC"幌一幌，变作万万千千，真个好杀！\n\n\n"NOR,
	HIC "$N现出三头六臂，把"+obj->name()+HIC"幌一幌，变作三"+(string)obj->query("unit")+HIC"，雨点流星般打来！\n\n\n"NOR,
	});
	}

	msg = cast1[random(sizeof(cast1))];
	msg += cast2[random(sizeof(cast2))];

	//乾坤圈，第一打。
	//双随机；
	//几率打碎手持当前兵器，自制法宝除外。
	//几率气血当前/上限均减少1/5；
	msg += HIY "$N祭起乾坤圈，自天门上往下一掼，滴流流的着$n头上打去！\n\n"NOR;
	cost_mana += 10*myzs;

	if( (int)(myexp*2/3+random(myexp/3)) > (int)(targetexp*2/3+random(targetexp/3)) )
	{
	success += 1;
	how_long += 1*myzs;

	msg += hitone[random(sizeof(hitone))];

	if (target->query_temp("weapon") )
	{
	if( (myzs > random(100)) && (random(mystr) > random(targetstr)) )
	{
	//次要武器
	obj=target->query_temp("secondary_weapon");
	if ( obj && !obj->query("owner_id") && !obj->query("series_no"))
	{
	obj->unequip();
	obj->set("value", 0);
	msg += HIY "只听见「啪」地一声，"+target->name()+"手中的"+obj->name()+HIY"已经断为两截！\n\n"NOR;
	obj->set("name", "断掉的"+obj->query("name"));
	obj->set("weapon_prop", 0);
	obj->set("armor_prop", 0);
	obj->move(environment(target));
	call_out("remove_broken_cloth",random(30)+15,obj);
	}
	//主要武器
	obj=target->query_temp("weapon");
	if ( obj && !obj->query("owner_id") && !obj->query("series_no")) 
	{
	obj->unequip();
	obj->set("value", 0);
	msg += HIY "只听见「啪」地一声，"+target->name()+"手中的"+obj->name()+HIY"已经断为两截！\n\n"NOR;
	obj->set("name", "断掉的"+obj->query("name"));
	obj->set("weapon_prop", 0);
	obj->set("armor_prop", 0);
	obj->move(environment(target));
	call_out("remove_broken_cloth",random(30)+15,obj);
	}
	target->delete_temp("apply/damage");
	}
	}

	if( (myzs > random(100)) && (random(mycon) > random(targetcon)) )
	{
	target->receive_wound("kee", targeteffkee/5);
	target->receive_damage("kee", targeteffkee/5);
	if( wizardp(me) ) msg += HIW"测试：$n气血被打掉1/5上限！\n\n"NOR;
	}
	} else msg += missone[random(sizeof(missone))];

	//混天绫，第二打。
	//双随机；
	//几率有坐骑，拿掉；
	//几率精神当前/上限均减少1/3；
	//水中，busy翻倍；
	//若失败，把施法者身上的gold全部拿走。
	msg += HIR "\n$N把七尺混天绫望空一展，似火块千团，往下一裹！\n\n"NOR;
	cost_mana += 15*myzs;
	if( (int)(mydx*2/3+random(mydx/3)) > (int)(targetdx*2/3+random(targetdx/3)) )
	{
	msg += hittwo[random(sizeof(hittwo))];
	success += 1;
	how_long += 3*myzs;
	ridee = target->query_temp("ridee");

	if ( ridee )
	{
	if( (myzs > random(100)) && (random(myint) > random(targetint)) )
	{
	msg += HIR "$n坠下"+ridee->name()+"，滚落在地。\n\n"NOR;
	target->set_temp("ridee",0);	
	target->add_temp("apply/dodge",-target->query_temp("ride/dodge"));
	target->set_temp("ride/dodge",0);
	}
	}

	if( (myzs > random(100)) && (random(myspi) > random(targetspi)) )
	{
	target->receive_wound("sen", targeteffsen/3);
	target->receive_damage("sen", targeteffsen/3);
	if( wizardp(me) ) msg += HIW"测试：$n精神被打掉1/3上限！\n\n"NOR;
	}

	if ( where->query("water") )
	{
 msg += HIR "\n混天绫挥舞甩动时，红光万道，赤染水色。\n\n摆一摆，江河晃动；摇一摇，乾坤动撼！\n\n"NOR;
	how_long += 3*myzs;
	}
	} else {
	if ( present("gold", this_player()) )
	{
	present("gold", me)->move(target);
	if( wizardp(me) ) msg += HIW"测试：$N身上的黄金都被$n收走了！\n\n"NOR;
	}
 msg += misstwo[random(sizeof(misstwo))];
	}

	//金砖，第三打。
	//双随机；
	//几率身上穿戴的装备全部打碎，自制法宝除外；
	//几率当前气血、精神减少1/2。
	//保留一下，再增加三头八臂，多一打。西游记应该比较法力。
	//计算法力时候，要引入转生次数。
 msg += HIY"\n$N手取金砖一块，丢起空中，喝声：“疾！”\n\n"NOR;
 cost_mana += 20*myzs;
	if( (int)(mymana*2/3+random(mymana/3)) > (int)(targetmana*2/3+random(targetmana/3)) )
	{
	inv = all_inventory(target);
	i = sizeof(inv);

	msg += hitthree[random(sizeof(hitthree))];
	success += 1;
	how_long += 5*myzs;

	if( (myzs > random(100)) && (random(myper) > random(targetper)) )
	{
	if( target->query_temp("armor") )
	{
	for (i=0; i < sizeof(inv); i++ ) 
	{
	obj = inv[i];
	if( obj->query("equipped") != "worn" ) continue;
	if( obj->query("owner_id") && obj->query("series_no") ) continue;
	obj->delete("equipped");
	obj->set("value", 0);
	obj->set("No_Wear", 1);
	msg += HIY"$n身上的"+obj->name()+HIY"被打的粉碎！\n\n"NOR;
	obj->set("name", "破碎的"+obj->query("name"));
	call_out("remove_broken_cloth",random(30)+15,obj);
	obj->move(environment(target));
	}
	target->delete_temp("apply/armor");
	}
	}

	if( (myzs > random(100)) && (random(mycps) > random(targetcps)) )
	{
	target->receive_damage("kee", target->query("kee")/2);
	target->receive_damage("sen", target->query("sen")/2);
	if( wizardp(me) ) msg += HIW"测试：$n精神、气血被打掉1/2！\n\n"NOR;
	}
} else msg += missthree[random(sizeof(missthree))];


	if( (int)me->query("reincarnation/skills/buddha_time") > 99 )
	//巫师专用，条件暂定。
	//这里可以设置为，团队副本掉落的东西，枣子，酒，吃到一定数量，开启终极技能。
	//暂定为100
	{
	//九龙神火罩，第四打。
	//双随机；
	//几率身上的灵丹妙药全部消失。
	//几率气血上限变0，当前气血变为-1。
	//几率精神上限变0，当前精神变为-1。
	//对方屏蔽指令，玩家和npc不同时长。
 msg += HIC"\n只听得左右齐响，$N又长出两只手来，竟是八臂"+me->name()+HIC"！\n\n諕得$n目瞪口呆！\n\n"NOR;
 msg += HIR"\n$N将身一跃，跳出圈子外来，将九龙神火罩抛起空中。\n\n$n见罩，欲避不出，已罩在里面。\n\n"NOR;
 cost_mana += 25*myzs;
	if( myzs > targetzs )
	{
	inv = all_inventory(target);
	i = sizeof(inv);

	msg += hitfour[random(sizeof(hitfour))];
	success += 1;
	how_long += 7*myzs;

	if( random(myzs) > random(targetzs) )
	{
	for (i=0; i < sizeof(inv); i++ )
	{
	obj = inv[i];
	if( !obj->query("drug_type") ) continue;
	msg += HIR"$n身上的"+obj->name()+HIR"顿时化为灰烬！\n\n"NOR;
	if( wizardp(me) ) msg += HIW"测试：$n身上的丹药顿时化为灰烬！\n\n"NOR;
	destruct(obj);
	}
	}

	if( (myzs > random(100)) && (random(mycor) > random(targetcor)) )
	{
	target->receive_damage("kee", target->query("kee")*2);
	target->receive_wound("kee", targeteffkee);
	if( wizardp(me) ) msg += HIW"测试：$n气血被打成0！\n\n"NOR;
	}

	if( (myzs > random(100)) && (random(mykar) > random(targetkar)) )
	{
	target->receive_damage("sen", target->query("sen")*2);
	target->receive_wound("sen", targeteffsen);
	if( wizardp(me) ) msg += HIW"测试：$n精神被打成0！\n\n"NOR;
	}
	} else msg += missfour[random(sizeof(missfour))];
	}

	if( !wizardp(me) ) me->add("mana", -(cost_mana));

	if(success)
	{
////玩家到底busy多少时间，再考虑，斟酌。此处需要修改。
	if ( userp(target) && how_long > 60 ) how_long = 60;
	target->start_busy(how_long);
	msg += hit[random(sizeof(hit))];
	}
	else
	{
	msg += miss[random(sizeof(miss))];
	}

	if( living(target) )
	{
	target->set_temp("block_msg/all",0);
	message_vision(msg, me, target);
	}

	if( !wizardp(me) ) me->start_busy(random(myzs-10));

	if(success)
	{
	remove_call_out("wakeup");
	target->set_temp("block_msg/all",1);
	if(userp(target) )
	{
	call_out("wakeup", how_long/myzs, target);
	}	else
	{
	call_out("wakeup", how_long, target);
	}
	}

	if( wizardp(me) )
	{
	tell_object(me, sprintf( HIW "结果：命中：%d， BUSY：%d， 致盲：%d\n" NOR, success, how_long, how_long/myzs));
	tell_object(me, sprintf( HIW "我的：转生：%d，武学：%d，道行：%d，法力：%d，臂力：%d，根骨：%d，悟性：%d，灵性：%d，胆识：%d，福源：%d，容貌：%d，定力：%d\n" NOR, myzs, myexp, mydx, mymana, mystr, mycon, myint, myspi, mycor, mykar, myper, mycps));
	tell_object(me, sprintf( HIW "他的：转生：%d，武学：%d，道行：%d，法力：%d，臂力：%d，根骨：%d，悟性：%d，灵性：%d，胆识：%d，福源：%d，容貌：%d，定力：%d\n" NOR, targetzs, targetexp, targetdx, targetmana, targetstr, targetcon, targetint, targetspi, targetcor, targetkar, targetper, targetcps));
	}
	target->kill_ob(me);
	if(!wizardp(me)) { me->set("last_buddha",time()); }

	return 1;
}

void remove_broken_cloth(object obj)
{
	if(obj && environment(obj)) {
	tell_object(environment(obj), "一阵微风吹过，"+obj->name()+"化为片片尘土，消失不见了。\n");
	destruct(obj);
	}
}

void wakeup(object target)
{
	if(!target) return;

	target->set_temp("block_msg/all", 0);
}
