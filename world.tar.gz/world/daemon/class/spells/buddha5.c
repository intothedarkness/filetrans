// cracked by huadao.2019.11.08
//三头六臂,主旨busy技，附带其他效果。
 
#include <ansi.h>
inherit SSERVER;

int cast(object me, object target)
{
  object *inv, obj, ridee;
  object where = environment(me);
  string msg, *hit, *miss, *hitone, *missone, *hittwo, *misstwo, *hitthree, *missthree, *cast1, *cast2;

  //Sn=n*a1+n(n-1)d/2
  //等差为5M，算上转生，学习和练功的时间，实际计算时用10M。
  int d = 10000000;
  int how_long = 0;
  int cost_mana = 0;
  int last_buddha, success, i, targeteffkee, targeteffsen;
  int myzs, mycon, myspi, mykar, mystr, myint, mycor, myexp, mydx;
  int targetzs, targetcon, targetspi, targetkar, targetstr, targetint, targetcor, targetexp, targetdx;

  myzs = (int)me->query("reincarnation/number");
  mycon = (int)me->query_con();
  myspi = (int)me->query_spi();
  mykar = (int)me->query_kar();
  mystr = (int)me->query_str();
  myint = (int)me->query_int();
  mycor = (int)me->query_cor();
  myexp = (int)((me->query("combat_exp")+myzs*30000000+myzs*(myzs-1)*d/2)/10000);
  mydx = (int)((me->query("daoxing")+myzs*30000000+myzs*(myzs-1)*d/2)/10000);

  targetzs = (int)target->query("reincarnation/number");
  targetcon = (int)target->query_con();
  targetspi = (int)target->query_spi();
  targetkar = (int)target->query_kar();
  targetstr = (int)target->query_str();
  targetint = (int)target->query_int();
  targetcor = (int)target->query_cor();
  targetexp = (int)((target->query("combat_exp")+targetzs*30000000+targetzs*(targetzs-1)*d/2)/10000);
  targetdx = (int)((target->query("daoxing")+targetzs*30000000+targetzs*(targetzs-1)*d/2)/10000);
  targeteffkee=(int)target->query("eff_kee");
  targeteffsen=(int)target->query("eff_sen");

  if( !wizardp(me) )
	{
	  if( myzs  < 11 )
		return notify_fail("你所学的法术中没有这种功能。\n");
	  
	  if( time()-me->query("last_buddha") <  (60-myzs) ) 
		return notify_fail("泼怪，稍安勿躁！\n");

	  if( !target ) target = offensive_target(me);
	  if( !target
		   ||  !living(target)
		   || !target->is_character()
		   || !me->is_fighting(target) )
		return notify_fail("不在战斗中，现什么形？\n");

	  if( target->is_busy() )
		return notify_fail("不必恃强，你且暂退。\n");

	  if( me->query("mana")  < 1000 )
		return notify_fail("你的法力不够了！\n");
	}

		obj=me->query_temp("weapon");

//乾坤圈
//(str)
//(con)
  hitone = ({
    HIC "$n只顾苦战，却不知天上坠下这兵器，打中了天灵，立不稳脚，跌了一跤。\n\n" NOR,
    HIC "$n不曾提防，夹颈一圈，“呵呀”一声，跌倒在地。\n\n" NOR,
    HIC "见此宝落将下来，$n方要脱身，怎免此厄，正中顶上。\n\n" NOR,
    HIC "$n躲不及，正中顶门，脑浆迸出。\n\n" NOR,
    HIC "正中$n顶门，打得脑浆迸出，翻跌在地。\n\n" NOR,
    HIC "落在$n头上，只打的脑浆迸流，在地上挺直。\n\n" NOR,
    HIC "正中$n后心，打了个饿虎扑食，跌倒在地。\n\n" NOR,
    HIC "打中$n肩甲，打了个带断皮开，筋断骨折。\n\n" NOR,
  });
  missone = ({
    HIC "$n用指上放一道白光如线，长出一朵庆云，高有数丈，上有八角，角上乃金灯，缨络垂珠，护持顶上。\n\n乾坤圈见金灯自然消化，毫不能伤。\n\n" NOR,
    HIC "$n用左手一指，指上放出一道白光，高有一二丈，顶上现一朵庆云，旋在空中护于顶上。\n\n乾坤圈方至顶云，如雪见烈焰一般，自灭无踪。\n\n" NOR,
    HIC "$n顶上现庆云，有一亩田大，上放五色毫光，金灯万盏，点点落下，如檐前滴水不断。\n\n那乾坤圈未到跟前，已化作灰尘飞去。\n\n" NOR,
    HIC "$n看见乾坤圈落下来，把袖口望上一迎。\n\n乾坤圈如芥子落于大海之中，毫无动静。\n\n" NOR,
    HIC "$n把口一张，有斗大一朵金莲喷出。\n\n左手五指里有五道白光垂地倒往上卷，白光顶上有一朵莲花，花上有五盏金灯。\n\n那圈不粘其身，自然安妥。\n\n" NOR,
    HIC "$n大呼曰：“来的好！”口吐金花，把乾坤圈敌住在空中。\n\n乾坤圈只是乱翻，不得落将下来。\n\n" NOR,
  });
//混天绫
//(int)
//(spi)
  hittwo = ({
    HIR "只见光华灿烂，漫天烈火，将$n就平空的拿去。\n\n" NOR,
    HIR "迸发红光万丈，金光散去已将$n缚得笔直。\n\n" NOR,
    HIR "只听得一声响，将$n拿去，绑缚起来。\n\n" NOR,
    HIR "只见一道金光，就将$n平空的拿去了。\n\n" NOR,
    HIR "只见光华灿烂，$n已被拿了。\n\n" NOR,
    HIR "一道金光，如电射目，已将$n拿住。\n\n" NOR,
  });
  misstwo = ({
    HIR "$n笑曰：“来得好！”\n\n急忙取出一个金钱，也祭起空中。\n\n只见混天绫跟着金钱落在地上，都被$n收了。\n\n" NOR,
  });
//金砖
//(cor)
//(kar)
  hitthree = ({
    HIY "正中$n，打了护心镜，纷纷粉碎。\n\n" NOR,
    HIY "正中$n，只打的星飞云散，瓦解冰消。\n\n" NOR,
    HIY "正中$n后心，当真霞光万道，魂飞魄散。\n\n" NOR,
    HIY "正中$n肩甲，扑的打了一跌，三魂出窍。\n\n" NOR,
    HIY "正中$n顶门上，打得个一派金光，散漫于地。\n\n" NOR,
    HIY "正中$n肩窝，打的筋断骨折，跌倒在地。\n\n" NOR,
    HIY "正中$n臂膊，打的皮开肉绽，血肉横飞。\n\n" NOR,
  });
  missthree = ({
    HIY "$n笑曰：“此小物也！”\n\n用中指一指，金砖落在地下，毫不能伤。\n\n" NOR,
    HIY "$n用手一指，“此物不落，更待何时？”\n\n金砖落将下来，成为齑粉。\n\n" NOR,
    HIY "看$n把身子一扭，杳然无迹无踪。\n\n" NOR,
    HIY "$n四下吃亏，大叫一声，借土遁走了。\n\n" NOR,
    HIY "$n见事不好，借土遁化清风而去。\n\n" NOR,
  });
//总结
  hit = ({
    HIY "$N笑曰：“" + target->name() + "，你今日难免此厄也！”\n\n" NOR,
    HIY "$N在光里言曰：“" + target->name() + "，今日放不得你！”\n\n" NOR,
    HIY "$N大呼曰：“" + target->name() + "！休想回去！此处乃是你归天之地！”\n\n" NOR,
    HIY "$N大呼曰：“" + target->name() + "，你不可情强，此处是你的死地了！”\n\n" NOR,
  });
  miss = ({
    HIY "$n笑曰：“米粒之珠，也放光华。”\n\n"NOR,
    HIY "$n叫道：“" + target->name() + "，再把你的宝贝用几件来，看我法术如何？”\n\n"NOR,
    HIY "$n笑曰：“万邪岂能侵正。”\n\n"NOR,
    HIY "$n叫声：“不好！”将身一闪，让个空。”\n\n"NOR,
  });
  cast1 = ({
    HIC "\n$N奋怒，大喝一声，叫：“变！”\n\n"NOR,
    HIC "\n三头六臂惊天地，忿怒" + me->name() + "扑帝钟。\n\n"NOR,
    HIC "\n忽若忿怒" + me->name() + "，忽若日面月面。\n\n"NOR,
    HIC "\n大喝一声“变！”\n\n"NOR,
  });
  cast2 = ({
    HIC "$N变做三头六臂，恶狠狠，手持六般兵器，如骤雨冰雹，纷纷密密，着$n就打！\n\n\n"NOR,
    HIC "$N现了三头六臂，恶狠狠，手持六般兵器，丫丫叉叉，扑面来打！\n\n\n"NOR,
    HIC "$N变做三头六臂，把手中兵器幌一幌，幻出万千虚影，舞得如风车一般！\n\n\n"NOR,
  });

  //乾坤圈，第一打。
  //双随机；
  //几率打碎手持当前兵器，自制法宝除外。
  //几率气血当前/上限均减少1/5；
	msg = cast1[random(sizeof(cast1))];
	msg += cast2[random(sizeof(cast2))];
  msg += HIC "$N祭起乾坤圈，自天门上往下一掼，滴流流的着$n头上打去！\n\n" NOR;
  if( random(myexp) > random(targetexp) )
    {
      success += 1;
      how_long += 1*myzs;
      cost_mana += 10*myzs;

	msg += hitone[random(sizeof(hitone))];

	if (target->query_temp("weapon") )
		{
	  if( (myzs > random(100)) && (random(mystr) > random(targetstr)) )
		  {
		  //次要武器
			  obj=target->query_temp("secondary_weapon");
		  if ( obj && !obj->query("owner_id") && !obj->query("series_no"))
			  {
			  obj->unequip();
			  obj->set("value", 0);
			  msg += HIC "只听见「啪」地一声，" + target->name() + "手中的" + obj->name()+ HIC"已经断为两截！\n\n" NOR;
			  obj->set("name", "断掉的" + obj->query("name"));
			  obj->set("weapon_prop", 0);
			  obj->set("armor_prop", 0);
			  obj->move(environment(target));
			  call_out("remove_broken_cloth",random(30)+15,obj);
			  }
		  //主要武器
			  obj=target->query_temp("weapon");
		  if ( obj && !obj->query("owner_id") && !obj->query("series_no")) 
			  {
			  obj->unequip();
			  obj->set("value", 0);
			  msg += HIC "只听见「啪」地一声，" + target->name() + "手中的" + obj->name()+ HIC"已经断为两截！\n\n" NOR;
			  obj->set("name", "断掉的" + obj->query("name"));
			  obj->set("weapon_prop", 0);
			  obj->set("armor_prop", 0);
			  obj->move(environment(target));
			  call_out("remove_broken_cloth",random(30)+15,obj);
			  }
			  target->delete_temp("apply/damage");
			}
		  }

	  if( (myzs > random(100)) && (random(mycon) > random(targetcon)) )
		  {
		  target->receive_wound("kee", targeteffkee/5);
		  target->receive_damage("kee", targeteffkee/5);
		  }
  } else msg += missone[random(sizeof(missone))];
  //混天绫，第二打。
  //双随机；
  //几率有坐骑，拿掉；
  //几率精神当前/上限均减少1/3；
  //水中，busy翻倍；
  //若失败，把施法者身上的gold全部拿走。
  msg += HIR "\n$N把七尺混天绫望空一展，似火块千团，往下一裹！\n\n"NOR;
  if( random(mydx) > random(targetdx) )
    {
      msg += hittwo[random(sizeof(hittwo))];
      success += 1;
      how_long += 3*myzs;
      cost_mana += 15*myzs;
	  ridee = target->query_temp("ridee");

	  if ( ridee )
		{
		  if( (myzs > random(100)) && (random(myint) > random(targetint)) )
			  {
				msg += HIR "$n坠下" + ridee->name() + "，滚落在地。\n\n"NOR;
				target->set_temp("ridee",0);          
				target->add_temp("apply/dodge",-target->query_temp("ride/dodge"));
				target->set_temp("ride/dodge",0);
			  }
		}

	  if( (myzs > random(100)) && (random(myspi) > random(targetspi)) )
		  {
		  target->receive_wound("sen", targeteffsen/3);
		  target->receive_damage("sen", targeteffsen/3);
		  }

      if ( where->query("water") )
		  {
 msg += HIR "\n混天绫挥舞甩动时，红光万道，赤染水色。\n\n摆一摆，江河晃动；摇一摇，乾坤动撼！\n\n"NOR;
		  how_long += 3*myzs;
		  }
	} else {
		if ( present("gold", this_player()) )
		  {
		  present("gold", me)->move(target);
		  }
 msg += misstwo[random(sizeof(misstwo))];
  }
  //金砖，第三打。
  //双随机；
  //几率身上穿戴的装备全部打碎，自制法宝除外；
  //几率当前气血、精神变为-1。
 msg += HIY"\n$N手取金砖一块，丢起空中，喝声：“疾！”\n\n"NOR;
  if( myzs > targetzs )
    {
    inv = all_inventory(target);
    i = sizeof(inv);

      msg += hitthree[random(sizeof(hitthree))];
      success += 1;
      how_long += 5*myzs;
      cost_mana += 20*myzs;

	  if( (myzs > random(100)) && (random(mycor) > random(targetcor)) )
		  {
		if( target->query_temp("armor") )
			{
			  for (i=0; i < sizeof(inv); i++ ) 
				  {
			  obj = inv[i];
			  if( obj->query("equipped") != "worn" ) continue;
			  if( obj->query("owner_id") && obj->query("series_no") ) continue;
			  obj->delete("equipped");
			  obj->set("value", 0);
			  obj->set("No_Wear", 1);
			  msg += HIY"" + target->name() + "身上的" + obj->name()+ HIY"被打的粉碎！\n\n" NOR;
			  obj->set("name", "破碎的"+obj->query("name"));
			  call_out("remove_broken_cloth",random(30)+15,obj);
			  obj->move(environment(target));
				  }
			  target->delete_temp("apply/armor");
			}
		  }

	  if( (myzs > random(100)) && (random(mykar) > random(targetkar)) )
		  {
			target->receive_damage("kee", target->query("kee")*2);
			target->receive_damage("sen", target->query("sen")*2);
		  }
} else msg += missthree[random(sizeof(missthree))];
  me->add("mana", -(cost_mana));
  if(success)
    {
      target->start_busy(how_long);
      msg += hit[random(sizeof(hit))];
    }
  else
    {
      msg += miss[random(sizeof(miss))];
    }
  if( living(target) ) message_vision(msg, me, target);
  if( !wizardp(me) ) me->start_busy(random(myzs-10));
  if( wizardp(me) )
	tell_object(me, sprintf( HIW "BUSY：%d，命中：%d\n" NOR, how_long, success));
  return 1;
}

void remove_broken_cloth(object obj)
{
  if(obj && environment(obj)) {
    tell_object(environment(obj),
      "一阵微风吹过，"+obj->name()+"化为片片尘土，消失不见了。\n");
    destruct(obj);
  }
}
