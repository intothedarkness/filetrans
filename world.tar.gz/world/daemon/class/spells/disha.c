//Created by huadao for reincarnation's disha skills.20140502
//地煞技能可以召唤强力npc协助打斗；
//npc随着转生次数的提升，个数和攻击成倍增长；

#include <ansi.h>
inherit SSERVER;

int cast(object me, object target)
{
	int disha_time; 
	object soldier;
    int num = ( (int)me->query("reincarnation/number") - 5 );

//	if( !me->is_fighting() )
//		return notify_fail("只有战斗中才能使用地煞术！\n");

	disha_time= 120; 

	if( me->query("reincarnation/number") < 5 
		|| !me->query("reincarnation/number") 
		|| me->query("reincarnation/skills/disha_learned") != "done")
		return notify_fail("什么？\n");

	if( (time()-me->query("last_disha") ) < disha_time )
		return notify_fail("泼怪，休得心焦气躁！\n");
	
	if( (int)me->query("mana") <4*(int)me->query_skill("spells"))
		return notify_fail("你的法力不够了！\n");

	if( (int)me->query("sen") < 200 )
		return notify_fail("你的精神无法集中！\n");

		me->add("mana", -100*( (int)me->query("reincarnation/number") - 4 ) );

		message_vision(HIC "$N攒紧了拳头，叫一声：“齐天大圣”"+"！" +chinese_number((int)me->query("reincarnation/number") - 4)+ "个雷公手执铁棒，平空跳将出来！\n" NOR, me);
    
	for(int i = 0; i < num + 1; ++i)
		{
		seteuid(getuid());
		soldier = new("/obj/npc/disha_hufa");

		soldier->move(environment(me));
		soldier->invocation(me);
		soldier->set_temp("invoker",me);
		me->set("last_disha",time());
		}

	return 1;
}

int help (object me)
{
        write(@HELP
指令格式: cast disha

地煞技能可以召唤强力npc协助打斗；
召唤的npc随着转生次数的提升，个数和威力极大增长；

HELP );
	return 1;
}
