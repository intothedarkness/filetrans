//六阴追魂

#include <ansi.h>
#include <combat.h>
#include <weapon.h>
#include <skill.h>
inherit SSERVER;

int perform(object me, object target)
{
	object weapon;
       string msg,*limbs;
       int size,damage,ap;
	if( !target ) target = offensive_target(me);

        if(me->query("family/family_name")!="阎罗地府")
          return notify_fail("你所使用的外功中没有这种功能。\n");
	if( !target
	||	!target->is_character()
	||	!me->is_fighting(target) )
		return notify_fail(HIR"[六阴追魂]"NOR WHT"只能对战斗中的对手使用。\n"NOR);

	if( (int)me->query_skill("kusang-bang",1) < 60)
              return notify_fail(WHT"你的哭丧棒法还不够娴熟，不能使出「六阴追魂」。\n"NOR);

	if( (int)me->query_skill("stick",1) < 60)
              return notify_fail(WHT"你的棒法还不够娴熟，不能使出「六阴追魂」。\n"NOR);

	if( (int)me->query("force") < 50 )
		return notify_fail("你的内力不够。\n");

       weapon = me->query_temp("weapon");

	me->add("force", -150);
	me->add("bellicosity",10);
	me->receive_damage("kee", 50);
	me->receive_damage("sen", 50);

    message_vision(HIB"\n$N腾空跃起，大喝："HIR"[六阴追魂]"HIB"-------->\n",me,target);
    message_vision("\n只见$N连人带"+weapon->name()+HIB
"散作六团模糊不清的人影，挟带着一股惊人的邪气向$n冲去。。。\n"NOR,me,target);
	limbs=target->query("limbs");
	if( random(me->query("combat_exp")) > (int)target->query("combat_exp")/3 )	{
    message_vision(HIY"\n结果$n被邪气侵入心神,无法抵抗！\n"NOR,me,target);
    message_vision(HIR"\n$n"HIR"你只觉得邪气逼人，突然周身一凉，顿时很难动弹。"NOR,me,target);
		size=((int)me->query_skill("kusang-bang"));
		ap=size*10;
		damage=random(size*4)+size+me->query("bellicosity")/10;
              damage+=damage+me->query("force_factor")+random(damage);
		if(damage>=3000) damage=3000+random(2000);
    message_vision(HIW"\n[嗤]------的一声，"HIR+weapon->name()+HIR"刺入了$n"HIR"的"+
limbs[random(sizeof(limbs))]+"。。。\n\n"NOR,me,target);
		target->receive_damage("kee",damage,me);
		target->receive_wound("kee",damage/2,me);
		COMBAT_D->report_status(target);
		me->start_busy(2);return 1;
	} else {
    message_vision(HIC"\n可是$p"HIC"看破了$P"HIC"的企图，并闪到一旁。\n"NOR,me,target);
	       me->start_busy(3);
	}

        if( !target->is_fighting(me) ) {
                if( living(target) ) {
                        if( userp(target) ) target->kill_ob(me);
                        else target->kill_ob(me);
                }
        }

	return 1;
}
